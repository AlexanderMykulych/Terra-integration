include("helpers.js", "helpers");

/**
	@class Security manager which allows to create security_descriptor for items.
	@constructor
	@param security_descriptor_factories Associative array of security descriptors factories by items types
	@param default_factory Default security descriptor factory used for all types that are not supported by security_descriptor_factories
	@memberOf security_manager
*/
function security_manager2(security_descriptor_factories, default_factory)
{
	if (default_factory == null)
		default_factory = const_access_factory(false);

	/**
	Security descriptor factory for types with constant predefined access rights.
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param {data_model.item_ex} item_ex Item security descriptor for which should be created.
	@return Security descriptor for "item_ex"
	@type security_manager.security_descriptor
	*/
	this.create = function(ctx, item_ex)
	{
		if (item_ex == null)
			item_ex = ctx.item_ex;
		var item_type = item_ex.get_type();
		var descr = security_descriptor_factories[item_type];
		if (descr == null)
			descr = default_factory;
		return descr(ctx, item_ex);
	}
}

function factory_from_constructor(c)
{
	return (function(ctx, item_ex) { return new c(ctx, item_ex); });
}

/**
Security descriptor factory for types with constant predefined access rights
@param {Boolean} del Delete access flag
@param {Boolean} modify Modify access flag, same as "del" by default
@param {Boolean} view View access flag, same as "modify" by default
@param {Boolean} link Link access, same as modify for create and remove by default
@return Constant access security descriptor
@extends security_manager.security_descriptor
@memberOf security_manager
*/
function const_access_factory(del, modify, view, link)
{
	if (modify == null)
		modify = del;
	if (view == null)
		view = modify;
	del = del == true;
	modify = modify == true;
	view = view == true;

	if (link == null)
	{
		link = {
			"create": modify,
			"remove": modify
		};
	}

	var descriptor = {
		"delete_access": function() { return del; },
		"modify_access": function() { return modify; },
		"view_access": function() { return view; },
		"link_access": function() { return link; },
		"link_operation_access": function(link_ctx)
		{
			return link[link_ctx.operation];
		}
	};

	return (function() { return helpers.merge_contexts(descriptor); });
}

/**
@class Security manager. It implements basic security checks for items
based on logic implemented by security descriptors
@constructor
@param {session} session Session object provided by C++
@param security_descriptor_factories Associative array of security descriptors factories by items types
@param default_factory Default security descriptor factory used for all types that are not supported by security_descriptor_factories
@memberOf security_manager
*/
function security_manager(session, security_descriptor_factories, default_factory)
{
	/**
	Creates security descriptor for item
	@param {form} [form] Outlook form object
	@param [item=form.item] Item. Used when there's no form specified
	@returns Security descriptor
	*/
	this.create_descriptor = function(form, item)
	{
		if (item == null)
			item = form.item;
		var item_type = item.type_id;
		var descr = security_descriptor_factories[item_type];
		if (descr == null)
			descr = default_factory;
		return descr != null ? descr(session, item, form) : null;
	}

	/**
	Checks delete access for item
	@param item Item
	@returns True if item can be deleted
	*/
	this.delete_access = function(item)
	{
		return this.create_descriptor(null, item).delete_access();
	}

	/**
	Checks modify access for item
	@param item Item
	@returns True if item can be modified
	*/
	this.modify_access = function(item)
	{
		return this.create_descriptor(null, item).modify_access();
	}

	/**
	Checks view access for item
	@param item Item
	@returns True if item can be opened and viewed
	*/
	this.view_access = function(item)
	{
		return this.create_descriptor(null, item).view_access();
	}
}