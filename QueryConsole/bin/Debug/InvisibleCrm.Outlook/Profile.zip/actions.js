include("actions_support.js", "actions_support");
include("security_utils.js", "security_utils");
include("business_logic.js", "business_logic");
include("mail_processing.js", "mail_processing");
include("data_model.js", "data_model");
include("control_utils.js", "utils");
include("helpers.js", "helpers");
include("idle.js", "idle");

function open_help_url(help_url) {
	this.execute = function (ctx) {
		var shell = new ActiveXObject("WScript.Shell");
		shell.Run(help_url);
	};
}

function convert_items(item_convertor, ctx, to_platform, folder_type) {
	this.ctx_changed = function (action_ctx) {
		if (action_ctx.type == "explorer" && ctx.application.item_convertor.conversion_available(action_ctx)) {
			action_ctx.ctrl.visible = true;
			var item = actions_support.retrieve_single_item(action_ctx);
			var is_conversion_available;
			if (to_platform) {
				is_conversion_available = (item == null && action_ctx.selected_count > 0);
			} else {
				is_conversion_available = (item != null) && !item.Shared;
			}
			action_ctx.ctrl.enabled = is_conversion_available;
		} else {
			action_ctx.ctrl.enabled = false;
		}
	};
	this.execute = function (action_ctx) {
		if (item_convertor.conversion_available(action_ctx)) {
			if (to_platform) {
				ctx.application.item_convertor.convert_to_platform(action_ctx);
				for (var enm = new Enumerator(action_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
					adjust_lookup(ctx, enm.item());
				}
			} else {
				ctx.application.item_convertor.convert_to_native(action_ctx);
			}
		}
	};
}

function track_mail(ctx, track) {
	return new function () {

		var change_shared_state = function (helper, item) {
			helper.Shared = track;
			helper.save();
			item.FlagStatus = track ? helpers.TrackStatus.SharedFlagStatus : helpers.TrackStatus.UnSharedFlagStatus;
			item.save();
		};
		var get_proxy_by_PIMId = function (id) {
			var session = ctx.session, filter = session.create_criteria("and");
			filter.add(session.create_expression("PIMObjectId", "eq", id));
			return session.find_item("Activity", filter);;
		};
		this.execute = function (act_ctx) {
			for (var enm = new Enumerator(act_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
				var mail_processor = new business_logic.mail_processor(ctx), session = ctx.session;
				var item = enm.item();
				if (item.type_id == "Mail") {
					var id = item.SearchKey;
					var helper = get_proxy_by_PIMId(id);
					if (typeof (helper) != "undefined" && helper != null) {
						if (helper.Shared != track) {
							change_shared_state(helper, item);
						}
					} else {
						if (track) {
							helper = session.create_item("Activity");
							mail_processor.process_ol_item_changes(new data_model.std_item_ex(helper, null),
								new data_model.std_item_ex(item, null), true);
							change_shared_state(helper, item);
						}
					}
					if (helper.Contact == null) {
						var filter = ctx.session.create_criteria("and");
						if (item.Inbound) {
							filter.add(ctx.session.create_expression("Email", "eq", item.SenderAddress));
						} else {
							filter.add(ctx.session.create_expression("Email", "eq", helpers.get_recipient_address(ctx.application, helpers.retrieve_single_item(item.raw_item.Recipients))));
						}
						var contact = ctx.session.find_item("Contact", filter);
						if (contact != null) {
							helper.Contact = contact.id;
							if (contact.Account != null) {
								var account = ctx.session.open_item(contact.Account);
								if (account != null) {
									helper.Account = account.id;
								}
							}
							helper.save();
						}
					}
				}
			}
		};
		this.ctx_changed = function (act_ctx) {
			var is_enabled = false;
			for (var enm = new Enumerator(act_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
				var item = enm.item();
				if (item.type_id == "Mail") {
					var id = item.SearchKey;
					var helper = get_proxy_by_PIMId(id);
					if (typeof (helper) != "undefined" && helper != null) {
						if ((helper.Shared && !track) || (!helper.Shared && track)) {
							is_enabled = true;
							break;
						}
					} else {
						if (track) {
							is_enabled = track;
							break;
						}
					}
				}
			}
			act_ctx.ctrl.enabled = is_enabled;
		};
	};
}

function retrieve_single_item(ctx) {
	var enm = new Enumerator(ctx);
	if (!enm.atEnd() && enm.item() != null)
		return enm.item();
	return null;
}

function track_item(ctx, track, folder_type) {
	return new function () {
		this.ctx_changed = function (action_ctx) {
			if (action_ctx.type == "explorer" && ctx.application.item_convertor.conversion_available(action_ctx)) {
				action_ctx.ctrl.visible = true;
				var item = actions_support.retrieve_single_item(action_ctx);
				if ((item == null && track == true) || (item != null && item.Shared == !track) ||
					(item != null && item.Shared == null && track)) {
					action_ctx.ctrl.enabled = true;
				} else {
					action_ctx.ctrl.enabled = false;
				}
			} else {
				action_ctx.ctrl.enabled = false;
			}
		};
		this.execute = function (action_ctx) {
			if (track == true && ctx.application.item_convertor.conversion_available(action_ctx) == true) {
				ctx.application.item_convertor.convert_to_platform(action_ctx);
			}
			for (var enm = new Enumerator(action_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
				var item = enm.item();
				if (track) {
					adjust_lookup(ctx, item);
				}
				ctx.idle_manager.add_job(item.id, "TrackItem", { "track": track }, false);
			}
		};
	};
}

function adjust_job(ctx, item) {
	if (item != null && item.raw_item.JobTitle && item.raw_item.JobTitle != "") {
		var filter = ctx.session.create_criteria("and");
		filter.add(ctx.session.create_expression("Name", "eq", item.raw_item.JobTitle));
	}
}

function adjust_lookup_type(ctx, item, type, field_value, lookup_field) {
	if (field_value && field_value != "") {
		var filter = ctx.session.create_criteria("and");
		filter.add(ctx.session.create_expression("Name", "eq", field_value));
		var result = ctx.session.find_item(type, filter);
		if (result == null) {
			result = ctx.session.create_item(type);
			result.Name = field_value;
			result.Save();
		}
	}
}

function adjust_lookup(ctx, item) {
	if (item.type_id == "Contact") {
		adjust_lookup_type(ctx, item, "Account", item.raw_item.CompanyName, "Account");
		adjust_lookup_type(ctx, item, "Country", item.raw_item.BusinessAddressCountry, "Country");
		adjust_lookup_type(ctx, item, "City", item.raw_item.BusinessAddressCity, "City");
		adjust_lookup_type(ctx, item, "Region", item.raw_item.BusinessAddressState, "Region");
		adjust_job(ctx, item);
	}
}

function open_remote(ctx) {
	var shell = new ActiveXObject("WScript.Shell");

	this.ctx_changed = function (action_ctx) {
		if (action_ctx.type == "explorer") {
			action_ctx.ctrl.enabled = false;
			for (var enm = new Enumerator(action_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
				action_ctx.ctrl.enabled = false;
				var item = utilities.try_get_mail_item(enm.item());
				if (item != null && utilities.is_synchronized_item(ctx, item)) {
					action_ctx.ctrl.enabled = (item.type_id == "Contact") || (item.type_id == "Task") ||
						(item.type_id == "Activity") || (item.type_id == "Appointment");
					break;
				}
			}
		} else {
			var item = utilities.try_get_mail_item(actions_support.retrieve_single_item(action_ctx));
			if (item == null) {
				action_ctx.ctrl.enabled = false;
			} else {
				action_ctx.ctrl.enabled = (item.type_id == "Contact" || item.type_id == "Task"
					|| item.type_id == "Activity" || item.type_id == "Appointment") &&
					utilities.is_synchronized_item(ctx, item);
			}
		}
	};
	this.execute = function (action_ctx) {
		var url = new String(), opened = false;
		if (action_ctx.type == "explorer") {
			for (var enm = new Enumerator(action_ctx.selection) ; !enm.atEnd() ; enm.moveNext()) {
				var item = utilities.try_get_mail_item(enm.item());
				if (utilities.is_synchronized_item(ctx, item)) {
					shell.Run(get_object_page(item));
					opened = true;
					break;
				}
			}
		} else {
			var item = utilities.try_get_mail_item(actions_support.retrieve_single_item(action_ctx));
			if (item != null && utilities.is_synchronized_item(ctx, item)) {
				shell.Run(get_object_page(item));
				opened = true;
			}
		}
		if (!opened && typeof url != "undefined" && url.length > 0) shell.Run(url);
	};
	var utilities = {
		'try_get_mail_item': function (item) {
			if (item != null && item.type_id == "Mail") {
				var filter = ctx.session.create_criteria("and");
				filter.add(ctx.session.create_expression("PIMObjectId", "eq", item.SearchKey));
				item = ctx.session.find_item("Activity", filter);
			}
			return item;
		},

		'is_synchronized_item': function (ctx, item) {
			return item != null && item.raw_item.Saved && ctx.application.synchronizer.id_to_remote(item.id) != null
				&& item.Shared;
		},

		'get_context_type': function (action_ctx) {
			if (action_ctx.is_current_folder_of_type("Contact")) {
				return "Contact";
			}
			if (action_ctx.is_current_folder_of_type("Mail")) {
				return "Mail";
			}
			return null;
		}
	};
	var get_object_page = function (item) {
		return ctx.application.connector.get_object_page(ctx.application.synchronizer.id_to_remote(item.id));
	};
}

function get_recipient_address(application, recipient) {
	var result = null;
	try {
		var type = recipient.AddressEntry.Type;
		if (type == "SMTP" && recipient.Address != "")
			result = recipient.Address;
		else {
			var addresses = application.accounts.open_entry(application.session.hexstring_to_id(recipient.EntryID)).toArray();
			if (addresses.length > 0)
				result = addresses[0];
		}
	}
	catch (e) { }
	return result;
}

function new_item(ctx, item_type) {
	this.execute = function (act_ctx) {
		new actions_support.new_item(ctx.session, item_type).execute(act_ctx);
	};
	this.ctx_changed = function (act_ctx) {
		act_ctx.ctrl.visible = act_ctx.type == "explorer" && act_ctx.is_current_folder_of_type(item_type);
	};
}

function show_help(ctx) {
	this.execute = function (act_ctx) {
		var shell = new ActiveXObject("WScript.Shell");
		var file_name = "\"" + ctx.application.platform_dir + "\\BPMonline_Outlook_Connector_UG.pdf\"";
		try {
			shell.Run(file_name);
		} catch (e) {
			ctx.ui.message_box(0, ctx.session.res_string("help_filenotfound").replace("[#filename#]", file_name),
				ctx.session.res_string("msg_warning"), 0x30);
		}
	};
}