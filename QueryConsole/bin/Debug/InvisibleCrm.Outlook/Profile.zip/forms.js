//Forms back end classes
include("control_utils.js", "control_utils");
include("form_helpers.js", "form_helpers");
include("helpers.js", "helpers");
include("business_logic.js", "business_logic");
include("raw_item_functions.js", "raw_item_functions");
include("mail_processing.js", "mail_processing");
include("mvg_dialogs.js", "mvg_dialogs");

function create_form_ctx(ctx) {
	var g_ctx = ctx.application_script.g_ctx;
	helpers.merge_contexts(helpers.get_restricted_context(g_ctx, ["data_model", "security_manager", "cfp_manager", "save_helper", "save", "primary_updater", "joined_fields_updater"]), ctx);
	ctx.session = ctx.application.session;
	ctx.settings = ctx.application.settings;
	ctx.events = new helpers.events_connection();
	ctx.ensure_saved_confirmation = false;
	new form_helpers.form_links_manager(ctx);
	return ctx;
}

function form_contact(ctx) {
	var form = ctx.form;
	var events = new helpers.events_connection();
	ctx.form_links_manager.init_new();
	var session = ctx.session;
	var validator = new form_helpers.form_validator(session, form);
	validator.validate_empty_field("Name", "name_id", "msg_contact_name_validation");

	var form_saved = function () {
		var id = ctx.item_ex.get_id(), employee;
		var filter = session.create_criteria("and");
		filter.add(session.create_expression("Contact", "eq", id));
		employee = session.find_item("Employee", filter);
		if (typeof (employee) != "undefined" && employee != null && employee.Name != ctx.form.item.Name) {
			employee.Name = ctx.form.item.Name;
			employee.silent_save();
		}
	};
	form.on_saved.connect(form_saved);

	function on_city_changed() {
		var cityId = form.city_id.selected;
		if (cityId != null) {
			var city = session.open_item(cityId);
			if (city != null) {
				var countryId = city.Country;
				var countryName = city.CountryName;
				var regionId = city.Region;
				var regionName = city.RegionName;
			} else {
				return;
			}
		}
		if (countryId != undefined) {
			form.country_id.assign(countryId, countryName);
			form.item.Country = countryId;
		}
		if (regionId != undefined) {
			form.region_id.assign(regionId, regionName);
			form.item.Region = regionId;
		}
	}

	function on_region_changed() {
		var regionId = form.region_id.selected;
		if (regionId != null) {
			var region = session.open_item(regionId);
			if (region != null) {
				var countryId = region.Country;
				var countryName = region.CountryName;
			} else {
				return;
			}
		}
		if (countryId != undefined) {
			form.country_id.assign(countryId, countryName);
			form.item.Country = countryId;
		}
	}
	events.connect(form.city_id, "changed", on_city_changed);
	events.connect(form.region_id, "changed", on_region_changed);
	//	form_helpers.open_remote_item_from_form_control(form.btn_owner_remote, form.owner_id, form.item.Owner);
	//	form_helpers.open_remote_item_from_form_control(form.btn_account_remote, form.account_id, form.item.Account);

	register_scriptable_autocomplete_control(ctx, "Account", form.btn_account_select, form.account_id,
													"lbl_Account", "accounts:salesbook", ["Name"], null,
													function (ctx, item) { return item["Name"]; },
													function (ctx, keywords_filter) {
														var filter = ctx.session.create_criteria("and");
														filter.add(keywords_filter);
														return filter;
													}, false);
	register_scriptable_autocomplete_control(ctx, "Contact", form.btn_owner_select, form.owner_id,
													"lbl_Owner", "contacts:salesbook", ["Name"], null,
													function (ctx, item) { return item["Name"]; },
													function (ctx, keywords_filter) {
														var employees = session.find_items("Employee", ctx.session.create_criteria("and"));
														var filter = session.create_criteria("or");
														for (var enm = new Enumerator(employees) ; !enm.atEnd() ; enm.moveNext()) {
															var employee = enm.item();
															filter.add(session.create_expression("Name", "eq", employee.Name));
														}
														var filter2 = ctx.session.create_criteria("and");
														filter2.add(keywords_filter);
														filter2.Add(filter);
														return filter2;
													}, false);
	register_scriptable_autocomplete_control(ctx, "Country", form.btn_country_select, form.country_id,
												"lbl_Country", "countries:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													filter.add(keywords_filter);
													return filter;
												}, true);
	register_scriptable_autocomplete_control(ctx, "Region", form.btn_region_select, form.region_id,
												"lbl_Region", "regions:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													filter.add(keywords_filter);
													if (form.country_id.selected != null) {
														filter.add(ctx.session.create_expression("Country", "eq", form.country_id.selected));
													}
													return filter;
												}, true);
	register_scriptable_autocomplete_control(ctx, "City", form.btn_city_select, form.city_id,
												"lbl_City", "cities:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													if (form.country_id.selected != null) {
														filter.add(ctx.session.create_expression("Country", "eq", form.country_id.selected));
													}
													if (form.region_id.selected != null) {
														filter.add(ctx.session.create_expression("Region", "eq", form.region_id.selected));
													}
													filter.add(keywords_filter);
													return filter;
												}, true);

}

function form_task(ctx) {
	var form = ctx.form;
	ctx.form_links_manager.init_new();

	// TODO: �������������
	var form_saved = function () {
		form_task_actualize_participants("TaskParticipant", ctx);
	};

	form.on_saved.connect(form_saved);
	register_scriptable_autocomplete_control(ctx, "Account", form.btn_account_select, form.account_id,
														"lbl_Account", "accounts:salesbook", ["Name"], null,
														function (form_ctx, item) { return item["Name"]; },
														function (form_ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
	register_scriptable_autocomplete_control(ctx, "Opportunity", form.btn_opportunity_select, form.opportunity_id,
														"lbl_Opportunity", "opportunities:salesbook", ["Title"], null,
														function (ctx, item) { return item["Title"]; },
														function (ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
}

function delete_participants(activityFilter, ctx, type) {
	var form = ctx.form;
	var participants = new Enumerator(ctx.session.find_items(type, activityFilter));
	for (var enm = participants; !enm.atEnd() ; enm.moveNext()) {
		var participant = ctx.session.open_item(enm.item().Participant);
		var exist = false;
		for (var i = 1; i < form.item.raw_item.Recipients.Count + 1; i++) {
			var recipient = form.item.raw_item.Recipients.Item(i);
			var filter = ctx.session.create_criteria("or");
			filter.add(ctx.session.create_expression("Email", "eq", recipient.Address));
			var contacts = new Enumerator(ctx.session.find_items("Contact", filter));
			for (var enm = contacts; !enm.atEnd() ; enm.moveNext()) {
				if (enm.item() != null && participant != null && ctx.session.equal_ids(participant.id, enm.item().id)) {
					exist = true;
					break;
				}
			}
		}
		if (!exist) {
			ctx.session.open_item(enm.item().id).remove();
		}
	}
}

function add_participants(activityFilter, ctx, type) {
	var form = ctx.form;

	for (var i = 1; i < form.item.raw_item.Recipients.Count + 1; i++) {
		var exist = false;
		participants = new Enumerator(ctx.session.find_items(type, activityFilter));
		var recipient = form.item.raw_item.Recipients.Item(i);
		var filter = ctx.session.create_criteria("and");
		filter.add(ctx.session.create_expression("Email", "eq", recipient.Address));
		for (participants; !participants.atEnd() ; participants.moveNext()) {
			if (participants.item().Participant == null) {
				continue;
			}
			var participant = ctx.session.open_item(participants.item().Participant);
			var contacts = new Enumerator(ctx.session.find_items("Contact", filter));
			for (contacts; !contacts.atEnd() ; contacts.moveNext()) {
				var contact = contacts.item();
				if (contact != null && participant != null && ctx.session.equal_ids(participant.id, contact.id)) {
					exist = true;
					break;
				}
			}
		}
		if (!exist) {
			if (contact == null) {
				contact = ctx.session.find_item("Contact", filter);
				if (contact == null) {
					return;
				}
			}
			var taskParticipant = ctx.session.create_item(type);
			taskParticipant.Activity = form.item.id;
			taskParticipant.Participant = contact.id;
			taskParticipant.silent_save();
		}
	}
}

function form_task_actualize_participants(type, ctx) {
	var form = ctx.form;
	var activityFilter = ctx.session.create_criteria("and");
	activityFilter.add(ctx.session.create_expression("Activity", "eq", form.item.id));
	delete_participants(activityFilter, ctx, type);
	add_participants(activityFilter, ctx, type);
}

function form_appointment(ctx) {
	var form = ctx.form;
	ctx.form_links_manager.init_new();
	var form_saved = function () {

		form_task_actualize_participants("AppointmentParticipant", ctx);
	};
	var form_saving = function () {
		form.item.ShowInScheduler = true;
	};
	form.on_saved.connect(form_saved);
	form.on_saving.connect(form_saving);

	register_scriptable_autocomplete_control(ctx, "Account", form.btn_account_select, form.account_id,
														"lbl_Account", "accounts:salesbook", ["Name"], null,
														function (form_ctx, item) { return item["Name"]; },
														function (form_ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
	register_scriptable_autocomplete_control(ctx, "Opportunity", form.btn_opportunity_select, form.opportunity_id,
														"lbl_Opportunity", "opportunities:salesbook", ["Title"], null,
														function (ctx, item) { return item["Title"]; },
														function (ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
}

function form_mail(ctx) {
	var mail_processor = new business_logic.mail_processor(ctx),
		on_saved_processing = false;

	var validator = new form_helpers.form_validator(ctx.session, ctx.form);
	validator.add_custom(business_logic.mail_owner_validator(ctx, ctx.form.mail_subform), null, "");
	ctx.validator.set_enabled(false);
	var subform_ctx =
	{
		"form": ctx.form.mail_subform,
		"child_type": "subform",
		"parent_ctx": ctx,
		"validate_access": false
	};
	helpers.merge_contexts(ctx, subform_ctx);
	ctx.link_forms = function () {
		if (subform_ctx.item_ex.get_id() != null) {
			var related_form = ctx.application.forms.find_by_object(subform_ctx.item_ex.get_id());
			if (related_form != null)
				link_activity_forms(ctx, subform_ctx.form, related_form);
		}
	};

	function update_subform(initial_run) {
		if (ctx.on_ctx_loaded != null) {
			ctx.on_ctx_loaded();
		}
		if (subform_ctx.form.item == null) {
			subform_ctx.form.item = mail_processor.get_proxy(ctx.item_ex, true, subform_ctx.created_from_ctx).fcd_item;
		}
		subform_ctx.revert_links = initial_run;
		new form_helpers.form_links_manager(subform_ctx);
		subform_ctx.form_links_manager.triggers.add_simple_trigger(form_helpers.create_mvg_link_result_analizer(ctx.data_model.mvg_link_result_options), null, null, "mvg", "check_results");
		subform_ctx.form_handler = new attach_helper(subform_ctx);
		ctx.link_forms();
		subform_ctx.form.visible = !(initial_run && ctx.form.ol_2003_virtual_form);
		if (!initial_run)
			ctx.item_ex.set_form_dirty();
	}

	function process_ol_item_changes() {
		if (!ctx.save_helper.is_saving_now(ctx.item_ex.fcd_item) && ctx.item_ex.fcd_item.Sent) {
			on_saved_processing = true;
			var is_new_proxy = subform_ctx.item_ex.get_id() == null;
			mail_processor.process_ol_item_changes(subform_ctx.item_ex, ctx.item_ex, is_new_proxy);
			subform_ctx.form_links_manager.on_saved();
			on_saved_processing = false;
			subform_ctx.created_from_ctx = null;
		}
		if (!ctx.form.item.raw_item.Saved) {
			subform_ctx.item_ex.set_property("PIMObjectId", ctx.form.item.SearchKey);
		}
		subform_ctx.form.save();
	}

	function on_saved() {
		if (!ctx.form.item.raw_item.Saved) {
			subform_ctx.item_ex.set_property("PIMObjectId", ctx.form.item.SearchKey);
		}
		subform_ctx.form.save();
	}

	function on_share_click() {
		var tracked = ctx.form.mail_subform.share_chk.checked;
		ctx.form.item.FlagStatus = tracked ? helpers.TrackStatus.SharedFlagStatus : helpers.TrackStatus.UnSharedFlagStatus;
		if (tracked && ctx.form.mail_subform.item.Contact == null) {
			var filter = ctx.session.create_criteria("and");
			if (ctx.form.item.Inbound) {
				filter.add(ctx.session.create_expression("Email", "eq", ctx.form.item.SenderAddress));
			} else {
				filter.add(ctx.session.create_expression("Email", "eq", helpers.get_recipient_address(ctx.application, helpers.retrieve_single_item(ctx.form.item.raw_item.Recipients))));
			}
			if ((ctx.form.item.Inbound && ctx.form.item.SenderAddress) || (!ctx.form.item.Inbound && helpers.get_recipient_address(ctx.application, helpers.retrieve_single_item(ctx.form.item.raw_item.Recipients)))) {
				var contact = ctx.session.find_item("Contact", filter);
				if (contact != null && contact.Account != null) {
					var account = ctx.session.open_item(contact.Account);
					if (account != null) {
						ctx.form.mail_subform.item.Account = account.id;
						ctx.form.mail_subform.account_id.assign(account.id, account.Name);
					}
				}
			}
		}
	}

	function on_subform_control_changed() {
		raw_item_functions.set_item_dirty(ctx.item_ex.fcd_item);
	}
	ctx.events.connect(ctx.form.mail_subform.account_id, "changed", on_subform_control_changed);
	ctx.events.connect(ctx.form.mail_subform.opportunity_id, "changed", on_subform_control_changed);
	ctx.events.connect(ctx.form.mail_subform.share_chk, "on_click", on_share_click);
	ctx.events.connect(ctx.form_links_manager, "on_after_saved", on_saved);
	ctx.events.connect(subform_ctx.form, "on_edited", function () { if (!on_saved_processing == true) ctx.item_ex.set_form_dirty(); });
	ctx.events.connect(ctx.application, "on_mail_sending", process_ol_item_changes);
	ctx.events.connect(ctx.form_links_manager, "on_after_saved", process_ol_item_changes);
	ctx.application.on_mail_sent.connect(process_ol_item_changes);
	update_subform(true);
}

function form_city(ctx) {
	var form = ctx.form;
	var events = new helpers.events_connection();
	ctx.form_links_manager.init_new();
	var session = ctx.session;
	var validator = new form_helpers.form_validator(session, form);
	validator.validate_empty_field("Name", "name_id", "msg_city_name_validation");

	function on_region_changed() {
		var regionId = form.region_id.selected;
		if (regionId != null) {
			var region = session.open_item(regionId);
			if (region != null) {
				var countryId = region.Country;
				var countryName = region.CountryName;
			} else {
				return;
			}
		}
		if (countryId != undefined) {
			form.country_id.assign(countryId, countryName);
			form.item.Country = countryId;
		}
	}

	events.connect(form.region_id, "changed", on_region_changed);

	register_scriptable_autocomplete_control(ctx, "Country", form.btn_country_select, form.country_id,
												"lbl_Country", "countries:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													filter.add(keywords_filter);
													return filter;
												}, false);
	register_scriptable_autocomplete_control(ctx, "Region", form.btn_region_select, form.region_id,
												"lbl_Region", "regions:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													filter.add(keywords_filter);
													if (form.country_id.selected != null) {
														filter.add(ctx.session.create_expression("Country", "eq", form.country_id.selected));
													}
													return filter;
												}, false);
}

function form_region(ctx) {
	var form = ctx.form;
	var events = new helpers.events_connection();
	ctx.form_links_manager.init_new();
	var session = ctx.session;
	var validator = new form_helpers.form_validator(session, form);
	validator.validate_empty_field("Name", "name_id", "msg_region_name_validation");

	register_scriptable_autocomplete_control(ctx, "Country", form.btn_country_select, form.country_id,
												"lbl_Country", "countries:salesbook", ["Name"], null,
												function (ctx, item) { return item["Name"]; },
												function (ctx, keywords_filter) {
													var filter = ctx.session.create_criteria("and");
													filter.add(keywords_filter);
													return filter;
												}, false);
}

function form_country(ctx) {
	var form = ctx.form;
	var events = new helpers.events_connection();
	ctx.form_links_manager.init_new();
	var session = ctx.session;
	var validator = new form_helpers.form_validator(session, form);
	validator.validate_empty_field("Name", "name_id", "msg_country_name_validation");
}

function form_job(ctx) {
	var form = ctx.form;
	var events = new helpers.events_connection();
	ctx.form_links_manager.init_new();
	var session = ctx.session;
	var validator = new form_helpers.form_validator(session, form);
	validator.validate_empty_field("Name", "name_id", "msg_job_name_validation");
}

function attach_helper(ctx) {
	ctx.controls_initialized = true;
	if (ctx.parent_ctx.item_ex.get_type() == "Mail") {
		var form = ctx.form;
		register_scriptable_autocomplete_control(ctx, "Account", form.btn_account_select, form.account_id,
														"lbl_Account", "accounts:salesbook", ["Name"], null,
														function (ctx, item) { return item["Name"]; },
														function (ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
		register_scriptable_autocomplete_control(ctx, "Opportunity", form.btn_opportunity_select, form.opportunity_id,
														"lbl_Opportunity", "opportunities:salesbook", ["Title"], null,
														function (ctx, item) { return item["Title"]; },
														function (ctx, keywords_filter) {
															var filter = ctx.session.create_criteria("and");
															filter.add(keywords_filter);
															return filter;
														}, false);
		ctx.form_links_manager.init_new();
	}
}

function register_view_control_with_button(ctx, linked_to, view_ctrl, btn_ctrl, additional_params) {
	ctx.form_links_manager.add_controller(
		new form_helpers.view_ctrl(),
		helpers.merge_contexts(additional_params, {
			"view_ctrl": ctx.form[view_ctrl],
			"link_to": linked_to,
			"btn_show_new": ctx.form[btn_ctrl],
			"missing_object_message": true
		})
	);
}

function register_autocomplete_control(ctx, link_to, autocomplete_ctrl, show_salesbook_btn, subform, additional_params) {
	var autocomplete_options;
	autocomplete_options =
		{
			"link_to": link_to,
			"tag": "direct",
			"ctrl": subform ? ctx.form[subform][autocomplete_ctrl] : ctx.form[autocomplete_ctrl],
			"btn_show": subform ? ctx.form[subform][show_salesbook_btn] : ctx.form[show_salesbook_btn],
			"created_from_ctx_type": "link_me",
			"ctrl_ex": new form_helpers.autocomplete_wrapper()
		};
	helpers.merge_contexts(additional_params, autocomplete_options);
	ctx.form_links_manager.add_controller(autocomplete_options.ctrl_ex, autocomplete_options);
	ctx.form_links_manager.add_controller(new form_helpers.direct_link_controller(), autocomplete_options);
	ctx.form_links_manager.add_controller(new form_helpers.sales_book_selector(), autocomplete_options);
}

function register_scriptable_autocomplete_control(ctx, link_to, btn_ctrl, autocomplete_ctrl, caption, view_id,
															search_by, image, display_name_fn, filter_fn, allow_new) {
	var assoc_to_options = {
		"link_to": link_to,
		"tag": "direct",
		"created_from_ctx_type": "link_me",
		"btn_show": btn_ctrl,
		"autocomplete": autocomplete_ctrl,
		"ctrl_ex": new mvg_dialogs.scriptable_autocomplete_wrapper(),
		"sources": [{
			"caption": caption,
			"view_id": view_id,
			"search_by": search_by,
			"image": image,
			"display_name_fn": display_name_fn,
			"filter_fn": filter_fn,
			"allow_new": allow_new,
			"visible_new": allow_new
		}]
	};
	ctx.form_links_manager.add_controller(assoc_to_options.ctrl_ex, assoc_to_options);
	ctx.form_links_manager.add_controller(new form_helpers.direct_link_controller(), assoc_to_options);
	ctx.form_links_manager.add_controller(new mvg_dialogs.custom_sales_book(), assoc_to_options);
}

function link_activity_forms(ctx, form1, form2) {
	var forms = ctx.application.forms;
	var ids = ["account_id", "opportunity_id", "ActionToContact", "ActionToEmployee", "Type"];
	helpers.for_each(ids, function (id) {
		var c1 = form1[id];
		var c2 = form2[id];
		if (c1 != null && c2 != null)
			forms.link_controls(form1, c1, form2, c2);
	});
}
