include("helpers.js", "helpers");

/**
@class Class that stores information how different object types can be linked
@constructor
@memberOf data_model
@deprecated
*/
function meta_scheme()
{
	var mvg_associations = new Array();
	var links = new Array();
	var objects = new Array();
	var filters = new Array();

	var mvg_association_object_description = function(type, left_link, right_link,
	                                                  left_assoc_status, right_assoc_status)
	{
		this.type = type;
		this.left_link = left_link;
		this.right_link = right_link;
		this.left_assoc_status = left_assoc_status;
		this.right_assoc_status = right_assoc_status;

		this.get_reverted = function()
		{
			return new mvg_association_object_description(type, right_link, left_link, right_assoc_status, left_assoc_status);
		}
	}

	var mvg_link_description = function(obj_type, link_to_type, association_type, left_obj_primary, right_obj_primary, is_reverted)
	{
		this.link_type = "mvg";
		this.obj_type = obj_type;
		this.link_to_type = link_to_type;
		this.left_obj_primary_link = left_obj_primary;
		this.right_obj_primary_link = right_obj_primary;
		this.is_reverted = is_reverted == true;

		this.get_reverted = function()
		{
			return new mvg_link_description(link_to_type, obj_type, association_type, right_obj_primary, left_obj_primary, is_reverted != true);
		}

		this.get_association_description = function()
		{
			return mvg_associations[get_link_index(this.obj_type, this.link_to_type)];
		}

		if (left_obj_primary != null)
			left_obj_primary.prefill_for_first_association = true;
		if (right_obj_primary != null)
			right_obj_primary.prefill_for_first_association = true;
	}

	var direct_link_description = function(obj_type, link_to_type, field)
	{
		this.link_type = "direct";
		this.obj_type = obj_type;
		this.link_to_type = link_to_type;
		this.field_name = field;

		this.get_field_descriptor = function()
		{
			return objects[this.obj_type].fields[this.field_name];
		}
	}

	var get_link_index = function(type1, type2)
	{
		return "[" + type1 + "]" + "[" + type2 + "]";
	}

	var object_descriptor = function(type)
	{
		this.fields = new Array();
		this.view_method = "disabled";

		this.get_fields_enumerator = function()
		{
			return new Enumerator(this.fields);
		}
	}

	var get_object_descriptor = function(type)
	{
		if (objects[type] == null)
			objects[type] = new object_descriptor(type);
		return objects[type];
	}

	var field_descriptor = function(obj_type, name, link_to_type, view_ids, require_refresh)
	{
		this.obj_type = obj_type;
		this.name = name;
		this.link_to_types = new Array(link_to_type);
		this.view_ids = view_ids;
		this.cascade_refresh = require_refresh == "cascade";
		this.require_refresh = this.cascade_refresh || require_refresh == true;
	}

	var add_field_descriptor = function(type, name, link_to_type, view_ids, require_refresh)
	{
		if (name != null)
		{
			var obj_descr = get_object_descriptor(type);
			var new_field_descr = new field_descriptor(type, name, link_to_type, view_ids, require_refresh);
			var old_field_desct = obj_descr.fields[name];
			if (old_field_desct == null)
				obj_descr.fields[name] = new_field_descr;
			else
			{
				old_field_desct.link_to_types = old_field_desct.link_to_types.concat(new_field_descr.link_to_types);
				old_field_desct.require_refresh = old_field_desct.require_refresh || new_field_descr.require_refresh;
				old_field_desct.cascade_refresh = old_field_desct.cascade_refresh || new_field_descr.cascade_refresh;
			}
		}
	}

	var add_direct_link = function(from_type, to_type, link_field, view_ids, refresh_required)
	{
		add_field_descriptor(from_type, link_field, to_type, view_ids, refresh_required);
		var link = new direct_link_description(from_type, to_type, link_field);
		links[get_link_index(from_type, to_type)] = link;
	}

	this.get_link_index = get_link_index;

	/**
	Adds direct link definition
	@param {String}from_type Name of the first items type that linked to second items type
	@param {String}to_type Name of the second items type
	@param {String} link_field Filed of first type that stores ID of linked object of second type
	@param {Array[String]} view_ids Arroy of view IDs that can be used in salesbooks
	@param {Boolean} [refresh_required=False] Refresh is required for primary association
	@param {String} [primary_field] Field for primary association
	@param {String} [status] Status field
	@param {Boolean} [primary_require_refresh=False] Refresh is required for primary association
	*/
	this.add_direct_link = function(from_type, to_type, link_field, view_ids, refresh_required, primary_field, status, primary_require_refresh)
	{
		add_direct_link(from_type, to_type, link_field, view_ids, refresh_required);

		var primary_link_description = null;
		if (primary_field != null)
		{
			add_field_descriptor(to_type, primary_field, from_type, null, primary_require_refresh);
			primary_link_description = new direct_link_description(to_type, from_type, primary_field);
		}
		mvg_associations[get_link_index(to_type, from_type)] = new mvg_association_object_description(from_type, link_field, null, null, status);
		links[get_link_index(to_type, from_type)] = new mvg_link_description
			(to_type, from_type, from_type, primary_link_description, null);
	}

	/**
	Adds MVG link definition
	@param {String} left_type Name of the left items type
	@param {String} right_type Name of the right items type
	@param {String} left_obj_primary Filed of left type that stores ID of primary object of right type
	@param {String} right_obj_primary Filed of right type that stores ID of primary object of left type
	@param {String} assoc_type Name of the association items name
	@param {String} left_link Filed of association type that stores ID of object of left type
	@param {String} right_link Filed of association type that stores ID of object of rigth type
	@param [left_assoc_status] Filed of association type that stores status of link to left type
	@param [right_assoc_status] Filed of association type that stores status of link to right type
	@param {Array[String]} left_objs_view_ids Array of view ids for left items types
	@param {Array[String]} right_objs_view_ids Array of view ids for right items types
	@param {Boolean} left_primary_refresh_required Refresh is required for primary association for left type
	@param {Boolean} right_primary_refresh_required Refresh is required for primary association for right type
	@param {Boolean} assoc_left_link_refresh_required Refresh is required for link of association type to left type
	@param {Boolean} assoc_right_link_refresh_required Refresh is required for link of association type to rigth type
	*/
	this.add_mvg_link = function(left_type, right_type, left_obj_primary, right_obj_primary,
	                             assoc_type, left_link, right_link,
	                             left_assoc_status, right_assoc_status,
	                             left_objs_view_ids, right_objs_view_ids,
	                             left_primary_refresh_required, right_primary_refresh_required,
	                             assoc_left_link_refresh_required, assoc_right_link_refresh_required)
	{
		var assoc_descr = new mvg_association_object_description(assoc_type, left_link, right_link, left_assoc_status, right_assoc_status);
		mvg_associations[get_link_index(left_type, right_type)] = assoc_descr;
		mvg_associations[get_link_index(right_type, left_type)] = assoc_descr.get_reverted();

		var left_obj_primary_link_description = null;
		if (left_obj_primary != null)
		{
			add_field_descriptor(left_type, left_obj_primary, right_type, null, left_primary_refresh_required);
			left_obj_primary_link_description = new direct_link_description(left_type, right_type, left_obj_primary);
		}
		var right_obj_primary_link_description = null;
		if (right_obj_primary != null)
		{
			add_field_descriptor(right_type, right_obj_primary, left_type, null, right_primary_refresh_required);
			right_obj_primary_link_description = new direct_link_description(right_type, left_type, right_obj_primary);
		}

		var link = new mvg_link_description(left_type, right_type, assoc_type, left_obj_primary_link_description, right_obj_primary_link_description);
		links[get_link_index(left_type, right_type)] = link;
		links[get_link_index(right_type, left_type)] = link.get_reverted();
		add_direct_link(assoc_type, left_type, left_link, left_objs_view_ids, assoc_left_link_refresh_required);
		add_direct_link(assoc_type, right_type, right_link, right_objs_view_ids, assoc_right_link_refresh_required);
	}

	/**
	Defines view methon
	@param {Array[String]} types List of linked types
	@param {String} method View method. Can be:
	<b>"native"</b> - Item have own form to display
	<b>"disabled</b> - Item cannot be dispayed
	Any other value means that item will be opened on dialog.
	*/
	this.set_view_method = function(types, method)
	{
		for (var enm = new Enumerator(types); !enm.atEnd(); enm.moveNext())
			get_object_descriptor(enm.item()).view_method = method;
	}

	/**
	Returns Enumerator for objects types definition list
	@returns Enumerator
	*/
	this.get_objects_enumerator = function()
	{
		return new Enumerator(objects);
	}

	/**
	Returns object definition for specified objects type
	@param type Object type
	@returns Object definition, null if not defined
	*/
	this.get_object_descriptor = function(type)
	{
		return objects[type];
	}

	/**
	Returns Enumerator for links definition list
	@returns Enumerator
	*/
	this.get_links_enumerator = function()
	{
		return new Enumerator(links);
	}

	/**
	Returns link definition for specified types
	@param from_type First type
	@param to_type Second type
	@returns Link definition, null if not defined
	*/
	this.get_link_description = function(from_type, to_type)
	{
		return links[get_link_index(from_type, to_type)];
	}

	/**
	Returns MVG primary link definition for specified types
	@param from_type First type
	@param to_type Second type
	@returns Link definition, null if not defined
	*/
	this.get_mvg_link_primary_description = function(from_type, to_type)
	{
		var link = this.get_link_description(from_type, to_type);
		if (link != null && link.link_type == "mvg")
		{
			var left_obj_primary_link = link.left_obj_primary_link;
			if (left_obj_primary_link != null)
				return left_obj_primary_link;
		}
		return null;
	}

	/**
	Returns MVG primary link field name definition for specified types
	@param from_type First type
	@param to_type Second type
	@returns Field name, null if not defined
	*/
	this.get_mvg_link_primary_field_name = function(from_type, to_type)
	{
		var primary_link = this.get_mvg_link_primary_description(from_type, to_type);
		return primary_link != null ? primary_link.field_name : null;
	}

	/**
	Sets custom filter for MVG dialogs
	@param {String} type Type name
	@param filter Custom filter
	*/
	this.set_custom_filter = function(type, filter)
	{
		filters[type] = filter;
	}

	/**
	Gets custom filter for MVG dialogs
	@param {String} type Type name
	@returns Custom filter, null if not set
	*/
	this.get_custom_filter = function(type)
	{
		return filters[type];
	}
}

/**
@class Helper class for creating MVG links
@constructor
@param {session} session Session object provided by C++
@param {idle.primary_value_updater} primary_updater Primary value updater
@param {helpers.save_helper} item_saver Items saving helper
@param {String} type Association items type
@param {String} link_fld Field of association type that stores ID of object of left type
@param {String} right_link_fld Field of association type that stores ID of object of secong type
@param {String} [right_obj_status] Filed of association type that stores status of link to second type
@param {String} [left_obj_status] Filed of association type that stores status of link to first type
@param {String} [right_primary_fld] Filed of right type that stores ID of primary object of left type
@memberOf data_model
@deprecated
*/
function mvg_objects_link_helper(session, primary_updater, item_saver, type, link_fld, right_link_fld, right_obj_status, left_obj_status, right_primary_fld)
{
	var deleted_status = "deleted";
	var unsaved_status = "unsaved";
	var always_true_filter = session.create_criteria("or");
	var always_false_filter = session.create_expression(link_fld, "eq", session.hexstring_to_id("00"));

	this.type = type;
	this.deleted_status = deleted_status;
	this.unsaved_status = unsaved_status;
	this.left_link = link_fld;
	this.right_obj_status = right_obj_status;
	this.right_link = right_link_fld;
	this.right_status = left_obj_status;

	var get_current_obj_filter = function(parent)
	{
		var id = helpers.safe_get_id(parent);
		return id != null ? session.create_expression(link_fld, "eq", id) : always_false_filter;
	}

	var get_status_filter = function(status, reverse)
	{
		if (right_obj_status != null)
			return session.create_expression(right_obj_status, reverse ? "ne" : "eq", status);
		else
			return reverse ? always_true_filter : always_false_filter;
	}

	var get_right_obj_filter = function(right_obj_id)
	{
		if (right_link_fld == null)
			return always_true_filter;
		else
			return session.create_expression(right_link_fld, "eq", right_obj_id);
	}

	var get_saved_on_left_filter = function(saved)
	{
		if (left_obj_status == null)
			return saved ? always_true_filter : always_false_filter;
		else
			return session.create_expression(left_obj_status, saved ? "ne" : "eq", unsaved_status);
	}

	var empty_array = new Array();

	var get_deleted_items_enm = function(parent)
	{
		var filter = session.create_criteria("and");
		filter.add(get_current_obj_filter(parent));
		filter.add(get_status_filter(deleted_status));
		return new Enumerator(session.find_items(type, filter));
	}

	var get_unsaved_items_enm = function(parent)
	{
		var filter = session.create_criteria("and");
		filter.add(get_current_obj_filter(parent));
		filter.add(get_status_filter(unsaved_status));
		return new Enumerator(session.find_items(type, filter));
	}

	var right_side_primary_equal_to = function(right_obj_id, value)
	{
		var result = false;
		if (primary_updater != null && right_primary_fld != null)
		{
			var obj = session.open_item(right_obj_id);
			if (obj != null)
			{
				var right_side_primary = obj[right_primary_fld];
				result = helpers.ids_equal(session, right_side_primary, value);
			}
		}
		return result;
	}

	var delete_right_side_unsaved = function(parent, right_id)
	{
		if (left_obj_status != null)
		{
			var filter = session.create_criteria("and");
			filter.add(get_current_obj_filter(parent));
			filter.add(get_saved_on_left_filter(false));
			filter.add(get_right_obj_filter(right_id));
			var other_assoc = session.find_item(type, filter);
			if (other_assoc != null)
				return other_assoc.remove();
		}
	}

	var make_persistent = function(parent, assoc)
	{
		if (right_obj_status != null)
			assoc[right_obj_status] = "";
		if (right_link_fld == null)
		{
			if (assoc[left_obj_status] == unsaved_status)
				assoc[left_obj_status] = "";
		}
		save(assoc);
		if (right_link_fld != null)
			delete_right_side_unsaved(parent, assoc[right_link_fld]);
	}

	/**
	Revert unsaved changes in links
	@param parent Parent item
	*/
	this.revert = function(parent)
	{
		for (var deleted_enm = get_deleted_items_enm(parent); !deleted_enm.atEnd(); deleted_enm.moveNext())
			make_persistent(parent, deleted_enm.item());
		for (var unsaved_enm = get_unsaved_items_enm(parent); !unsaved_enm.atEnd(); unsaved_enm.moveNext())
			unsaved_enm.item().remove();
	}

	/**
	Apply unsaved changes in links
	@param parent Parent item
	*/
	this.apply = function(parent)
	{
		var parent_type = parent.type_id;
		var parent_id = parent.id;
		for (var deleted_enm = get_deleted_items_enm(parent); !deleted_enm.atEnd(); deleted_enm.moveNext())
		{
			var item = deleted_enm.item();
			var right_obj_id = this.get_assocaited_obj_id(item);
			item.remove();
			if (right_side_primary_equal_to(right_obj_id, parent_id))
				primary_updater.track_association_remove(right_obj_id, parent_type);
		}
		for (var unsaved_enm = get_unsaved_items_enm(parent); !unsaved_enm.atEnd(); unsaved_enm.moveNext())
		{
			var item = unsaved_enm.item();
			var right_obj_id = this.get_assocaited_obj_id(item);
			make_persistent(parent, item, true);
			if (right_side_primary_equal_to(right_obj_id, null))
				primary_updater.track_association_add(right_obj_id, parent_type);
		}
	}

	/**
	Prefill new item
	@param item New irem
	*/
	this.prefill_new = function(item)
	{
		if (right_obj_status != null)
			item[right_obj_status] = unsaved_status;
	}

	/**
	Mark item for delete
	@param item Item to mark
	*/
	this.mark_for_delete = function(item)
	{
		if (right_obj_status != null)
		{
			if (item[right_obj_status] == unsaved_status)
				item.remove();
			else
			{
				item[right_obj_status] = deleted_status;
				this.save(item);
			}
		}
	}

	/**
	Break association
	@param parent Parent item
	@param right_obj_id ID of linked item
	@param {Boolean} persistent If true, phisically remove association, else mark it for deletion
	@returns True if success
	*/
	this.unassociate = function(parent, right_obj_id, persistent)
	{
		var filter = session.create_criteria("and");
		filter.add(get_current_obj_filter(parent));
		filter.add(get_saved_on_left_filter(true));
		filter.add(get_right_obj_filter(right_obj_id));
		var assoc = session.find_item(type, filter);
		if (assoc != null)
		{
			if (persistent == true)
				assoc.remove();
			else
				this.mark_for_delete(assoc);
		}
		return assoc != null;
	}

	/**
	Associate items
	@param parent Parent item
	@param right_obj_id ID of item to link with parent item
	@param {Boolean} persistent Apply changes
	@returns Created association item
	*/
	this.associate = function(parent, right_obj_id, persistent)
	{
		var assoc = null;
		if (right_link_fld != null)
		{
			var filter = session.create_criteria("and");
			filter.add(get_current_obj_filter(parent));
			filter.add(get_saved_on_left_filter(true));
			filter.add(get_right_obj_filter(right_obj_id));
			assoc = session.find_item(type, filter);
		}
		if (assoc != null)
		{
			if (persistent == true)
				make_persistent(parent, assoc);
			else
			{
				if (assoc[right_obj_status] == deleted_status)
				{
					assoc[right_obj_status] = "";
					this.save(assoc);
				}
				else
					assoc = null;
			}
		}
		else
		{
			if (right_link_fld != null)
			{
				assoc = session.create_item(type);
				assoc["Created By MVG"] = true;
				assoc[right_link_fld] = right_obj_id;
			}
			else
				assoc = session.open_item(right_obj_id);
			assoc[link_fld] = parent.id;
			if (persistent == true)
				make_persistent(parent, assoc);
			else
				this.prefill_new(assoc);
			this.save(assoc);
		}
		return assoc;
	}

	var get_saved_filter = function(parent, right_obj_id, saved)
	{
		var filter = session.create_criteria("and");
		filter.add(get_current_obj_filter(parent));
		if (right_obj_id != null)
			filter.add(get_right_obj_filter(right_obj_id));
		filter.add(get_saved_on_left_filter(true));
		filter.add(get_status_filter(saved ? unsaved_status : deleted_status, true));
		return filter;
	}

	/**
	Returns ID of associated item
	@param assoc Association item
	@returns Associated item ID
	*/
	var get_assocaited_obj_id = function(assoc)
	{
		return right_link_fld != null ? assoc[right_link_fld] : assoc.id;
	}

	var get_associated_ids = function(parent, right_obj_id, saved)
	{
		var result = new Array();
		if (right_link_fld == null && right_obj_id != null)
		{
			var item = session.open_item(right_obj_id);
			if (item != null && !helpers.ids_equal(session, item[link_fld], parent.id))
				item = null;
			if (item != null && item[left_obj_status] != unsaved_status)
			{
				if ((saved && item[right_obj_status] != unsaved_status)
				    || (!saved && item[right_obj_status] != deleted_status))
					result.push(right_obj_id);
			}
		}
		else
		{
			for (var enm = new Enumerator(session.find_items(type, get_saved_filter(parent, right_obj_id, saved))); !enm.atEnd(); enm.moveNext())
			{
				var item = enm.item();
				result.push(get_assocaited_obj_id(item));
			}
		}
		return result;
	}

	/**
	Creates and returns filter to that describes actual state
	@returns Filter object
	*/
	this.get_actual_state_filter = function()
	{
		var filter = session.create_criteria("and");
		filter.add(get_saved_on_left_filter(true));
		filter.add(get_status_filter(deleted_status, true));
		return filter;
	}

	/**
	Returns first found associated item
	@param parent Parent item
	@returns Associated item, null if not found
	*/
	this.get_any_associated = function(parent)
	{
		var item = session.find_item(type, get_saved_filter(parent, null, false))
		if (item == null)
			return null
		else
			return this.get_assocaited_obj_id(item);
	}

	/**
	Returns ID of first found associated item
	@param parent Parent item
	@returns Object id, null if not found
	*/
	this.get_any_saved_associated_id = function(parent)
	{
		var item = session.find_item(type, get_saved_filter(parent, null, true))
		if (item == null)
			return null
		else
			return this.get_assocaited_obj_id(item);
	}

	/**
	Returns IDs of associated objects
	@param parent Parent item
	@param [right_obj_id] ID of right object
	@returns Array of items IDs
	*/
	this.get_associated_ids = function(parent, right_obj_id)
	{
		return get_associated_ids(parent, right_obj_id, false);
	}

	/**
	Returns IDs of saved associated objects
	@param parent Parent item
	@param [right_obj_id] ID of right object
	@returns Array of items IDs
	*/
	this.get_saved_associated_ids = function(parent, right_obj_id)
	{
		return get_associated_ids(parent, right_obj_id, true);
	}

	/**
	Returns ID of associated item
	*/
	this.get_assocaited_obj_id = get_assocaited_obj_id;

	var own_save = function(item, silent)
	{
		if (silent == true)
			item.silent_save();
		else
			item.save();
	}

	/**
	Saves item
	@param item Item to save
	*/
	this.save = function(item)
	{
		if (item_saver != null)
			item_saver.save_and_disable_events(item, true);
		else
			own_save(item, true);
	}

	var save = this.save;
}

/**
@class Class that performs applying associations changes on item saved event and provides interface for apply/revert all changes manually
@constructor
@param helpers Array of helpers
@param {form} form Outlook form object
@memberOf data_model
@deprecated
*/
function objects_link_group(helpers, form)
{
	/**
	Applyes associations changes
	@param item Item
	*/
	this.apply = function(item)
	{
		auto_apply(item);
	}

	/**
	Reverts associations changes
	@param item Item
	*/
	this.revert = function(item)
	{
		if (item == null)
			item = form.item;
		for (var enm = new Enumerator(helpers); !enm.atEnd(); enm.moveNext())
			enm.item().revert(item);
	}

	this.get = function(key)
	{
		return helpers[key];
	}

	var auto_apply = function(item)
	{
		if (item == null)
			item = form.item;
		for (var enm = new Enumerator(helpers); !enm.atEnd(); enm.moveNext())
			enm.item().apply(item);
	}

	if (form != null)
	{
		form.on_saved.connect(auto_apply);
		this.revert();
	}
}

function objects_linker_facrory(session, item_saver, primary_updater, meta_scheme)
{
	var cache = new Array();

	var create = function(from_type, to_type)
	{
		var link_descr = meta_scheme.get_link_description(from_type, to_type);
		if (link_descr != null && link_descr.link_type == "mvg")
		{
			var association_descr = link_descr.get_association_description();

			return new mvg_objects_link_helper(session, primary_updater, item_saver,
				association_descr.type, association_descr.left_link, association_descr.right_link,
				association_descr.right_assoc_status, association_descr.left_assoc_status,
				meta_scheme.get_mvg_link_primary_field_name(to_type, from_type));
		}
		return null;
	}

	this.create = function(from_type, to_type)
	{
		var link_index = meta_scheme.get_link_index(from_type, to_type);
		if (cache[link_index] == null)
			cache[link_index] = create(from_type, to_type);
		return cache[link_index];
	}

	this.create_group = function(form, to_types, from_type)
	{
		if (from_type == null)
			from_type = form.item.type_id;
		var helpers = new Array();
		for (var key in to_types)
		{
			var to_type = to_types[key];
			helpers[to_type] = this.create(from_type, to_type);
		}
		return new objects_link_group(helpers, form);
	}
}

function objects_linker(application, item_saver, primary_updater, meta_scheme)
{
	var session = application.session;
	var factory = new objects_linker_facrory(session, item_saver, primary_updater, meta_scheme);
	this.mvg_objects_linker_factory = factory;

	var put_required_fields = function(obj, fields)
	{
		var result = false;
		if (fields != null)
			for (var key in fields)
		{
			obj[key] = fields[key];
			result = true;
		}
		return result;
	}

	var link_by_direct = function(ctx, object, link_with_id, link_description, options, push_unsuccess)
	{
		var field = link_description.field_name;
		if (ctx.fields_set[field] != true && object[field] == null)
		{
			if (ctx.associations_only != true)
			{
				ctx.fields_set[field] = true;
				object[field] = link_with_id;
				var prefill_array = options.required_field_values;
				if (prefill_array == null)
					prefill_array = link_description.required_field_values;
				put_required_fields(object, prefill_array);
			}
		}
		else if (push_unsuccess)
		{
			ctx.unlinked_ids.push(link_with_id);
			ctx.unlinked_ids_options.push(options);
		}
	}

	this.link = function(object, link_with_array, persistent, options)
	{
		var ctx = new Object();
		ctx.unlinked_ids = new Array();
		ctx.unlinked_ids_options = new Array();
		ctx.unlinked_because_of_absent_id = new Array();
		ctx.unlinked_because_of_absent_id_options = new Array();
		ctx.fields_set = new Array();

		if (persistent == "associations_only")
		{
			ctx.associations_only = true;
			persistent = true;
		}

		var object_id = false;
		var object_type = object.type_id;
		var enm = new Enumerator(link_with_array);
		var options_enm = new Enumerator(options != null ? options : new Array());
		for (; !enm.atEnd(); enm.moveNext())
		{
			var option = null;
			if (!options_enm.atEnd())
			{
				option = options_enm.item();
				options_enm.moveNext();
			}
			if (option == null)
				option = new Object();

			var link_with_id = enm.item();
			var link_with = session.open_item(link_with_id);
			var link_with_type = link_with.type_id;
			var link_description = meta_scheme.get_link_description(object_type, link_with_type);

			if (link_description != null)
			{
				if (link_description.link_type == "direct")
					link_by_direct(ctx, object, link_with_id, link_description, option, true);
				else if (link_description.link_type == "mvg")
				{
					if (object_id == false)
						object_id = helpers.safe_get_id(object);
					if (object_id != null)
					{
						var helper = factory.create(object_type, link_with_type);
						var association = helper.associate(object, link_with_id, persistent);
						var prefill_array = option.required_association_field_values;
						if (prefill_array == null)
							prefill_array = link_description.required_field_values;
						if (put_required_fields(association, prefill_array))
							helper.save(association);
					}
					else
					{
						ctx.unlinked_because_of_absent_id.push(link_with_id);
						ctx.unlinked_because_of_absent_id_options.push(option);
					}
					var left_obj_primary_link = link_description.left_obj_primary_link;
					if (left_obj_primary_link != null && left_obj_primary_link.prefill_for_first_association == true || option.primary == true)
						link_by_direct(ctx, object, link_with_id, left_obj_primary_link, option, false);
				}
			}
			else
			{
				ctx.unlinked_ids.push(link_with_id);
				ctx.unlinked_ids_options.push(option);
			}
		}
		if (persistent == true && !(new Enumerator(ctx.fields_set).atEnd() && new Enumerator(ctx.unlinked_because_of_absent_id).atEnd()))
		{
			item_saver.save_and_disable_events(object);
			this.link(object, ctx.unlinked_because_of_absent_id, "associations_only", ctx.unlinked_because_of_absent_id_options);
			ctx.unlinked_because_of_absent_id = new Array();
			ctx.unlinked_because_of_absent_id_options = new Array();
		}
		if (options == null)
			return ctx.unlinked_ids.concat(ctx.unlinked_because_of_absent_id);
		else
			return { "ids": ctx.unlinked_ids.concat(ctx.unlinked_because_of_absent_id), "options": ctx.unlinked_ids_options.concat(ctx.unlinked_because_of_absent_id_options) };
	}

	this.unlink = function(object, link_with_array, persistent)
	{
		var update_primary = new Array();
		var unlinked_ids = new Array();

		var object_type = object.type_id;
		var enm = new Enumerator(link_with_array);
		for (; !enm.atEnd(); enm.moveNext())
		{
			var link_with_id = enm.item();
			var link_with = session.open_item(link_with_id);
			var link_with_type = link_with.type_id;
			var link_description = meta_scheme.get_link_description(object_type, link_with_type);

			if (link_description != null && link_description.link_type == "mvg")
			{
				var helper = factory.create(object_type, link_with_type);
				if (helper.unassociate(object, link_with_id, persistent))
				{
					var left_obj_primary_link = link_description.left_obj_primary_link;
					if (left_obj_primary_link != null)
					{
						var field = left_obj_primary_link.field_name;
						if (update_primary[field] == null)
						{
							var selected_primary = object[field];
							if (helpers.ids_equal(session, selected_primary, link_with_id))
							{
								var ctx = new Object();
								ctx.helper = helper;
								ctx.link_descr = left_obj_primary_link;
								update_primary[field] = ctx;
							}
						}
					}
				}
				else
					unlinked_ids.push(link_with_id);
			}
			else
				unlinked_ids.push(link_with_id);
		}
		if (!new Enumerator(update_primary).atEnd())
		{
			for (var key in update_primary)
			{
				var ctx = update_primary[key];
				var value = null;
				if (ctx.link_descr.prefill_for_first_association == true)
				{
					var helper = ctx.helper;
					value = persistent == true ? helper.get_any_saved_associated_id(object) : helper.get_any_associated(object);
				}
				object[key] = value;
			}
			if (persistent == true)
				item_saver.save_and_disable_events(object);
		}
		return unlinked_ids;
	}
}

function new_item_prefiller(application, shared_objects, required_items, form, item)
{
	var session = application.session;

	var item_saver = shared_objects.item_saver;
	var primary_updater = shared_objects.primary_updater;
	var meta_scheme = shared_objects.meta_scheme;
	var cfp_manager = shared_objects.cfp_manager;

	var saved_handler = function()
	{
		if (link_result != null && link_result.ids.length > 0)
		{
			var res = link_result;
			link_result = null;
			linker.link(item, res.ids, true, res.options);
		}
		if (cfp_descriptor != null && cfp_descriptor.post_save_action_required == true)
		{
			var cfp_copy = cfp_descriptor;
			cfp_descriptor = null;
			try
			{
				cfp_copy.form_saved(form, item, linker, meta_scheme);
			}
			catch (e)
			{
			}
		}
	}

	if (item == null)
		item = form.item;

	var cfp_descriptor = cfp_manager != null ? cfp_manager.retrieve_item_descriptor(item) : null;
	this.cfp_descriptor = cfp_descriptor;

	var linker = new objects_linker(application, item_saver, primary_updater, meta_scheme);

	var linked_items = new Array();
	var linked_items_options = new Array();

	var fix_options_length = function()
	{
		while (linked_items_options.length < linked_items.length)
			linked_items_options.push(null);
	}

	if (required_items != null)
	{
		linked_items = linked_items.concat(required_items);
		fix_options_length();
	}
	if (cfp_descriptor != null)
	{
		if (cfp_descriptor.linked_items != null)
		{
			linked_items = linked_items.concat(cfp_descriptor.linked_items);
			if (cfp_descriptor.options != null)
				linked_items_options = linked_items_options.concat(cfp_descriptor.options);
			fix_options_length();
		}
		if (cfp_descriptor.prefill_required == true)
			cfp_descriptor.prefill(form, item, linker, meta_scheme);
	}

	var link_result = linker.link(item, linked_items, false, linked_items_options);

	if (form != null && (link_result.ids.length > 0 || (cfp_descriptor != null && cfp_descriptor.post_save_action_required == true)))
		form.on_saved.connect(saved_handler);

	this.save_unsaved = function()
	{
		saved_handler();
	}
}

// Version 2
/**
@class Class that stores information about field. 
Usually no need to create this class because {@link data_model.object_descriptor#get_field} method perform this silently if field_descriptor absent.
@constructor
@param parent Object descriptor to which this field_descriptor belongs
@param name Name of field
@memberOf data_model
*/
function field_descriptor(parent, name)
{
	/**
	Name of field that is described by current object
	*/
	this.name = name;

	/**
	Object descriptor to which this field_descriptor belongs
	@type data_model.object_descriptor
	*/
	this.parent = parent;

	/**
	Add information that this field can be link to another object. This information is required to refresh field values that was copied from another object.
	@param {String} link_to Type of object link to which can this field retain.
	@param {Variant} refresh True value indicates that this field should be refreshed after change of object to which value of this field points. 
		"cascade" value indicates that after refreshing of this field in some object it is required to begin refresh operation of all fields that points to that object.
	*/
	this.set_link = function(link_to, refresh)
	{
		if (this.link_to == null)
			this.link_to = [];
		this.link_to.push(link_to);

		this.link_refresh_cascade = this.link_refresh_cascade == true || refresh == "cascade";
		this.link_refresh_required = this.link_refresh_required == true || this.link_refresh_cascade || refresh == true;
	}
}

/**
@class Class that stores information about object type. 
Usually no need to create this class because {@link data_model.objects_model#get_object} method perform this silently if object_descriptor absent.
@constructor
@param {String} Name of object type that this descriptor describes.
@memberOf data_model
*/
function object_descriptor(type)
{
	/**
	Name of type that is described by current object
	*/
	this.type = type;
	var fields = [];

	/**
	Return field descriptor. If descriptor is absent new descriptor created and returned
	@param {String} name Name of field.
	@return Field descriptor
	@type data_model.field_descriptor
	*/
	this.get_field = function(name)
	{
		var field = fields[name];
		if (field == null)
			fields[name] = new field_descriptor(this, name);
		return fields[name];
	}

	/**
	Set field descriptor.
	@param {String} name Name of field.
	@param {Object} descriptor Descriptor of field.
	*/
	this.set_field = function(name, descriptor)
	{
		fields[name] = descriptor;
	}

	/**
	Performs function for each descriptor.
	@param {Function} f Function with signature f(field_descriptor) that will be called for each field descriptor.
	*/
	this.for_each_field = function(f)
	{
		helpers.for_each(fields, f);
	}
}

/**
@class Object this call is part of Data Model and stores all object descriptors. 
@constructor
@memberOf data_model
*/
function objects_model()
{
	var objects = [];

	/**
	Return type descriptor. If descriptor is absent new descriptor created and returned
	@param {String} type Type of object descriptor for which should be returned.
	@return Descriptor of requested type
	@type data_model.object_descriptor
	*/
	this.get_object = function(type)
	{
		var obj = objects[type];
		if (obj == null)
			objects[type] = new object_descriptor(type);
		return objects[type];
	}

	/**
	Set object descriptor descriptor.
	@param {String} type Type of object descriptor for each should be set.
	@param {Object} descriptor Descriptor of object type.
	*/
	this.set_object = function(type, descriptor)
	{
		objects[type] = descriptor;
	}

	/**
	Performs function for each descriptor.
	@param {Function} f Function with signature f(object_descriptor) that will be called for each field descriptor.
	*/
	this.for_each_object = function(f)
	{
		helpers.for_each(objects, f);
	}
}

/**
@class Data model of current application. 
@constructor
@memberOf data_model
*/
function data_model()
{
	/**
	Objects of this Data Model
	@type data_model.objects_model
	*/
	this.objects = new objects_model();

	/**
	Links of this Data Model
	@type data_model.objects_model
	*/
	this.links = new links_model();

	/**
	Triggers of this Data Model
	@type data_model.objects_model
	*/
	this.triggers = new triggers();
}

/**
@private
*/
function like_cached_container(fields, reverted_compare)
{
	var items = [];
	var cache;

	this.reset = function()
	{
		cache = {};
	}
	this.reset();

	this.add = function(item)
	{
		items.push(item);
		this.reset();
	}

	this.get_sub = function(criteria)
	{
		var key = get_key(criteria);
		if (cache[key] == null)
		{
			var result = [];
			helpers.for_each2(items, function(item){
				if (like(item, criteria))
					result.push(item);
			});
			cache[key] = result;
		}
		return cache[key];
	}

	function like(what_ctx, criteria)
	{
		if (reverted_compare)
		{
			var x = what_ctx;
			what_ctx = criteria;
			criteria = x;
		}
		var result = true;
		helpers.for_each(fields, function(field, param, for_each_ctx){
			result = result && (criteria[field] == null || criteria[field] == what_ctx[field]);
			for_each_ctx.interrupted = !result;
		});
		return result;
	}

	function get_key(criteria)
	{
		var result = "";
		helpers.for_each(fields, function(field){ result += "/" + (criteria[field] == null ? "null" : criteria[field]); });
		return result;
	}
}

/**
@class Object that is a part of Data Model and stores all links. 
@constructor
@memberOf data_model
*/
function links_model()
{
	var links = new like_cached_container(["type", "link_to", "tag"]);

	/**
	Add link. 
	@param {data_model.link} link link to be added
	*/
	this.add_link = function(link)
	{
		links.add(link);
	}

	/**
	Search for link using given criteria. 
	@param {data_model.get_link_criteria} criteria Search criteria
	@return Return structure that describes search result.
	@type data_model.get_link_result
	*/
	this.get_link = function(criteria)
	{
		var found_links = links.get_sub(criteria);
		var result = { "success": found_links.length == 1 };
		if (result.success)
			result.link = found_links[0];
		else
			result.reason = found_links.length == 0 ? "absent" : "ambiguous";
		return result;
	}

	/**
	Executes operation for each link that match given criteria. 
	@param {data_model.get_link_criteria} criteria Search criteria
	@param {Function} f function with signature f(link) that should be called for each link matching criteria.
	*/
	this.for_each = function(criteria, f)
	{
		helpers.for_each2(links.get_sub(criteria), f);
	}
}

/**
@class Object that is a part of Data Model and stores all triggers. 
@constructor
@memberOf data_model
*/
function triggers()
{
	var triggers = new like_cached_container(["type", "link_to", "tag", "operation"], true);

	/**
	Add trigger. 
	@param {data_model.trigger} trigger Trigger to be added
	*/
	this.add_trigger = function(trig)
	{
		triggers.add(trig);
	}

	/**
	Constructs {@link data_model.trigger} with given callback and criteria values.
	@param {Function} handler Function that will be called when trigger called.
	@param {String} type Type on which trigger shoul be called.
	@param {String} link_to Link to value on which trigger shoul be called.
	@param {String} tag Tag on which trigger shoul be called.
	@param {String} operation Operation on which trigger shoul be called.
	@return Returns just contstucted trigger.
	@type data_model.trigger
	*/
	this.add_simple_trigger = function(handler, type, link_to, tag, operation)
	{
		var trigger = { "type": type, "link_to": link_to, "tag": tag, "operation": operation, "handler": handler };
		this.add_trigger(trigger);
		return trigger;
	}

	/**
	Call all triggers that subscribed for given action_ctx options.
	@param {platform_scripts.ctx} ctx This ctx will be passed argument for triggers.
	@param {data_model.trigger_action_ctx} action_ctx This param used to determine which triggers should be called and used as argument for triggers.
	*/
	this.call = function(ctx, action_ctx)
	{
		helpers.for_each2(triggers.get_sub(action_ctx), function(trigger) { trigger.handler(ctx, action_ctx); });
	}
}

/**
@class Objects of this class create bindings, returns existent bindings and performs submit/revert operation using links from links_model.
@constructor
@memberOf data_model
*/
function objects_linker2(ctx)
{
	var application = ctx.application;
	var session = ctx.session;
	var links = ctx.links != null ? ctx.links : ctx.data_model.links;
	var triggers = ctx.triggers != null ? ctx.triggers : ctx.data_model.triggers;

	ctx.linker = this;

	var spec_ctx = function(link_ctx)
	{
		this.item_ex = link_ctx.item_ex;
		this.with_id = link_ctx.with_id;
		this.params = link_ctx.params;
		this.submited = link_ctx.submited;

		var type = link_ctx.item_ex.get_type();
		var link = null;
		var tag = link_ctx.tag;

		var find_link = function()
		{
			if (link_ctx.link_to == null && link_ctx.with_id != null)
			{
				var with_item = ctx.session.open_item(link_ctx.with_id);
				if (with_item != null)
					link_ctx.link_to = with_item.type_id;
			}
			link = links.get_link({ "type": type, "link_to": link_ctx.link_to, "tag": link_ctx.tag }).link;
		}

		this.notify = function(operation, notification_params)
		{
			triggers.call(ctx,
			{
				"type": type,
				"link_to": link != null ? link.link_to : link_ctx.link_to,
				"tag": link != null ? link.tag : tag,
				"operation": operation,
				"item_ex": link_ctx.item_ex,
				"with_id": link_ctx.with_id,
				"params": link_ctx.params,
				"submited": link_ctx.submited,
				"result": result,
				"notification_params": notification_params
			});
		}

		var result = null;

		this.fn1 = function(name, pre_op, post_op)
		{
			find_link();
			var notify_params = {};
			this.notify(pre_op, notify_params);

			if (link == null)
				result = { "reason": "no_link" };
			else if (link.id_required && this.item_ex.get_id() == null)
				result = { "reason": "id_expected" };
			else
			{
				if (notify_params.cancel != true && notify_params.cancel_reason == null)
				{
					result = link[name](ctx, this);
					result = result;
				}
				else
					result = { "reason": notify_params.cancel_reason != null ? notify_params.cancel_reason : "cancelled" };
			}
			compl_success(result);
			this.notify(post_op, notify_params);
			return result;
		}

		this.fn2 = function(name)
		{
			find_link();
			var result = link != null ? link[name](ctx, this) : { "reason": "no_link" };
			compl_linked_result(result);
			return result;
		}

		this.fn3 = function(name)
		{
			var _this = this;
			function f(item)
			{
				if (item[name] != null)
				{
					link = item;
					item[name](ctx, _this);
				}
			}
			links.for_each({ "type": type }, f);
		}

		var compl_success = function(result)
		{
			if (result.success == null)
				result.success = (result.reason == null);
		}

		var compl_linked_result = function(result)
		{
			if (result.values == null)
			{
				result.values = [];
				if (result.value != null)
					result.values.push(result.value);
			}
			if (result.count == null)
				result.count = result.values.length;
			if (result.value === undefined && result.count < 2)
				result.value = result.count == 1 ? result.values[0] : null;
		}
	}

	/**
	@private
	*/
	this.get_notifier = function(link_ctx)
	{
		return new spec_ctx(link_ctx);
	}

	/**
	Searches for appropriate link and creates binding
	@param {platform_scripts.ctx} ctx General ctx.
	@param {data_model.link_spec_ctx} link_ctx Defines values required to find link and to create binding. "item_ex", "with_id" and "tag" fields used to find link, also "link_to" can be used if object with specified "with_id" cannot be opened.
	@return Result of operation
	@type data_model.link_result_cr
	*/
	this.link = function(link_ctx)
	{
		return this.get_notifier(link_ctx).fn1("create", "creating", "created");
	}

	/**
	Searches for appropriate link and remove binding
	@param {platform_scripts.ctx} ctx General ctx.
	@param {data_model.link_spec_ctx} link_ctx Defines values required to find link and to remove binding. "item_ex", "with_id" and "tag" fields used to find link, also "link_to" can be used if object with specified "with_id" cannot be opened.
	@return Result of operation
	@type data_model.link_result_cr
	*/
	this.unlink = function(link_ctx)
	{
		return this.get_notifier(link_ctx).fn1("remove", "removing", "removed");
	}

	/**
	Searches for appropriate link and return linked by it objects
	@param {platform_scripts.ctx} ctx General ctx.
	@param {data_model.link_spec_ctx} link_ctx Defines values required to find link and perform operation. "item_ex", "link_to" and "tag" fields used to find link.
	@return Result of operation
	@type data_model.link_result_lk
	*/
	this.linked = function(link_ctx)
	{
		return this.get_notifier(link_ctx).fn2("linked");
	}

	/**
	Submits all non-submitted bindings of given object.
	@param {platform_scripts.ctx} ctx General ctx.
	@param {data_model.link_spec_ctx} link_ctx Defines values required to find links and perform operations. "item_ex" field used to find links.
	*/
	this.submit = function(link_ctx)
	{
		this.get_notifier(link_ctx).fn3("submit");
	}

	/**
	Deletes all non-submitted bindings of given object.
	@param {platform_scripts.ctx} ctx General ctx.
	@param {data_model.link_spec_ctx} link_ctx Defines values required to find links and perform operations. "item_ex" field used to find links.
	*/
	this.revert = function(link_ctx)
	{
		this.get_notifier(link_ctx).fn3("revert");
	}
}


/**
@class Implementation of item_ex
@param {Object} item Original item that have to be wrapped by this item_ex
@param {data_model.std_item_ex_options} options Options that defines behavior of item_ex
@constructor
@extends data_model.item_ex
@memberOf data_model
*/
function std_item_ex(item, options)
{
	options = helpers.merge_contexts({
		"use_snapshot": false,
		"lazy_save": true,
		"set_property_only_if_different": false
	}, options);
	options.use_snapshot = options.use_snapshot && item.type_id != "Mail";

	this.fcd_item = item;
	this.item_ex_type = "std_item_ex";

	/**
	True value indicates that at list property was set.
	@type bool
	*/
	this.dirty;

	/**
	True value indicates that "save" method was called while "lazy_save" is true.
	@type bool
	*/
	this.save_called;

	var cache;

	this.reset = function()
	{
		cache = {
			"id": false,
			"field_values": {}
		};
		this.dirty = false;
		this.save_called = false;
	}
	this.reset();

	this.get_id = function()
	{
		if (cache.id == false)
			cache.id = helpers.safe_get_id(item);
		return cache.id;
	}

	this.get_type = function()
	{ return item.type_id; }

	this.save = function()
	{
		if (options.lazy_save)
		{
			this.save_called = true;
			return true;
		}
		else
		{
			var result = helpers.save_item(item);
			this.reset();
			return result;
		}
	}

	this.get_property = function(name)
	{
		if (cache.field_values[name] !== undefined)
			return cache.field_values[name];
		if (cache.snapshot == null)
			cache.snapshot = options.use_snapshot ? item.snapshot : item;
		return cache.snapshot[name];
	}

	this.set_property = function(name, value)
	{
		if (!options.set_property_only_if_different || !util.equal(this.get_property(name), value))
		{
			item[name] = value;
			cache.field_values[name] = value;
			this.dirty = true;
		}
	}
}


/**
Tries again all links that has error with reason "id_expected" with partially overridden {@link data_model.link_spec_ctx}.
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.link_result} link_results Array of link results.
@param {data_model.link_spec_ctx} override_options Any options possible in {@link data_model.link_spec_ctx} that will override options from {@link data_model.link_result#spec_ctx}.
@memberOf data_model
*/
function after_save_link(ctx, link_results, override_options)
{
	function f(link_result)
	{
		if (link_result.result.reason == "id_expected")
			link_result.result = ctx.linker.link(helpers.merge_contexts(link_result.spec_ctx, helpers.merge_contexts(override_options)));
	}
	helpers.for_each(link_results, f);
}

/**
Analize link results for errors with reason "id_expected".
@param {data_model.link_result} link_results Array of link results.
@return Result of search of link errors with reason "id_expected".
@type bool
@memberOf data_model
*/
function is_id_expected_error(link_results)
{
	var result = false;
	function f(link_result, param, for_each_ctx)
	{
		result = link_result.result.reason == "id_expected";
		for_each_ctx.interrupted = result;
	}
	helpers.for_each(link_results, f);
	return result;
}

/**
Performs initialization of item by setting of initial property values and create initial bindings. Also creates item if it not passed as option of "create_ctx".
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.prefill_item_create_ctx} create_ctx Ctx with data required for create and/or initialization.
@return Struct that contain result of create initialization
@type data_model.prefill_item_result
@memberOf data_model
*/
function prefill_item(ctx, create_ctx)
{
	if (create_ctx.item_ex == null)
	{
		if (create_ctx.item == null)
			create_ctx.item = ctx.session.create_item(create_ctx.type);
		create_ctx.item_ex = new std_item_ex(create_ctx.item);
	}
	if (create_ctx.type == null)
		create_ctx.type = create_ctx.item_ex.get_type();
	var result =
	{
		"item": create_ctx.item,
		"item_ex": create_ctx.item_ex,
		"link_results": []
	};
	var object_descriptor = ctx.data_model.objects.get_object(create_ctx.type);
	function prefill_field(fld)
	{
		var value;
		if (fld.initial_value != null)
			value = fld.initial_value;
		if (fld.initial_value_res != null)
			value = ctx.session.res_string(fld.initial_value_res);
		if (fld.initial_value_fn != null)
			value = fld.initial_value_fn(ctx);
		if (value !== undefined)
			result.item_ex.set_property(fld.name, value);
	}
	object_descriptor.for_each_field(prefill_field);
	var static_spec_ctx = helpers.get_restricted_context(create_ctx, ["item_ex", "submited"]);
	var initial_links = object_descriptor["initial_links"];
	if (object_descriptor["initial_links_fn"] != null)
		initial_links = object_descriptor["initial_links_fn"](ctx);
	if (create_ctx.notification_params != null)
	{
		helpers.for_each(create_ctx.notification_params.fields, prefill_field);
		var additional_links = create_ctx.notification_params["initial_links"];
		if (additional_links != null)
			initial_links = initial_links != null ? initial_links.concat(additional_links) : additional_links;
	}
	if (initial_links != null)
	{
		function f2(spec_ctx)
		{
			var link_result = { "spec_ctx": helpers.merge_contexts(spec_ctx) };
			helpers.merge_contexts(static_spec_ctx, link_result.spec_ctx);
			link_result.result = ctx.linker.link(link_result.spec_ctx);
			result.link_results.push(link_result);
		}
		helpers.for_each2(initial_links, f2);
	}

	if (create_ctx.submited)
	{
		if (result.item_ex.item_ex_type == "std_item_ex")
		{
			ctx.save(result.item);
			result.item_ex.reset();
		}
		else if (result.item_ex.get_id() == null)
			result.item_ex.save();
		after_save_link(ctx, result.link_results);
	}
	return result;
}

//////////////////////////////////////////////////////////////////////////
// Links
function link_filtering_support(object_type, left_link, our_status, foreign_status)
{
	var _this = this;

	this.deleted_status = "deleted";
	this.unsaved_status = "unsaved";

	this.true_filter = function(ctx)
	{ return ctx.session.create_criteria("or"); }
	this.false_filter = function(ctx)
	{ return ctx.session.create_expression(left_link, "eq", ctx.session.hexstring_to_id("00")); }

	this.get_current_obj_filter = function(ctx, item_ex)
	{
		var id = item_ex.get_id();
		return id == null ? this.false_filter(ctx) : ctx.session.create_expression(left_link, "eq", id);
	}

	this.get_status_filter = function(ctx, field, status, reverse)
	{
		if (field != null)
			return ctx.session.create_expression(field, reverse ? "ne" : "eq", status);
		else
			return reverse ? this.true_filter(ctx) : this.false_filter(ctx);
	}

	this.get_filter = function(ctx, item_ex, with_id, our, our_rev, foreign, for_rev)
	{
		var filter = ctx.session.create_criteria("and");

		if (item_ex != null)
			filter.add(this.get_current_obj_filter(ctx, item_ex));

		if (with_id != null && this.get_right_filter != null)
			filter.add(this.get_right_filter(ctx, with_id));

		if (our != null)
			filter.add(this.get_status_filter(ctx, our_status, our, our_rev));

		if (foreign != null)
			filter.add(this.get_status_filter(ctx, foreign_status, foreign, for_rev));

		return filter;
	}

	var get_marked_items = function(ctx, item_ex, our_status)
	{
		var filter = _this.get_filter(ctx, item_ex, null, our_status, false, null, null);
		return ctx.session.find_items(object_type, filter);
	}

	this.process_marked = function(ctx, item_ex, deleted_fn, unsaved_fn)
	{
		helpers.for_each(get_marked_items(ctx, item_ex, this.deleted_status), deleted_fn);
		helpers.for_each(get_marked_items(ctx, item_ex, this.unsaved_status), unsaved_fn);
	}

	this.linked_helper = function(ctx, f, item_ex, submited, options)
	{
		var filter = this.get_filter(ctx, item_ex, null, submited ? this.unsaved_status : this.deleted_status, true, this.unsaved_status, true);
		if (options && options["additional_filter"])
			filter.add(options["additional_filter"]);
		var result = { "count": 0, "values": [], "association_ids": [] };
		helpers.for_each(ctx.session.find_items(object_type, filter), f, result);
		return result;
	}

}

/**
@class Objects of this class manage MVG bindings represented by associations which have two fields to retain ID of both objects.
@constructor 
@param {String} type Type of object for which this link will create bindings.
@param {String} link_to Type of object to which this link will create bindings.
@param {String} association_type Type of association that will represent binding.
@param {String} left_link Name of field that will retain link to object for which this link will create bindings.
@param {String} right_link Name of field that will retain link to object to which this link will create bindings.
@param {String} our_status Name of field that will retain status of binding on object for which this link will create bindings.
@param {String} foreign_status Name of field that will retain status of binding on object to which this link will create bindings. This argument is optional.
@extends data_model.link
@memberOf data_model
*/
function mvg_link(type, link_to, association_type, left_link, right_link, our_status, foreign_status)
{
	// Common properties
	this.type = type;
	this.link_to = link_to;
	this.link_type = "mvg";
	this.tag = "mvg";

	this.id_required = true;

	// Common methods
	this.create = function(ctx, spec_ctx)
	{
		var filter = filtering_support.get_filter(ctx, spec_ctx.item_ex, spec_ctx.with_id, null, null, filtering_support.unsaved_status, true);
		var item = ctx.session.find_item(association_type, filter);
		var new_item = item == null;
		var changed = new_item;
		if (new_item)
		{
			item = prefill_item(ctx, { "type": association_type }).item;
			item[left_link] = spec_ctx.item_ex.get_id();
			item[right_link] = spec_ctx.with_id;
			if (!spec_ctx.submited)
				item[our_status] = filtering_support.unsaved_status;
		}
		else
		{
			var status = item[our_status];
			if (status == filtering_support.deleted_status || (spec_ctx.submited && status == filtering_support.unsaved_status))
			{
				item[our_status] = "";
				changed = true;
			}
		}
		if (item != null && changed)
		{
			ctx.save(item);
			if (spec_ctx.submited)
				remove_unsaved_on_other_side(ctx, spec_ctx.item_ex, spec_ctx.with_id);
		}
		return ({
			"association_id": item != null ? item.id : null,
			"associated_id": spec_ctx.with_id,
			"changed": changed,
			"is_new": new_item,
			"reason": changed ? null : "already_exists"
		});
	}

	this.remove = function(ctx, spec_ctx)
	{
		var filter = filtering_support.get_filter(ctx, spec_ctx.item_ex, spec_ctx.with_id, null, null, filtering_support.unsaved_status, true);
		var item = ctx.session.find_item(association_type, filter);
		if (item != null)
		{
			var result =
			{
				"association": item,
				"association_id": item.id,
				"associated_id": spec_ctx.with_id,
				"removed": false,
				"modified": false
			}
			var status = item[our_status];
			if (spec_ctx.submited || item[our_status] == filtering_support.unsaved_status)
			{
				result.removed = true;
				result.association = null;
				item.remove();
			}
			else if (item[our_status] != filtering_support.deleted_status)
			{
				item[our_status] = filtering_support.deleted_status;
				result.modified = true;
				ctx.save(item);
			}
			return result;
		}
		else
			return ({ "reason": "not_linked" });
	}

	this.linked = function(ctx, spec_ctx)
	{
		function f(item, result)
		{
			result.count++;
			result.values.push(item[right_link]);
			result.association_ids.push(item.id);
		}
		return filtering_support.linked_helper(ctx, f, spec_ctx.item_ex, spec_ctx.submited, spec_ctx.params);
	}

	this.submit = function(ctx, spec_ctx)
	{
		var notification_params = { "removed": [], "created": [] };
		var _this = this;

		function delete_deleted(item)
		{
			notification_params.removed.push(_this.resolve_association(ctx, item));

			item.remove();
		}

		function apply_unsaved(item)
		{
			notification_params.created.push(_this.resolve_association(ctx, item));

			item[our_status] = "";
			ctx.save(item);
			remove_unsaved_on_other_side(ctx, spec_ctx.item_ex, item[right_link]);
		}

		filtering_support.process_marked(ctx, spec_ctx.item_ex, delete_deleted, apply_unsaved);
		spec_ctx.notify("submit", notification_params);
	}

	this.revert = function(ctx, spec_ctx)
	{
		function clear_deleted(item)
		{
			item[our_status] = "";
			ctx.save(item);
		}

		function delete_unsaved(item)
		{
			item.remove();
		}

		filtering_support.process_marked(ctx, spec_ctx.item_ex, clear_deleted, delete_unsaved);
	}

	// Custom methods
	/**
	Transforms association to ID of linked object. This method is used usually by {@link form_helpers.view_ctrl}.
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param {Object} item Object that represents association.
	@return ID of linked object from binding represented by association.
	@type ID
	*/
	this.resolve_association = function(ctx, item)
	{
		return item[right_link];
	}

	// Own methods
	var get_right_filter = function(ctx, right_id)
	{
		return right_id == null ? true_filter(ctx) : ctx.session.create_expression(right_link, "eq", right_id);
	}

	var filtering_support = this.filtering_support = new link_filtering_support(association_type, left_link, our_status, foreign_status);
	filtering_support.get_right_filter = get_right_filter;

	var remove_unsaved_on_other_side = function(ctx, item_ex, with_id)
	{
		var filter = filtering_support.get_filter(ctx, item_ex, with_id, null, null, filtering_support.unsaved_status, false);
		var item = ctx.session.find_item(association_type, filter);
		if (item != null)
			item.remove();
	}

	// Custom properties
	this.filtering_support = filtering_support;
	this.association_type = association_type;
	this.left_link = left_link;
	this.right_link = right_link;
}

/**
@class Objects of this class manage 1:M associations when child objects has field with ID of parent.
@constructor 
@param {String} type Type of parent object.
@param {String} link_to Type of child object.
@param {String} left_link Name of field that will retain link to parent.
@param {String} our_status Name of field that will retain status of binding on parent object.
@param {bool} remove_on_unlink True means that pointer to parent is required on child object and child object should be removed if "unlink" called. Otherwise, link to parent will be blanked on child if "unlink" called.
@extends data_model.link
@memberOf data_model
*/
function mirrored_direct_link(type, link_to, left_link, our_status, remove_on_unlink, foreign_status)
{
	// Common properties
	this.type = type;
	this.link_to = link_to;
	this.link_type = "mirrored_direct";
	this.tag = "mvg";

	this.id_required = true;

	// Common methods
	this.create = function(ctx, spec_ctx)
	{
		function f(left_id, with_item, result)
		{
			var prev_id = with_item[left_link];
			var new_link = prev_id == null;
			var old_link = helpers.ids_equal(ctx.session, left_id, prev_id);
			if (new_link || old_link)
			{
				if (new_link)
				{
					with_item[left_link] = left_id;
					with_item[our_status] = spec_ctx.submited ? null : filtering_support.unsaved_status;
					result.changed = true;
				}
				else if (old_link)
				{
					if (with_item[our_status] == filtering_support.deleted_status
						|| (spec_ctx.submited && with_item[our_status] == filtering_support.unsaved_status))
					{
						with_item[our_status] = null;
						result.changed = true;
					}
				}
				result.is_new = new_link;
			}
			else
				result.reason = "link_exists";
		}
		return check_and_execute(ctx, spec_ctx, f);
	}

	this.remove = function(ctx, spec_ctx)
	{
		function f(left_id, with_item, result)
		{
			var prev_id = with_item[left_link];
			var link_exists = helpers.ids_equal(ctx.session, left_id, prev_id);
			if (link_exists)
			{
				var status = with_item[our_status];
				if (spec_ctx.submited || status == filtering_support.unsaved_status)
				{
					if (remove_on_unlink)
					{
						with_item.remove();
						result.removed = true;
					}
					else
					{
						with_item[left_link] = null;
						with_item[our_status] = null;
						result.changed = true;
					}
				}
				else if (status != filtering_support.deleted_status)
				{
					with_item[our_status] = filtering_support.deleted_status;
					result.changed = true;
				}
			}
			else
				result.reason = "not_linked";
		}
		return check_and_execute(ctx, spec_ctx, f);
	}

	this.linked = function(ctx, spec_ctx)
	{
		function f(item, result)
		{
			result.count++;
			var id = item.id;
			result.values.push(id);
			result.association_ids.push(id);
		}
		return filtering_support.linked_helper(ctx, f, spec_ctx.item_ex, spec_ctx.submited, spec_ctx.params);
	}

	this.submit = function(ctx, spec_ctx)
	{
		var notification_params = { "removed": [], "created": [] };
		var _this = this;

		function delete_deleted(item)
		{
			notification_params.removed.push(_this.resolve_association(ctx, item));

			if (remove_on_unlink)
				item.remove();
			else
			{
				item[left_link] = null;
				item[our_status] = null;
				ctx.save(item);
			}
		}

		function apply_unsaved(item)
		{
			notification_params.created.push(_this.resolve_association(ctx, item));

			item[our_status] = null;
			ctx.save(item);
		}

		filtering_support.process_marked(ctx, spec_ctx.item_ex, delete_deleted, apply_unsaved);
		spec_ctx.notify("submit", notification_params);
	}

	this.revert = function(ctx, spec_ctx)
	{
		function clear_deleted(item)
		{
			item[our_status] = null;
			ctx.save(item);
		}

		function delete_unsaved(item)
		{
			if (remove_on_unlink)
				item.remove();
			else
			{
				item[left_link] = null;
				item[our_status] = null;
				ctx.save(item);
			}
		}

		filtering_support.process_marked(ctx, spec_ctx.item_ex, clear_deleted, delete_unsaved);
	}

	// Custom methods
	// Custom methods
	/**
	Transforms association to ID of linked object but given that linked object and association in the same thing in case of mirrored direct link id of object returned.
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param {Object} item Object that represents child.
	@return ID of linked object from binding represented by association.
	@type ID
	*/
	this.resolve_association = function(ctx, item)
	{
		return item.id;
	}

	// Own methods
	var filtering_support = new link_filtering_support(link_to, left_link, our_status, foreign_status);

	var remove_unsaved_on_other_side = function(ctx, item_ex, with_id)
	{
		var filter = filtering_support.get_filter(ctx, item_ex, with_id, null, null, filtering_support.unsaved_status, false);
		var item = ctx.session.find_item(association_type, filter);
		if (item != null)
			item.remove();
	}

	var check_and_execute = function(ctx, spec_ctx, f)
	{
		var result = { "success": false };
		var left_id = spec_ctx.item_ex.get_id();
		if (left_id != null)
		{
			if (spec_ctx.with_id != null)
			{
				var with_item = ctx.session.open_item(spec_ctx.with_id);
				if (with_item != null)
				{
					result.item = with_item;
					f(left_id, with_item, result);

					if (result.changed)
						ctx.save(with_item);
					else
						result.changed = false;
				}
				else
					result.reason = "no_with";
			}
			else
				result.reason = "no_with_id";
		}
		result.success = result.reason == null;
		return result;
	}

	// Custom properties
	this.filtering_support = filtering_support;
	this.association_type = link_to;
	this.left_link = left_link;
	this.right_link = "id()";
}

/**
@class Objects of this class manage bindings when ID of linked object retained by field.
@constructor 
@param {String} type Type of object for which this link will create bindings.
@param {String} link_to Type of object to which this link will create bindings.
@param {String} field Name of field that will retain ID of linked object.
@extends data_model.link
@memberOf data_model
*/
function direct_link(type, link_to, field)
{
	// Common properties
	this.type = type;
	this.link_to = link_to;
	this.link_type = "direct";
	this.tag = "direct";

	this.id_required = false;

	// Custom properties
	this.field = field;

	// Common methods
	this.create = function(ctx, spec_ctx)
	{
		var result =
		{
			"success": true,
			"prev_value": get_current_value(spec_ctx.item_ex),
			"new_value": spec_ctx.with_id,
			"saved": false
		}
		spec_ctx.item_ex.set_property(field, spec_ctx.with_id);
		if (spec_ctx.submited)
		{
			result.saved = spec_ctx.item_ex.save();
			result.success = result.saved;
		}
		return result;
	}

	this.remove = function(ctx, spec_ctx)
	{
		var result;
		if (helpers.ids_equal(ctx.session, get_current_value(spec_ctx.item_ex), spec_ctx.with_id))
		{
			spec_ctx.with_id = null;
			result = this.create(ctx, spec_ctx);
		}
		else
			result = { "success": false };
		return result;
	}

	this.linked = function(ctx, spec_ctx)
	{
		var value = get_current_value(spec_ctx.item_ex);
		var values = value != null ? [value] : [];

		var result =
		{
			"count": values.length,
			"value": value,
			"values": values
		};
		return result;
	}

	// Internal methods
	var get_current_value = function(item_ex)
	{
		return item_ex.get_property(field);
	}
}

/**
@class Objects of this class manage bindings which have form of MVG bindings but behavior object can be linked only to 1 or 0 objects at the same time. 
This means that "create" method will modify existent association instead of creation of new.
@constructor 
@param {String} type Type of object for which this link will create bindings.
@param {String} link_to Type of object to which this link will create bindings.
@param {String} association_type Type of association that will represent binding.
@param {String} left_link Name of field that will retain link to object for which this link will create bindings.
@param {String} right_link Name of field that will retain link to object to which this link will create bindings.
@param {String} foreign_status Name of field that will retain status of binding on object to which this link will create bindings. This argument is optional.
@extends data_model.link
@memberOf data_model
*/
function mvg_single_link(type, link_to, association_type, left_link, right_link, foreign_status)
{
	// Common properties
	this.type = type;
	this.link_to = link_to;
	this.link_type = "mvg_single_link";
	this.tag = "direct";

	this.id_required = true;

	// Common methods
	this.create = function(ctx, spec_ctx)
	{
		var result =
		{
			"success": true,
			"new_value": spec_ctx.with_id,
			"prev_value": null,
			"association_id": null,
			"removed": false
		};
		var new_with_is_null = spec_ctx.with_id == null;
		var item = get_association(ctx, spec_ctx, !new_with_is_null);
		if (item != null)
		{
			result.prev_value = item[right_link];
			if (new_with_is_null)
			{
				result.association_id = item.id;
				item.remove();
				result.removed = true;
			}
			else
			{
				if (!helpers.ids_equal(ctx.session, result.prev_value, result.new_value))
				{
					item[right_link] = spec_ctx.with_id;
					ctx.save(item);
				}
				else
				{
					result.success = false;
					result.reason = "already exists";
				}
				result.association_id = item.id;
			}
		}
		remove_unsaved_on_other_side(ctx, spec_ctx.item_ex);
		return result;
	}

	this.linked = function(ctx, spec_ctx)
	{
		var result = {
			"values": [],
			"value": null,
			"association_id": null,
			"association_ids": []
		};
		var association = get_association(ctx, spec_ctx);
		if (association != null)
		{
			result.value = association[right_link];
			result.values.push(result.value);
			result.association_id = association.id;
			result.association_ids.push(result.association_id);
		}
		result.count = result.values.length;
		return result;
	}

	// Custom methods
	this.resolve_association = function(ctx, item)
	{
		return item[right_link];
	}

	// Own methods
	var get_right_filter = function(ctx, right_id)
	{
		return ctx.session.create_expression(right_link, "eq", right_id);
	}

	var filtering_support = this.filtering_support = new link_filtering_support(association_type, left_link, null, foreign_status);
	filtering_support.get_right_filter = get_right_filter;

	var get_association = function(ctx, spec_ctx, create_if_not_found)
	{
		var filter = filtering_support.get_filter(ctx, spec_ctx.item_ex, null, null, null, filtering_support.unsaved_status, true);
		var item = ctx.session.find_item(association_type, filter);
		if (item == null && create_if_not_found)
		{
			item = prefill_item(ctx, { "type": association_type }).item;
			item[left_link] = spec_ctx.item_ex.get_id();
		}
		return item;
	}

	var remove_unsaved_on_other_side = function(ctx, item_ex)
	{
		var filter = filtering_support.get_filter(ctx, item_ex, null, null, null, filtering_support.unsaved_status, false);
		var item = ctx.session.find_item(association_type, filter);
		if (item != null)
			item.remove();
	}

	// Custom properties
	this.filtering_support = filtering_support;
	this.association_type = association_type;
}

//////////////////////////////////////////////////////////////////////////
// Triggers
/**
@class This function creates function that can be used as trigger handler to update primary when first association created or change/remove primary when first primary association removed.
@constructor 
@param options Options of trigger. Only one "primary_tag" option supported now that describes tag of primary link and has default value "direct".
@memberOf data_model
*/
function create_update_primary_trigger(options)
{
	options = helpers.merge_contexts({ "primary_tag": "direct" }, options);

	function f(ctx, action_ctx)
	{
		if (action_ctx.result.success || action_ctx.result.reason == "id_expected")
		{
			var linked = ctx.linker.linked({
				"item_ex": action_ctx.item_ex,
				"link_to": action_ctx.link_to,
				"submited": action_ctx.submited,
				"params": action_ctx.params,
				"tag": options.primary_tag
			});
			var new_id = false;
			if (action_ctx.operation == "created" && linked.count == 0)
				new_id = action_ctx.with_id;
			else if (action_ctx.operation == "removed" && (linked.count == 0 || helpers.ids_equal(ctx.session, linked.value, action_ctx.with_id)))
			{
				var mvg_linked = ctx.linker.linked({
					"item_ex": action_ctx.item_ex,
					"link_to": action_ctx.link_to,
					"submited": action_ctx.submited,
					"params": action_ctx.params,
					"tag": action_ctx.tag
				});
				new_id = mvg_linked.count > 0 ? mvg_linked.values[0] : null;
			}
			if (new_id != false)
			{
				ctx.linker.link({
					"item_ex": action_ctx.item_ex,
					"link_to": action_ctx.link_to,
					"with_id": new_id,
					"submited": action_ctx.submited,
					"params": action_ctx.params,
					"tag": options.primary_tag
				});
			}
		}
	}
	return f;
}
var update_primary_trigger = create_update_primary_trigger();

/**
Trigger function that performs link/unlink operation on link/unlink notifications.
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.perform_operation_from_notification_action_ctx} action_ctx Ctx that describes current operation.
@memberOf data_model
*/
function perform_operation_from_notification_trigger(ctx, action_ctx)
{
	var default_spec_ctx = helpers.get_restricted_context(action_ctx, ["item_ex", "tag", "submited", "params"]);

	function link_one(spec_ctx)
	{
		var link_result = { "spec_ctx": helpers.merge_contexts(default_spec_ctx, spec_ctx) };
		link_result.result = ctx.linker[action_ctx.operation](link_result.spec_ctx);
		action_ctx.notification_params.link_results.push(link_result);
	}
	function link_id(with_id)
	{
		link_one({ "with_id": with_id });
	}
	action_ctx.notification_params.link_results = [];
	helpers.for_each2(action_ctx.notification_params.with_ids, link_id);
	helpers.for_each2(action_ctx.notification_params.links, link_one);
	(ctx.triggers != null ? ctx.triggers : ctx.data_model.triggers).call(ctx, helpers.merge_contexts(action_ctx, { "operation": "check_results" }));
}

/**
Trigger function that performs denies deletion of primary association.
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.trigger_action_ctx} action_ctx Ctx that describes current operation.
@memberOf data_model
*/
function deny_primary_delete_trigger(ctx, action_ctx)
{
	var spec_ctx = helpers.get_restricted_context(action_ctx, ["item_ex", "link_to", "submited", "params"]);
	spec_ctx = helpers.merge_contexts({ "tag": "direct" }, spec_ctx);
	var primary = ctx.linker.linked(spec_ctx);

	if (primary.count == 1 && helpers.ids_equal(ctx.session, primary.value, action_ctx.with_id))
		action_ctx.notification_params.cancel_reason = "primary_delete_denied";
}

/**
@class Function that allows to extract mail addresses from items that supports this. This function uses custom method "extract_emails(ctx, item_ex)" of {@link data_model.object_descriptor} if it present there.
@constructor 
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.item_ex} item_ex Item from which mail addresses shoul be extracted.
@param {ID} item_id Object ID that is used to open object if item_ex argument is empty.
@return Array of mail addresses that can be empty if item doesn't it.
@type String
@memberOf data_model
*/
function extract_emails(ctx, item_ex, item_id)
{
	if (item_ex == null && item_id != null)
	{
		var item = ctx.session.open_item(item_id);
		if (item != null)
			item_ex = new std_item_ex(item);
	}
	if (item_ex != null)
	{
		var descriptor = ctx.data_model.objects.get_object(item_ex.get_type());
		if (descriptor.extract_emails)
			return descriptor.extract_emails(ctx, item_ex);
	}

	return [];
}