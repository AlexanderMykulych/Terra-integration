/**
	Checks value is null or empty string
	@param value Value to check
	@returns true if provided field is null or empty string
*/
function is_null_or_empty(value)
{
	return (value == null || value == "");
}

/**
	Resolves field to winning side if it's not empty
	@param field_name Field name
	@param winning_set Winning-side fields set
	@param losing_set Losing-side fields set
	@param resolution Resolved fields set
*/
function resolve_to_winner(field_name, winning_set, losing_set, resolution)
{
	var wins = winning_set.get_field(field_name);
	var loses = losing_set.get_field(field_name);
	if ((wins != loses) && !is_null_or_empty(wins))
		return resolution.set_field(field_name, wins), true;
	return false;
}

/**
	Resolves field to non-empty side
	@param id_field_name Field name
	@param local_set Local fields set
	@param remote_set Remote fields set
	@param resolution Resolved fields set
*/
function resolve_to_nonempty(id_field_name, local_set, remote_set, resolution)
{
	var lid = local_set.get_field(id_field_name);
	var rid = remote_set.get_field(id_field_name);
	if (is_null_or_empty(lid) != is_null_or_empty(rid))
		return resolution.set_field(id_field_name, is_null_or_empty(lid) ? rid : lid), true;
	return false;
}

/**	
	Resolves conflict for Contacts
	@param conflict Conflict object
*/

function on_person_conflict(conflict)
{
	var remote_set = conflict.left_values();
	var local_set = conflict.right_values();
	if (remote_set == null || local_set == null)
		return; // update-delete

	var resolution = conflicts_manager.create_empty_resolution();
	
	if (conflict.conflict_type == "duplication")
	{		
		//Values of all ID fields will be taken from Workbooks
		if (!resolve_to_winner("assigned_to", remote_set, local_set, resolution))
			resolve_to_nonempty("assigned_to", local_set, remote_set, resolution);
		if (!resolve_to_winner("employer_link", remote_set, local_set, resolution))
			resolve_to_nonempty("employer_link", local_set, remote_set, resolution);

		//Resolves for empty custom fields
		resolve_to_nonempty("name", local_set, remote_set, resolution);
		resolve_to_nonempty("person_salutation", local_set, remote_set, resolution);
		resolve_to_nonempty("person_job_role", local_set, remote_set, resolution);
		resolve_to_nonempty("no_email_soliciting", local_set, remote_set, resolution);
		resolve_to_nonempty("no_phone_soliciting", local_set, remote_set, resolution);
		resolve_to_nonempty("watched", local_set, remote_set, resolution);
	}
	
	if (!resolve_to_winner("created_through", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_through_reference", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through_reference", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_at", remote_set, local_set, resolution))
		resolve_to_nonempty("created_at", local_set, remote_set, resolution);
	if (!resolve_to_winner("updated_at", remote_set, local_set, resolution))
		resolve_to_nonempty("updated_at", local_set, remote_set, resolution);
		
	if (resolution.get_names().toArray().length > 0)
		conflict.resolve_partial(resolution);
}

/**	
	Resolves conflict for Tasks
	@param conflict Conflict object
*/
function on_task_conflict(conflict)
{
	var remote_set = conflict.left_values();
	var local_set = conflict.right_values();
	if (remote_set == null || local_set == null)
		return; // update-delete

	var resolution = conflicts_manager.create_empty_resolution();
	
	if (conflict.conflict_type == "duplication")
	{

		//Values of all ID fields will be taken from Workbooks
		if (!resolve_to_winner("assigned_to", remote_set, local_set, resolution))
			resolve_to_nonempty("assigned_to", local_set, remote_set, resolution);
		if (!resolve_to_winner("primary_contact_id", remote_set, local_set, resolution))
			resolve_to_nonempty("primary_contact_id", local_set, remote_set, resolution);
			
		//Resolves for empty custom fields
		resolve_to_nonempty("primary_contact_type", local_set, remote_set, resolution);
		resolve_to_nonempty("watched", local_set, remote_set, resolution);
	}
	
	if (!resolve_to_winner("created_through", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_through_reference", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through_reference", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_at", remote_set, local_set, resolution))
		resolve_to_nonempty("created_at", local_set, remote_set, resolution);
	if (!resolve_to_winner("updated_at", remote_set, local_set, resolution))
		resolve_to_nonempty("updated_at", local_set, remote_set, resolution);
	
	if (resolution.get_names().toArray().length > 0)
		conflict.resolve_partial(resolution);
}

/**	
	Resolves conflict for Emails
	@param conflict Conflict object
*/
function on_email_conflict(conflict)
{
	var remote_set = conflict.left_values();
	var local_set = conflict.right_values();
	if (remote_set == null || local_set == null)
		return; // update-delete

	var resolution = conflicts_manager.create_empty_resolution();
	
	
	if (conflict.conflict_type == "general")
	{
		if (!resolve_to_winner("rfc822", remote_set, local_set, resolution));
			resolve_to_nonempty("rfc822", local_set, remote_set, resolution);
		if (!resolve_to_winner("message_id", remote_set, local_set, resolution));
			resolve_to_nonempty("message_id", local_set, remote_set, resolution);
	}
	if (conflict.conflict_type == "duplication")
	{
		if (!resolve_to_winner("rfc822", local_set, remote_set, resolution));
			resolve_to_nonempty("rfc822", local_set, remote_set, resolution);
		if (!resolve_to_winner("message_id", local_set, remote_set, resolution));
			resolve_to_nonempty("message_id", local_set, remote_set, resolution);
	}
	
	if (!resolve_to_winner("created_at", remote_set, local_set, resolution))
		resolve_to_nonempty("created_at", local_set, remote_set, resolution);
	if (!resolve_to_winner("updated_at", remote_set, local_set, resolution))
		resolve_to_nonempty("updated_at", local_set, remote_set, resolution);
	
	if (resolution.get_names().toArray().length > 0)
		conflict.resolve_partial(resolution);
}

/**	
	Resolves conflict for Meetings
	@param conflict Conflict object
*/
function on_meeting_conflict(conflict)
{
	var remote_set = conflict.left_values();
	var local_set = conflict.right_values();
	if (remote_set == null || local_set == null)
		return; // update-delete

	var resolution = conflicts_manager.create_empty_resolution();
	
	if (conflict.conflict_type == "duplication")
	{

		//Values of all ID fields will be taken from Workbooks
		if (!resolve_to_winner("assigned_to", remote_set, local_set, resolution))
			resolve_to_nonempty("assigned_to", local_set, remote_set, resolution);
		if (!resolve_to_winner("primary_contact_id", remote_set, local_set, resolution))
			resolve_to_nonempty("primary_contact_id", local_set, remote_set, resolution);
		
		if (!resolve_to_winner("reminder_enabled", local_set, remote_set, resolution))
			resolve_to_nonempty("reminder_enabled", local_set, remote_set, resolution);
		if (!resolve_to_winner("reminder_minutes", local_set, remote_set, resolution))
			resolve_to_nonempty("reminder_minutes", local_set, remote_set, resolution);

		//Resolves for empty custom fields
		resolve_to_nonempty("primary_contact_type", local_set, remote_set, resolution);
		resolve_to_nonempty("watched", local_set, remote_set, resolution);
	}
	
	if (!resolve_to_winner("created_through", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_through_reference", remote_set, local_set, resolution))
		resolve_to_nonempty("created_through_reference", local_set, remote_set, resolution);
	if (!resolve_to_winner("created_at", remote_set, local_set, resolution))
		resolve_to_nonempty("created_at", local_set, remote_set, resolution);
	if (!resolve_to_winner("updated_at", remote_set, local_set, resolution))
		resolve_to_nonempty("updated_at", local_set, remote_set, resolution);
	
	if (resolution.get_names().toArray().length > 0)
		conflict.resolve_partial(resolution);
}

function on_conflict(conflict) 
{
    if (conflict.item_type == "Private::Crm::Person")
		on_person_conflict(conflict);
	else
	if (conflict.item_type == "Private::Activity::Task")
		on_task_conflict(conflict);
	else
	if (conflict.item_type == "Private::Activity::Meeting")
		on_meeting_conflict(conflict);
	else
	if (conflict.item_type == "Private::Email")
		on_email_conflict(conflict);
} 

conflicts_manager.on_conflict.connect(on_conflict);
