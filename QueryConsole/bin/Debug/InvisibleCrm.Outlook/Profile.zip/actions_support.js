include("helpers.js", "helpers");
include("data_model.js", "data_model");
include("form_helpers.js", "form_helpers");

/**
	@class Actions manager class
	@constructor
	@memberOf actions_support
*/
function action_manager()
{
	var create_ctx_from_form_item = function(item)
	{
		var ctx = new Object();
		ctx.selection = new Array(item);
		ctx.selected_count = 1;
		ctx.inspector_adapter = true;
		return ctx;
	}

	var create_ctx_from_view_ctrl = function(view_ctrl)
	{
		var ctx = new Object();
		ctx.selection = new Array(view_ctrl.selected);
		ctx.selected_count = 1;
		ctx.view_ctrl_adapter = true;
		return ctx;
	}

	var actions_map = new Array();

	/**
		Executes specified action with provided context
		@param id Action name
		@param ctx Context
	*/
	this.execute_action = function(id, ctx)
	{
		var action = actions_map[id];
		if (action != undefined)
			action.action.execute(ctx);
	}
	
	/**
		Executes specified action with form's context
		@param id Action name
		@param {form} form Outlook form object
	*/
	this.execute_from_form = function(id, form)
	{
		this.execute_action(id, create_ctx_from_form_item(form.item));
	}

	/**
		Executes specified action with view control's context
		@param id Action name
		@param view_ctrl View control
	*/
	this.execute_from_view_ctrl = function(id, view_ctrl)
	{
		this.execute_action(id, create_ctx_from_view_ctrl(view_ctrl));
	}

	var set_ctrl_state = function(ctx, action)
	{
		var selected_count = ctx.selected_count;
		if (selected_count == 0)
			selected_count = "no_selected";
		else if (selected_count == 1)
			selected_count = "single_selected";
		else
			selected_count = "multi_selected";
		var state = action.options[selected_count];
		if (state == null)
			state = action.options["default"];

		if (state == "type_dependent" || state == "type_dependent_disabled")
		{
			var type = null;
			var count = 0;
			for (var enm = new Enumerator(ctx.selection); !enm.atEnd(); enm.moveNext())
			{
				count++;
				var current_type = enm.item().type_id;
				if (type == null)
					type = current_type;
				else if (type != current_type)
				{
					type = "";
					break;
				}
			}
			if (count < ctx.selected_count)
				type = count ? "" : "outlook-native";
			var type_dependent_state = action.options["type_dependence"] != null ? action.options["type_dependence"][type] : null;
			if (type_dependent_state == null)
				type_dependent_state = action.options["all_types_state"];
			if (type_dependent_state == "context_dependent_enabled")
			{
				var enabled = state == "type_dependent";
				if (enabled)
				{
					function f1(item)
					{
						enabled = enabled && action.action.is_enabled(ctx, item);
					}
					helpers.for_each(ctx.selection, f1);
				}
				type_dependent_state = enabled ? "enabled" : "disabled";
			}
			if (type_dependent_state == "enabled" && state == "type_dependent_disabled")
				type_dependent_state = "disabled";
			state = type_dependent_state;
		}

		if (state != undefined)
		{
			var visible = (state == "enabled") || (state == "disabled");
			ctx.ctrl.visible = visible;
			if (visible)
				ctx.ctrl.enabled = state == "enabled";
			return true;
		}
		else
			return false;
	}

	/**
		Processes context changing for action
		@param id Action name
		@param ctx Context
	*/
	this.process_action_ctx_change = function(id, ctx)
	{
		var action = actions_map[id];
		if (action != undefined)
		{
			if (action.options != null && set_ctrl_state(ctx, action))
				return;
			if (action.action.ctx_changed != undefined)
				action.action.ctx_changed(ctx);
		}
	}

	/**
		Add new action
		@param id Action name
		@param action Function that implements action functionality
		@param options Structured options definition for action
		<pre>
			{
				"default": <"hidden"> | <"enabled"> | <"disabled"> | <"type_dependent"> | <"type_dependent_disabled">,
				"no_selected": <"hidden"> | <"enabled"> | <"disabled"> | <"type_dependent"> | <"type_dependent_disabled">,
				"single_selected": <"hidden"> | <"enabled"> | <"disabled"> | <"type_dependent"> | <"type_dependent_disabled">,
				"multi_selected": <"hidden"> | <"enabled"> | <"disabled"> | <"type_dependent"> | <"type_dependent_disabled">,
				"type_dependence": { <"type_id"> : <"hidden"> | <"enabled"> | <"disabled"> | <"context_dependent_enabled">, ... },
				"all_types_state": <"hidden"> | <"enabled"> | <"disabled">
			}
			
			Options:
			<b>"no_selected"</b> - State for action control when no items selected
			<b>"single_selected"</b> - State for action control when single item selected
			<b>"multi_selected"</b> - State for action control when multiple items selected
			<b>"type_dependence"</b> - State for items by their types (if state <b>"type_dependent"</b>
			<b>"all_types_state"</b> - State for items which type not defined in <b>"type_dependence"</b>
			
			States:
			<b>"hidden"</b> - Action control is hidden
			<b>"enabled"</b> - Action control is enabled
			<b>"disabled"</b> - Action control is disabled
			<b>"type_dependent"</b> - State of action control depends on selected item's type
			<b>"type_dependent_disabled"</b> - Same as <b>"type_dependent"</b> but control state is <b>"disabled"</b> by default
			<b>"context_dependent_enabled"</b> - State of action control depends on context
		</pre>
	*/
	this.add_action = function(id, action, options)
	{
		actions_map[id] = { "action": action, "options": options };
	}

	/**
		Add new action s
		@param ids Array of action names
		@param action Function that implements action functionality
		@param options Structured options definition for action
	*/
	this.add_actions = function(ids, action, options)
	{
		for (var i in ids)
			actions_map[ids[i]] = { "action": action, "options": options };
	}
}

/**
	@class Factory for action manager
	@param {application} application Application object provided by C++
	@param util Helpers provided by C++
	#returns instance of action_manager class
	@memberOf actions_support
*/
function create_action_manager(application, util)
{
	var am = new action_manager();
	application.on_action.connect(util.create_function(am, "execute_action"));
	application.on_action_ctx_changed.connect(util.create_function(am, "process_action_ctx_change"));
	return am;
}

/**
	@class Std. create-from-parent descriptor. It implements basic fumctionality for linking newly created item with other items on first save
	@constructor
	@memberOf actions_support
	@deprecated
*/
function std_cfp_descriptor()
{
	this.linked_items = new Array();
	this.options = new Array();

	/**
		Add item to link with
		@param id Item id
		@param options Structured options for link
	*/
	this.add = function(id, options)
	{
		if (id != null)
		{
			this.linked_items.push(id);
			this.options.push(options != null ? options : null);
		}
	}

	/**
		Add primary item to link with
		@param id Item id
	*/
	this.add_primary = function(id)
	{
		this.add(id, { "primary": true });
	}
}

/**
	@class Manager class that performs linking of newly created items with other items on first save
	@constructor
	@param {session} session Session object provided by C++
	@memberOf actions_support
*/
function created_from_parent_manager(session)
{
	var associations = new Array();
	
	var get_key = function(item)
	{
		var sk = item.SearchKey;
		return sk != null ? session.id_to_hexstring(sk) : null;
	}
	
	/**
		Returns descriptor for specified item and removes it from descriptors list.
		@param item Item to retrieve descriptor for it
		@returns Descriptor for specified item or null if it doesn't exist.
	*/
	this.retrieve_item_descriptor = function(item)
	{
		var key = get_key(item);
		var descr = associations[key];
		associations[key] = null;
		return descr;
	}

	/**
		Adds descriptor for item
		@param item Item to add descriptor for it
		@param descr Descriptor
	*/
	this.add_descriptor = function(item, descr)
	{
		associations[get_key(item)] = descr;
	}
	
	/**
		Check for descriptor for item existance
		@param item Item to check descriptor for it
		@returns Is there any descriptor for this item
	*/
	this.has_descriptor = function(item)
	{
		return associations[get_key(item)] != null;
	}
}

/**
	Checks selection from context for maximum selection limit. Shows error message if it doesn't.
	@param {session} session Session object provided by C++
	@param {ui} ui UI object provided by C++
	@param ctx Action context
	@param {Integer} action_selection_limit Maximum selection limit
	@returns True if selection count less then limit.
	@memberOf actions_support
*/
function check_selection_limit(session, ui, ctx, action_selection_limit)
{
	if (ctx.selected_count > action_selection_limit)
	{
		ui.message_box(0, session.res_string("msg_too_many_items_selected"), session.res_string("msg_too_many_items_selected_caption"), 0x40);
		return false;
	}
	return true;
}

/**
	Returns First selected item
	@param ctx Action context
	@returns First selected item or null if nothing selected
	@memberOf actions_support
*/
function retrieve_single_item(ctx)
{
	var enm = new Enumerator(ctx.selection);
	if (!enm.atEnd() && enm.item() != null)
		return enm.item();
	return null;
}

/**
	Returns type of first selected items
	@param ctx Action context
	@returns Type of first selected item or null if nothing selected
	@memberOf actions_support
*/
function single_selected_item_type(ctx)
{
	var item = retrieve_single_item(ctx);
	return item != null ? item.type_id : null;
}

/**
	@class Action that creates new item of specified type
	@constructor
	@param {session} session Session object provided by C++
	@param item_type Type of item
	@memberOf actions_support
*/
function new_item(session, item_type)
{
	/**
		Execute action
		@param ctx Action context
	*/
	this.execute = function(ctx)
	{
		var item = session.create_item(item_type);
		session.display_item(item);
	}
}

/**
	@class Action that deletes specified item using confirmation
	@constructor
	@param {ctx} ctx Context with global objects
	@param {Array[String]} no_confirmation_types Array of types names that must be deleted without confirmation
	@memberOf actions_support
*/
function std_item_delete(ctx, options)
{
	var default_options = {
		"no_confirmation_types": []
	}

	options = helpers.merge_contexts(default_options, options);

	var no_confirm = [];
	helpers.for_each(options.no_confirmation_types, function(type) { no_confirm[type] = true; });

	/**
		Execute action
		@param action_ctx Action context
	*/
	this.execute = function(action_ctx)
	{
		if (check_selection_limit(ctx.session, ctx.ui, ctx))
		{
			var can_delete_all = true;
			var no_confirmation = true;
			helpers.for_each(action_ctx.selection, function(item)
			{
				can_delete_all = can_delete_all && can_delete_item(item);
				no_confirmation = no_confirmation && no_confirm[item.type_id] == true;
			});
			if (!can_delete_all)
			{
				ctx.ui.message_box(0, ctx.session.res_string("msg_cant_delete_item"), ctx.session.res_string("msg_cant_delete_item_caption"), 0x40);
				action_ctx.cancel_action = true;
			}
			else
				action_ctx.cancel_action = !(no_confirmation || helpers.delete_confirmation(ctx.ui, ctx.session));
		}
		else
			action_ctx.cancel_action = true;
	}

	var can_delete_item = function(item)
	{
		return ctx.security_manager.create(ctx, new data_model.std_item_ex(item)).delete_access();
	}
}

/**
	@class Action that opens help file
	@constructor
	@param full_path Full path to help file
	@memberOf actions_support
*/
function open_help(full_path)
{
	/**
		Execute action
		@param ctx Action context
	*/
	this.execute = function(ctx)
	{
		var shell = new ActiveXObject("WScript.Shell");
		shell.Exec("hh " + full_path);
	}
}

// Create new Meeting, Email, Task
/**
	@private
*/
var create_item_for_recipients_resource_map =
{
	"Mail": {
		"caption": "msg_no_recipients_caption",
		"message": "msg_no_recipients",
		"single_selected_message": "msg_no_recipient"
	},
	"Event": {
		"caption": "msg_no_attendees_caption",
		"message": "msg_no_attendees",
		"single_selected_message": "msg_no_attendee"
	},
	"Task": {
		"caption": "msg_no_assignees_caption",
		"message": "msg_no_assignees",
		"single_selected_message": "msg_no_assignee"
	}
}

/**
	@private
*/
function create_item_for_recipients(ctx, options, action_ctx)
{
	var cu_addresses = data_model.extract_emails(ctx, null, helpers.get_current_user_id(ctx.session));
	cu_addresses = cu_addresses.concat(helpers.safe_get_account_addresses(ctx.application));

	action_ctx.notification_params.cleared_recipients = [];
	helpers.for_each(action_ctx.notification_params.recipients, function(addr) { if (addr != null && addr != "" && !helpers.ci_contains(cu_addresses, addr)) action_ctx.notification_params.cleared_recipients.push(addr); });

	if (action_ctx.notification_params.cleared_recipients.length > 0)
	{
		action_ctx.notification_params.item = ctx.session.create_item(action_ctx.link_to);
		action_ctx.notification_params.item.recipients = util.jsarray_to_vbarray(action_ctx.notification_params.cleared_recipients);
		action_ctx.notification_params.is_new = true;
		action_ctx.operation = "show";

		if (options.prepare_item_fn)
			options.prepare_item_fn(ctx, action_ctx.notification_params);

		ctx.data_model.triggers.call(ctx, action_ctx);
	}
	else
	{
		var caption = create_item_for_recipients_resource_map[action_ctx.link_to]["caption"];
		var message = create_item_for_recipients_resource_map[action_ctx.link_to][action_ctx.notification_params.single_selected ? "single_selected_message" : "message"];
		ctx.ui.message_box(0, ctx.session.res_string(message), ctx.session.res_string(caption), 0x40);
	}
}

/**
	@class Action that creates new oulook item (E-Mail, Task, Calendar) to recipients from linked objects.<br>
	This action performs search of all linked related recipients, extracts e-mail addresses from them, inserts them to {@link data_model.created_from_ctx#initial_links} and creates new Outlook item with pre-filled recipients.
	@constructor
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param {actions_support.item_for_related_recipients_action_options} options Options.
	@memberOf actions_support
*/
function item_for_related_recipients_action(ctx, options)
{
	options.proxy_type = ctx.data_model.objects.get_object(options.type).proxy_type;

	function process_related_type(related_type)
	{
		helpers.merge_contexts({ "tag": "mvg" }, related_type);
		helpers.merge_contexts({ "out_tag": related_type.tag }, related_type);
	}
	helpers.for_each2(options.related_types, process_related_type);

	this.execute = function(act_ctx)
	{
		var item = retrieve_single_item(act_ctx);
		var item_ex = new data_model.std_item_ex(item);
		var submited = act_ctx.type == "explorer";

		var action_ctx =
		{
			"item_ex": item_ex,
			"type": item_ex.get_type(),
			"link_to": options.proxy_type,
			"operation": "new_created",
			"notification_params": {
				"created_from_ctx_type": "std"
			}
		}
		ctx.data_model.triggers.call(ctx, action_ctx);

		action_ctx.notification_params.recipients = [];

		var analize_related = function(id, related_type)
		{
			var current_emails = data_model.extract_emails(ctx, null, id);
			action_ctx.notification_params.recipients = action_ctx.notification_params.recipients.concat(current_emails);
			action_ctx.notification_params.initial_links = helpers.push_ex(
				action_ctx.notification_params.initial_links, { "with_id": id, "tag": related_type.out_tag });
		}

		var get_related = function(related_type)
		{
			var linked = ctx.linker.linked(helpers.merge_contexts(related_type, { "item_ex": item_ex, "submited": submited }));
			helpers.for_each(linked.values, analize_related, related_type);
		}

		helpers.for_each2(options.related_types, get_related);

		action_ctx.link_to = options.type;
		create_item_for_recipients(ctx, options, action_ctx);
	}
}

/**
	@class Action that creates new oulook item (E-Mail, Task, Calendar) to recipients from selected objects.<br>
	This action extracts e-mail addresses from selected items, inserts them to {@link data_model.created_from_ctx#initial_links} and creates new Outlook item with pre-filled recipients.
	@constructor
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param {actions_support.item_for_recipients_action_options} options Options.
	@memberOf actions_support
*/
function item_for_recipients_action(ctx, options)
{
	options.proxy_type = ctx.data_model.objects.get_object(options.type).proxy_type;
	helpers.merge_contexts({ "tag": "mvg", "single_selected_tag": "direct" }, options);

	this.execute = function(act_ctx)
	{
		var action_ctx =
		{
			"notification_params":
			{
				"single_selected": act_ctx.selected_count == 1,
				"recipients": [],
				"initial_links": [],
				"created_from_ctx_type": "std"
			}
		}

		function selection_filter(item, tag, use_addresses)
		{
			var item_ctx =
			{
				"item": item,
				"addresses": data_model.extract_emails(ctx, new data_model.std_item_ex(item)),
				"initial_links": [{ "with_id": item.id, "tag": tag}],
				"use_addresses": use_addresses,
				"use_links": true
			}
			if (options.selection_filter_fn)
				options.selection_filter_fn(ctx, action_ctx.notification_params, item_ctx);
			if (item_ctx.use_addresses)
				action_ctx.notification_params.recipients = action_ctx.notification_params.recipients.concat(item_ctx.addresses);
			if (item_ctx.use_links)
				action_ctx.notification_params.initial_links = helpers.push_array_ex(action_ctx.notification_params.initial_links, item_ctx.initial_links);
			return item_ctx;
		}

		if (action_ctx.notification_params.single_selected)
		{
			var item = retrieve_single_item(act_ctx);
			var item_ctx = selection_filter(item, options.single_selected_tag, false);
			if (item_ctx.use_links)
			{
				action_ctx.item_ex = new data_model.std_item_ex(item);
				action_ctx.type = action_ctx.item_ex.get_type();
				action_ctx.link_to = options.proxy_type;
				action_ctx.operation = "new_created";
				ctx.data_model.triggers.call(ctx, action_ctx);
			}
		}

		var analize_item = function(item)
		{
			selection_filter(item, options.tag, true);
		}

		helpers.for_each(act_ctx.selection, analize_item);

		action_ctx.link_to = options.type;
		create_item_for_recipients(ctx, options, action_ctx);
	}

	this.is_enabled = function(act_ctx, item)
	{
		return !helpers.is_new_item(item);
	}
}

/**
	@class Action that creates new item with no context-dependent information.<br>
	@constructor
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@param options Simple options which have only "type" options that define type of item to be created.
	@memberOf actions_support
*/
function create_new_item_action(ctx, options)
{
	this.execute = function()
	{
		var action_ctx = {
			"link_to": options.type,
			"operation": "show",
			"notification_params": {
				"item": ctx.session.create_item(options.type),
				"is_new": true
			}
		}
		ctx.data_model.triggers.call(ctx, action_ctx);
	}
}

/**
	@class Action that starts synchronization or show synchronization window if it was hidden.
	@constructor
	@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
	@memberOf actions_support
*/
function start_syncronization_action(ctx)
{
	this.execute = function()
	{
		ctx.application.synchronizer.start_now(0);
	}
}