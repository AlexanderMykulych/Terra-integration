include("helpers.js", "helpers");
include("control_utils.js", "control_utils");
include("business_logic.js", "business_logic");
include("raw_item_functions.js", "raw");

var max_mail_size = 16777216;

function mail_resolver(session) {
	this.resolve_email_to_contact = function (addr, track_conversation_check) {
		var result = new Array();
		if (addr != "" && addr != null) {
			var filter = session.create_criteria("and");
			if (track_conversation_check)
				filter.add(session.create_expression("save_correspondence", "eq", true));
			filter.add(session.create_expression("main_location[email]", "eq", addr));
			filter.add(session.create_expression("workbooks_shared", "eq", true));
			for (var contacts = new Enumerator(session.find_items("Private::Crm::Person", filter)); !contacts.atEnd(); contacts.moveNext())
				result.push(contacts.item());
		}
		return result;
	}

	this.resolve_emails_to_contacts = function (addresses, track_conversation_check) {
		var result = new Array();
		for (var index in addresses)
			result = result.concat(this.resolve_email_to_contact(addresses[index], track_conversation_check));
		return helpers.stable_unique_objects_array(session, result);
	}
}

function mail_processor(application, ui) {
	var session = application.session;

	var get_addresses_string = function (addresses) {
		var result = "";
		for (var key in addresses)
			result += addresses[key];

		return result;
	}

	this.get_mail_addresses = function (mail, include_sender, include_bcc) {
		var to = raw.get_recipints_of_type(application, mail, raw.olTo);
		var cc = raw.get_recipints_of_type(application, mail, raw.olCC);
		var bcc = raw.get_recipints_of_type(application, mail, raw.olBCC);
		var recepients = include_bcc ? to.concat(cc) : to.concat(cc.concat(bcc));
		recepients.sort();

		return (include_sender && mail.SenderAddress != null) ? new Array(mail.SenderAddress).concat(recepients) : recepients;
	}

	this.update_proxy_from_mail = function (session, proxy_object, mail) {
		if (mail.Sent) {
			if (mail.MessageSize < max_mail_size) {
				business_logic.prefill_created_through(session, proxy_object);
				proxy_object.rfc822 = mail.RFC822_Content; ;
				proxy_object.subject = mail.Subject;
				proxy_object.message_id = mail.MessageID;
				proxy_object.hash_code = this.get_hash_code(mail);
				proxy_object.workbooks_shared = true;
			}
			else {
				try {
					proxy_object.remove();
				}
				catch (e) // if never saved
				{ }
				proxy_object = null;
			}
		}
		else {
			proxy_object.rfc822 = null;
			proxy_object.pim_object_id = mail.SearchKey;
			proxy_object.workbooks_shared = false;
		}

		return proxy_object;
	}

	this.get_hash_code = function (mail) {
		var result = mail.Subject != null ? mail.Subject : "";

		result += get_addresses_string(this.get_mail_addresses(mail, true, false));

		var sent_date = mail.SentOn;
		if (sent_date != null) {
			sent_date = new Date(sent_date);
			sent_date.setMilliseconds(0);
			result += helpers.format_date(sent_date, "dd-MM-yyyy HH:mm:ss");
		}

		return control_utils.hash(result);
	}

	this.get_proxy_of_mail = function (session, mail) {
		var result = null;

		var key = mail.MessageID;
		if (key != null)
			result = session.find_item("Private::Email", session.create_expression("message_id", "eq", key));

		key = this.get_hash_code(mail);
		if (result == null && key != null)
			result = session.find_item("Private::Email", session.create_expression("hash_code", "eq", key));

		key = mail.SearchKey;
		if (result == null && key != null)
			result = session.find_item("Private::Email", session.create_expression("pim_object_id", "eq", key));

		return result;
	}
}

function manual_mail_processing(application, ui, application_script, form, sub_form) {
	var session = application.session;
	var mail = form.item;
	var mp = new mail_processor(application, ui);
	var security_manager = application_script.security_manager;

	var create_item = function () {
		return session.create_item("Private::Email");
	}

	var raise_form = function () {
		raw.mark_mail_dirty(mail);
	}

	this.change_shared = function (flag) {
		var new_state = flag;

		if (flag) {
			if (mail.Sent && mail.MessageSize >= max_mail_size) {
				ui.message_box(0, session.res_string("email_too_large_label"), session.res_string("msg_cant_share_activity_caption"), 0x30);
				new_state = false;
			}
			else if (sub_form.item == null) {
				var proxy_object = create_item();
				sub_form.item = proxy_object;
			}
		}
		else {
			if (business_logic.item_already_synched(sub_form.item)) {
				var security_descriptor = security_manager.create_descriptor(form, sub_form.item);
				var delete_access = security_descriptor.delete_access();

				if (!delete_access) {
					ui.message_box(0, session.res_string("msg_cant_unshare_activity"), session.res_string("msg_cant_unshare_activity_caption"), 0x40);
					new_state = true;
				}
				else if (ui.message_box(0, session.res_string("msg_unsharing_event"), session.res_string("msg_unsharing_event_caption"), 0x44) != 6)
					new_state = true;
			}
			else {
				new_state = false;
			}
		}

		if (this.shared != new_state)
			raise_form();

		this.shared = new_state;
	}

	this.form_saved = function () {
		if (this.shared) {
			try {
				sub_form.item = mp.update_proxy_from_mail(session, sub_form.item, mail);
			}
			catch (e) { }
			//sub_form.item = sub_form.item;
			sub_form.save();
		}
		else {
			var proxy_object = sub_form.item;
			if (proxy_object != null) {
				sub_form.item = null;
				try {
					proxy_object.remove();
				}
				catch (e) // if never saved
				{ }
			}
		}
	}

	sub_form.on_edited.connect(raise_form);

	var proxy = mp.get_proxy_of_mail(session, mail);

	this.shared = proxy != null;

	if (this.shared) {
		sub_form.item = proxy;
	}
}

function auto_mail_processing(application, ui, item_saver) {
	var session = application.session;
	var mr = new mail_resolver(session);
	var mp = new mail_processor(application, ui);
	var sent_mail_ids = new Array();

	var process_sent_mail = function (mail) {
		var proxy = mp.get_proxy_of_mail(session, mail);
		if (proxy != null) {
			proxy = mp.update_proxy_from_mail(session, proxy, mail);
			if (proxy != null)
				item_saver.save_and_disable_events(proxy);
		}
		else
			process_received_mail(mail);
	}

	var process_received_mail = function (mail) {
		if (mail != null && mail.type_id == "Mail") {
			//mail.save();
			var all_addresses = mp.get_mail_addresses(mail, true, true);
			var tracked_contacts = mr.resolve_emails_to_contacts(all_addresses, true);
			if (tracked_contacts.length > 0) {
				var proxy = mp.get_proxy_of_mail(session, mail);
				if (proxy == null)
					proxy = session.create_item("Private::Email");

				proxy = mp.update_proxy_from_mail(session, proxy, mail);
				if (proxy != null)
					item_saver.save_and_disable_events(proxy);
			}
		}
	}

	var on_mail_sending = function (mail) {
		if (mail != null && mail.type_id == "Mail") {
			mail.save();
			var proxy = mp.get_proxy_of_mail(session, mail);
			if (proxy != null && mail.MessageSize >= max_mail_size) {
				ui.message_box(0, session.res_string("email_too_large_label"), session.res_string("msg_cant_share_activity_caption"), 0x30);

				try {
					proxy.remove();
				}
				catch (e) // if never saved
				{ }
			}
		}
	}

	//application.on_mail_received.connect(process_received_mail);
	//application.on_mail_sending.connect(on_mail_sending);
	//application.on_mail_sent.connect(process_sent_mail);
}

function get_recipient_address(application, recipient) {
	var result = null;
	try {
		var type = recipient.AddressEntry.Type;
		if (type == "SMTP" && recipient.Address != "")
			result = recipient.Address;
		else {
			var addresses = application.accounts.open_entry(application.session.hexstring_to_id(recipient.EntryID)).toArray();
			if (addresses.length > 0)
				result = addresses[0];
		}
	}
	catch (e)
	{ }
	return result;
}

function get_recipients_addresses(application, recipients) {
	var result = "";
	for (var i = 1; i <= recipients.Count; i++) {
		var recipient = recipients.Item(i);
		result += get_recipient_address(application, recipient);
		result += "; ";
	}
	return result;
}
