include("helpers.js", "helpers");
include("data_model.js", "data_model");
include("form_helpers.js", "form_helpers");

/**
@private
*/
function restriction_to_dasl_convertor(ctx)
{
	var normalize = function(arg)
	{
		return helpers.replace_all(" ", "%20", arg);
	}
	
	var std_prefix = "http://schemas.microsoft.com/mapi/string/{00020329-0000-0000-C000-000000000046}/";
	var prefix = std_prefix	+ normalize(ctx.data_model.dasl_field_product_prefix);

	var operators_map =
	{
		"eq": "=",
		"ne": "&lt;&gt;"
	};
	
	var convert_field_name = function(field, obj_type)
	{
		if (obj_type != null)
		{
			var field_dscr = ctx.data_model.objects.get_object(obj_type).get_field(field);
			if (field_dscr.internal_name != null)
				return std_prefix + normalize(field_dscr.internal_name); 
		}
		return prefix + normalize(field); 
	}

	var criteria = function(crit)
	{
		var restrictions = [];

		this.add = function(r)
		{
			restrictions.push(r);
		}

		this.to_dasl = function(type)
		{
			var result = "";
			function f(r, params, for_each_ctx)
			{
				var current_result = r.to_dasl(type);
				if (current_result != "")
				{
					if (result != "")
						result += " " + crit + " ";
					result += current_result;
				}
				else if (crit.toLowerCase() == "or")
				{
					result = "";
					for_each_ctx.interrupted = true;
				}
			}
			helpers.for_each(restrictions, f);
			if (result != "")
				result = "(" + result + ")";
			return result;
		}
	}
	
	var expression = function(field, op, value)
	{
		this.to_dasl = function(to_dasl)
		{
			return "(\"" + convert_field_name(field, to_dasl) + "\" " + operators_map[op] + " '" + value + "')";
		}
	}

	this.create_criteria = function(crit)
	{
		return new criteria(crit);
	}
	
	this.create_expression = function(field, op, value)
	{
		return new expression(field, op, value);
	}
	
	this.convert_field_name = convert_field_name;
}

/**
	@class Controller that manage MVG dialog.
	Main task of this controller to create dialog from template and create other controllers such as:<br>
	- {@link form_helpers.view_ctrl};<br>
	- {@link form_helpers.sales_book_selector};<br>
	- {@link form_helpers.autocomplete_selector};<br>
	- {@link form_helpers.direct_link_controller};<br>
	- {@link form_helpers.primary_selector_wrapper} or {@link form_helpers.primary_combobox_wrapper}.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function mvg_dialog_controller()
{
	this.default_options =
	{
		"dialog_id": "mvg_dialog",
		"primary_tag": "direct",
		"mvg_tag": "mvg"
	};

	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.mvg_dialog_controller_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		options.primary_link = ctx.links.get_link(helpers.merge_contexts(options, { "tag": options.primary_tag })).link;
		options.mvg_link = ctx.links.get_link(helpers.merge_contexts(options, { "tag": options.mvg_tag })).link;

		options.dialog_xml_template = ctx.ui.get_dialog_xml(options.dialog_id);

		var dasl_creator = new restriction_to_dasl_convertor(ctx);
		var dasl_ctx = { "session": dasl_creator };
		var filter = options.mvg_link.filtering_support.get_filter(
			dasl_ctx,
			null,
			null,
			options.mvg_link.filtering_support.deleted_status,
			true,
			options.mvg_link.filtering_support.unsaved_status,
			true);
		if (options.vc_filter_fn != null)
			filter = options.vc_filter_fn(dasl_ctx, filter);

		options.dialog_template_params = helpers.merge_contexts(options.mvg_link.dialog_template_params, options.dialog_template_params);
		helpers.merge_contexts({
			"autocomplete_field": options.mvg_link.right_link,
			"autocomplete_type": options.mvg_link.link_to,
			"view_type": options.mvg_link.association_type,
			"view_dasl_left_link_field": dasl_creator.convert_field_name(options.mvg_link.left_link, options.mvg_link.association_type),
			"view_dasl": filter.to_dasl(options.mvg_link.association_type),
			"primary_selector_type": options.mvg_link.association_type,
			"primary_selector_left_id": options.mvg_link.left_link,
			"primary_selector_value": options.mvg_link.right_link
		}, options.dialog_template_params);

		if (options.primary_link != null)
			helpers.merge_contexts({ "primary_selector_field": options.primary_link.field }, options.dialog_template_params);

		options.dialog_xml = form_helpers.shared.apply_template_params(options.dialog_xml_template, options.dialog_template_params);

		options.dialog = ctx.ui.create_dialog_from_xml(0, options.dialog_xml);
		init_control_controllers();
		if (options.on_dialog_init_fn != null)
			options.on_dialog_init_fn(ctx, options);
	}

	/** Shows dialog. */
	this.show = function()
	{
		if (options.disabled != true)
		{
			if (options.on_before_show_fn != null)
				options.on_before_show_fn(ctx, options);
			options.dialog.item = ctx.form.item;
			var primary_ctrl = options.dialog.primary_selector;
			if (primary_ctrl == null)
				primary_ctrl = options.dialog.primary_combobox;
			if (primary_ctrl != null)
				ctx.application.forms.link_controls(options.dialog, primary_ctrl, ctx.form, options.ctrl);
			options.dialog.visible = true;
		}
	}

	var init_control_controllers = function()
	{
		var cleared_options = helpers.merge_contexts(options);
		cleared_options["link"] = null;
		cleared_options["tag"] = null;

		if (options.dialog.btn_show != null)
		{
			var sb_options = helpers.merge_contexts(cleared_options, {
				"btn_show": options.dialog.btn_show,
				"tag": options.mvg_tag
			});
			sb_options.dialog = null;
			options.sales_book_selector = options.use_scriptable_selectors ? new custom_sales_book() : new form_helpers.sales_book_selector();
			ctx.form_links_manager.add_controller(options.sales_book_selector, sb_options);
		}
		if (options.dialog.new_assocaition_subform != null && options.dialog.new_assocaition_subform.autocomplete != null && options.dialog.btn_add != null)
		{
			var ac_options = helpers.merge_contexts(cleared_options, {
				"autocomplete": options.dialog.new_assocaition_subform.autocomplete,
				"btn_add": options.dialog.btn_add,
				"tag": options.mvg_tag,
				"related_selector": options.sales_book_selector
			});
			var controller = options.use_scriptable_selectors ? new scriptable_autocomplete_selector() : new form_helpers.autocomplete_selector();
			ctx.form_links_manager.add_controller(controller, ac_options);
		}
		if (options.dialog.view_ctrl != null)
		{
			var vc_options = helpers.merge_contexts(cleared_options, { "tag": options.mvg_tag });
			helpers.merge_contexts(helpers.get_restricted_context(options.dialog, ["view_ctrl", "btn_remove_association", "btn_remove", "btn_show_new", "btn_new"]), vc_options);
			helpers.merge_contexts({
				"delete_action": "remove_association"
			}, vc_options);
			ctx.form_links_manager.add_controller(new form_helpers.view_ctrl(), vc_options);
		}
		if (options.dialog.primary_selector != null)
		{
			options.primary_options = helpers.merge_contexts(cleared_options, {
				"ctrl": options.dialog.primary_selector,
				"tag": options.primary_tag,
				"ctrl_ex": new form_helpers.primary_selector_wrapper()
			});
			ctx.form_links_manager.add_controller(options.primary_options.ctrl_ex, options.primary_options);
		}
		if (options.dialog.primary_combobox != null)
		{
			options.primary_options = helpers.merge_contexts(cleared_options, {
				"ctrl": options.dialog.primary_combobox,
				"tag": options.primary_tag,
				"ctrl_ex": new form_helpers.primary_combobox_wrapper()
			});
			ctx.form_links_manager.add_controller(options.primary_options.ctrl_ex, options.primary_options);
		}
		if (options.dialog.btn_close != null)
		{
			options.btn_close = options.dialog.btn_close;
			options.btn_close.on_click.connect(function() { options.dialog.visible = false; });
		}
	}

	this.update_access = function(ctx, security_descriptor)
	{
		if (options.primary_options != null)
		{
			var access = security_descriptor.link_access(options.primary_options);
			options.primary_options.ctrl_ex.set_control_enabled(access.create && access.remove);
		}
	}

	this.disable = function()
	{
		if (options.dialog.visible)
			options.dialog.visible = false;
	}
}

/**
	@class Controller that tracks button events and show mvg dialog on click.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function mvg_dialog_button_controller()
{
	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.mvg_dialog_button_controller_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		if (options["btn_show_mvg"] != null)
			options["btn_show_mvg"].on_click.connect(init_and_show_dialog);
	}

	var show = function()
	{
		if (options.dialog_controller == null)
		{
			options.dialog_controller = new mvg_dialog_controller();
			ctx.form_links_manager.add_controller(options.dialog_controller, options);
		}
		options.dialog_controller.show();
	}

	var init_and_show_dialog = function()
	{
		if (options.disabled != true)
		{
			if (ctx.item_ex.get_id() != null)
				show();
			else if (ctx.item_ex.ensure_saved())
			{
				if (options.use_on_afrer_saved)
					ctx.form_links_manager.on_after_saved.connect(helpers.call_once(show));
				else
					show();
			}
		}
	}
}

/**
@private
*/
var shared = {
	"prepare_filter": function (ctx, source_dsc, keywords) {
		var filter = ctx.session.create_criteria("or");
		if (keywords.length) {
			helpers.for_each(source_dsc.search_by, function (field) {
				filter.add(ctx.session.create_expression(field, "like", /*"substr,ci:" +*/ keywords));
			});
		}
		return source_dsc.filter_fn(ctx, filter);
	},

	"item2id": function (ctx, item) {
		return item.id;
	},

	"filter": function (ctx, keywords_filter) {
		var filter = keywords_filter;
		if (this.and_filter || this.and_filter_fn) {
			filter = ctx.session.create_criteria("and");
			filter.add(keywords_filter);
			filter.add(this.and_filter ? this.and_filter : this.and_filter_fn(ctx));
		}
		return filter;
	},

	"display_name": function (ctx, item) {
		if (this.display_format)
			return helpers.parse_string(this.display_format, item);
	},

	"init_controller": function (ctx, options, additional_fn) {
		function init_sources() {
			var default_view_options = {
				"link_to": options.link_to,
				"item2id_fn": shared.item2id,
				"filter_fn": shared.filter,
				"display_name_fn": shared.display_name,
				"caption_is_resource": true,
				"allow_new": true,
				"visible": true
			};
			helpers.for_each2(options.sources, function (current_view) {
				helpers.merge_contexts(default_view_options, current_view);
				helpers.merge_contexts({
					"displayed_type": current_view.link_to,
					"display_format": (current_view.search_by) ? ":[:(" + current_view.search_by.join(") :]:[:(") + "):]" : null
				}, current_view);
			});
			if (additional_fn != null)
				additional_fn();
		}
		init_sources();

		var reinit_trigger = helpers.merge_contexts(helpers.get_restricted_context(options, ["type", "link_to", "tag"]), {
			"operation": "reinitialize_sources",
			"handler": form_helpers.disconnectable_handler(function (ctx, action_ctx) {
				if (action_ctx.notification_params != null && action_ctx.notification_params.sources != null)
					options.sources = action_ctx.notification_params.sources;
				init_sources();
			}, options)
		});
		ctx.triggers.add_trigger(reinit_trigger);
	},

	"get_caption": function (ctx, sources, item, item_id) {
		if (item == null && item_id != null)
			item = ctx.session.open_item(item_id);
		var caption = "";
		if (item != null) {
			var type = item.type_id;
			helpers.for_each(sources, function (source, p, for_each_ctx) {
				if (source.displayed_type == type) {
					caption = source.display_name_fn(ctx, item);
					for_each_ctx.interrupted = true;
				}
			});
		}
		return caption;
	}
}

/**
	@class Items selector based on custom Sales Book. Unlike {@link form_helpers.sales_book_selector} this selector allows to define custom filters, custom caption and other features.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function custom_sales_book()
{
var custom_sb_xml = 
'	<dialog>'
 + '		<layout sizable="true" id="General" min_height="220" min_width="400" caption="$caption" small_icon="app_small_icon">'
 + '			<appearance height="442" width="488" position="parent_center"></appearance>'
 + '			<cell>'
 + '				<stack layout="vert" padding="10" spacing="10">'
 + '					<cell size="39">'
 + '						<stack layout="horz" spacing="3" padding="5">'
 + '							<cell>'
 + '								<stack layout="vert" spacing="5">'
 + '									<cell size="15">'
 + '										<static id="lbl_keywords">'
 + '											<text>#ol_lookup-type_name_or_select_label</text>'
 + '										</static>'
 + '									</cell>'
 + '									<cell size="21">'
 + '										<scriptable_edit id="keywords" tab_order="1">'
 + '											<field value="string"/>'
 + '										</scriptable_edit>'
 + '									</cell>'
 + '								</stack>'
 + '							</cell>'
 + '							<cell size="152" attraction="far">'
 + '								<stack layout="vert" spacing="5">'
 + '									<cell size="15">'
 + '										<static id="lbl_view">'
 + '											<text>#ol_lookup-show_label</text>'
 + '										</static>'
 + '									</cell>'
 + '									<cell size="21">'
 + '										<combobox id="cb_view" tab_order="2">'
 + '											<field>View</field>'
 + '											<inmem_source/>'
 + '										</combobox>'
 + '									</cell>'
 + '								</stack>'
 + '							</cell>'
 + '						</stack>'
 + '					</cell>'
 + '					<cell>'
 + '						<outlook_view id="view" scriptable="true"/>'
 + '					</cell>'
 + '					<cell size="25">'
 + '						<stack layout="horz" spacing="5" padding="5">'
 + '							<cell size="75">'
 + '								<button id="btn_new" tab_order="3">'
 + '									<text>#btn_new_simple</text>'
 + '								</button>'
 + '							</cell>'
 + '							<cell>'
 + '							</cell>'
 + '							<cell size="75">'
 + '								<button id="btn_ok" tab_order="4">'
 + '									<text>#btn_ok</text>'
 + '								</button>'
 + '							</cell>'
 + '							<cell size="75">'
 + '								<button id="btn_cancel" tab_order="5">'
 + '									<text>#btn_cancel</text>'
 + '								</button>'
 + '							</cell>'
 + '						</stack>'
 + '					</cell>'
 + '				</stack>'
 + '			</cell>'
 + '		</layout>'
 + '	</dialog>';

	this.default_options = {
		"created_from_ctx_type": "std",
		"new_notification": false,
		"submited": false,
		"custom_sb_xml": custom_sb_xml,
		"custom_sb_template_params": {
			"caption": "#ol_lookup-caption"
		}
	};

	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.custom_sales_book_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		options.custom_sb_template_params = helpers.merge_contexts(this.default_options.custom_sb_template_params, options.custom_sb_template_params);

		options.link_notifier = ctx.form_links_manager.create_notifier({
			"operation": "link",
			"submited": options.submited,
			"tag": options.tag
		});

		options.btn_show.on_click.connect(form_helpers.disconnectable_handler(show_dialog, options));

		options.create_new_controller = new form_helpers.create_new_controller();
		ctx.form_links_manager.add_controller(options.create_new_controller, options);

		shared.init_controller(ctx, options, function()
		{
			if (options.sb_dialog != null)
			{
				prepare_combobox();
				update_view();
			}
		});
	}

	this.disable = function()
	{
		if (options.sb_dialog != null)
			close();
	}

	this.show = show_dialog;
	
	function show_dialog() {
		if (options.link.id_required != true || ctx.item_ex.ensure_saved())
		{
			if (options.sb_dialog == null) {
				options.sb_dialog = ctx.ui.create_dialog_from_xml(0, form_helpers.shared.apply_template_params(options.custom_sb_xml, options.custom_sb_template_params));
				var update_view_fn = form_helpers.disconnectable_handler(update_view, options);

				ctx.events.connect(options.sb_dialog.cb_view, "changed", update_view_fn);
				ctx.events.connect(options.sb_dialog.keywords, "on_changed", update_view_fn);

				ctx.events.connect(options.sb_dialog.view, "on_dbl_click", select_items);
				ctx.events.connect(options.sb_dialog.btn_ok, "on_click", select_items);
				ctx.events.connect(options.sb_dialog.btn_new, "on_click", create_new);

				ctx.events.connect(options.sb_dialog.btn_cancel, "on_click", close);
				prepare_combobox();
			}
			else {
				options.sb_dialog.keywords.value = "";
			}
			update_view();
			options.sb_dialog.visible = true;
		}
	}
	
	function prepare_combobox()
	{
		options.sb_dialog.cb_view.items.clear();
		var default_value = null;
		var count = 0;
		for (var key in options.sources)
		{
			var current_view = options.sources[key];
			if (current_view.visible)
			{
				var caption = current_view.caption;
				if (current_view.caption_is_resource)
					caption = ctx.session.res_string(caption);
				options.sb_dialog.cb_view.items.add(key, caption);
				if (default_value == null)
					default_value = key;
				count++;
			}
		}
		options.sb_dialog.cb_view.items.default_value = default_value;
		options.sb_dialog.cb_view.value = default_value;
		options.sb_dialog.cb_view.enabled = count > 1;
	}
	
	function get_view_dsc()
	{
		return options.sources[options.sb_dialog.cb_view.value];
	}

	function update_view() {
		var view_dsc = get_view_dsc();
		options.sb_dialog.view.set_view(view_dsc.view_id, view_dsc.displayed_type, shared.prepare_filter(ctx, view_dsc, options.sb_dialog.keywords.value));
		options.sb_dialog.btn_new.enabled = view_dsc.allow_new;
		options.sb_dialog.btn_new.visible = view_dsc.visible_new;
	}
	
	function select_items()
	{
		if (options.sb_dialog.view.selection_count)
		{
			var view_dsc = get_view_dsc();
			var action_ctx = helpers.merge_contexts(helpers.get_restricted_context(view_dsc, ["tag", "link_to"]), {
				"notification_params": { "with_ids": [] }
			});
			helpers.for_each(options.sb_dialog.view.selection, function(item) {
				action_ctx.notification_params.with_ids.push(view_dsc.item2id_fn(ctx, item));
			});
			options.link_notifier(action_ctx);
		}
		options.autocomplete.raise_changed();
		close();
	}
	
	function close()
	{
		options.sb_dialog.visible = false;
	}

	function init_dialog()
	{
		prepare_combobox();
		update_view();
	}
	
	function create_new()
	{
		options.create_new_controller.create_new({ "link_to": get_view_dsc().link_to }, true);
	}
	
	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options["btn_show"].enabled = access.create;
	}
}

/**
@private
*/
function scriptable_autocomplete_base()
{
	var ctx;
	var options;

	this.init = function(c, opt)
	{
		ctx = c;
		options = opt;

		options.autocomplete.need_data.connect(form_helpers.disconnectable_handler(fill_data, options));

		ctx.form_links_manager.add_controller(new form_helpers.autocomplete_opener(), options );

		shared.init_controller(ctx, options);
	}

	function fill_data(keyword) {
		helpers.for_each(options.sources, function (source) {
			if (source.visible) {
				var filter = shared.prepare_filter(ctx, source, keyword);
				helpers.for_each(ctx.session.find_items(source.displayed_type, filter), function (obj) {
					options.autocomplete.add_data(source.item2id_fn(ctx, obj), source.display_name_fn(ctx, obj), source.image);
				});
			}
		});
	}
}

/**
	@class Control wrapper based on scriptable autocomplete. It has the same appearance as {@link form_helpers.autocomplete_wrapper} but is more flexible.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.autocomplete_wrapper
*/
function scriptable_autocomplete_wrapper() {
	scriptable_autocomplete_base.apply(this);
	this.scriptable = true;

	var ctx;
	var options;

	var base_init = this.init;
	var on_changed;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.scriptable_autocomplete_wrapper_options} options
	*/
	this.init = function(c, opt) {
		base_init.apply(this, arguments);

		ctx = c;
		options = opt;

		options.field = options.link.field;
		set_value(ctx.item_ex.get_property(options.field));

		on_changed = new helpers.signal();
		options.autocomplete.changed.connect(form_helpers.disconnectable_handler(raise_changed, options));
		this.on_changed = on_changed;
	}

	this.select = function(value)
	{
		set_value(value);
		raise_changed();
	}

	this.get_selected = function()
	{
		return options.autocomplete.selected;
	}

	this.set_control_enabled = function(value)
	{
		options.autocomplete.enabled = value;
	}
	
	function set_value(value)
	{
		options.autocomplete.assign(value, shared.get_caption(ctx, options.sources, null, value));
	}

	function raise_changed()
	{
		ctx.form.item[options.field] = options.autocomplete.selected;
		on_changed.raise();
	}
	
	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options.autocomplete.enabled = access.create;
	}
}

/**
	@class Items selector based on scriptable autocomplete. It has the same appearance as {@link form_helpers.sales_book_selector} but is more flexible.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.autocomplete_selector
*/
function scriptable_autocomplete_selector()
{
	scriptable_autocomplete_base.apply(this);

	var ctx;
	var options;

	var base_init = this.init;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.scriptable_autocomplete_selector_options} options
	*/
	this.init = function(c, opt)
	{
		base_init.apply(this, arguments);

		ctx = c;
		options = opt;

		options.link_notifier = ctx.form_links_manager.create_notifier({
			"operation": "link",
			"submited": options.submited,
			"tag": options.tag
		});

		options["btn_add"].on_click.connect(form_helpers.disconnectable_handler(on_add, options));
	}

	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options.autocomplete.enabled = access.create;
		options["btn_add"].enabled = access.create;
	}

	var on_add = function()
	{
		var selected_id = options.autocomplete.selected;
		if (selected_id != null)
		{
			if (options.link.id_required != true || ctx.item_ex.ensure_saved())
			{
				var notification_params = { "with_ids": [selected_id] };
				options.link_notifier({ "notification_params": notification_params });
				if (notification_params.link_results != null && notification_params.link_results[0].result.success == true)
					options.autocomplete.assign(null, "");
			}
		}
		else if (options.related_selector != null)
			options.related_selector.show();
	}
}

/**
@private
*/
function mvg_initial_selector()
{
	this.default_options = {
		"primary_tag": "direct",
		"mvg_tag": "mvg"
	}
	
	var ctx;
	var options;

	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		var link_ctx = {
			"item_ex": ctx.item_ex,
			"link_to": options.link_to,
			"submited": false
		};

		var visible = !ctx.linker.linked(helpers.merge_contexts(link_ctx, { "tag": options.primary_tag })).count && !ctx.linker.linked(helpers.merge_contexts(link_ctx, { "tag": options.mvg_tag })).count;
		set_visibility(visible);
		if (visible)
		{
			ctx.triggers.add_simple_trigger(analize_result, options.type, options.link_to, options.primary_tag, "created");
			ctx.triggers.add_simple_trigger(analize_result, options.type, options.link_to, options.mvg_tag, "created");

			options.link_notifier = ctx.form_links_manager.create_notifier({
				"operation": "link",
				"tag": options.mvg_tag
			});
			options.autocomplete.changed.connect(form_helpers.disconnectable_handler(perform_link, options));
		}
	}
	
	var set_visibility = function(value)
	{
		function set_control_visibility(ctrl, visible)
		{
			ctrl.visible = visible;
		}
		helpers.for_each(options.initialy_hidden, set_control_visibility, !value);
		helpers.for_each(options.initialy_visible, set_control_visibility, value);
		set_control_visibility(options.replaced_ctrl, !value);
		set_control_visibility(options.autocomplete, value);
	}

	var analize_result = function(ctx, action_ctx)
	{
		if (action_ctx.result.success && action_ctx.with_id != null)
			set_visibility(false);
	}

	var perform_link = function()
	{
		var selected_id = options.autocomplete.selected;
		if (selected_id != null)
		{
			var notification_params = { "with_ids": [selected_id] };
			if (ctx.item_ex.ensure_saved())
				options.link_notifier({ "notification_params": notification_params });
			if (notification_params.link_results != null && notification_params.link_results[0].result.success == true)
				options.replaced_ctrl.set_focus();
			else
				options.autocomplete.selected = null;
		}
	}
}

function inline_mvg()
{
	this.default_options = {
		"mvg_tag": "mvg",
		"primary_tag": "direct"
	}

	var ctx;
	var options;
	var on_changed = new helpers.signal();
	
	var mvg_link;

	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		shared.init_controller(ctx, options);

		mvg_link = ctx.links.get_link(helpers.merge_contexts(options, { "tag": options.mvg_tag })).link;

		options.inline_mvg.on_new_item_detected.connect(form_helpers.disconnectable_handler(on_new_item_detected, options));
		options.inline_mvg.on_context_menu.connect(form_helpers.disconnectable_handler(on_context_menu, options));
		options.inline_mvg.on_context_menu_click.connect(form_helpers.disconnectable_handler(on_context_menu_click, options));

		var primary_link = ctx.links.get_link(helpers.merge_contexts(options, { "tag": options.primary_tag })).link;
		if (options.show_primary == null)
			options.show_primary = primary_link != null;

		if (options.show_primary)
		{
			var primary_linked = ctx.linker.linked(helpers.merge_contexts(primary_link, { "item_ex": ctx.item_ex })).value;
			set_primary(primary_linked);

			this.scriptable = true;
			this.on_changed = on_changed;
			this.get_selected = get_selected;
			this.select = function(value) { set_primary(value, true); };
			this.set_control_enabled = function(value) { };
		}
	}

	function get_linked_id(item)
	{
		var result = null;
		if (item.id != null)
		{
			var association = ctx.session.open_item(item.id);
			result = mvg_link.resolve_association(ctx, association);
			util.disconnect_object(association);
		}
		else
			result = item.data.with_id;
		return result;
	}

	function set_primary(value, raise_changed)
	{
		var primary_item = null;
		if (value != null)
		{
			helpers.for_each(options.inline_mvg.items, function(item, param, for_each_ctx)
			{
				if (helpers.ids_equal(ctx.session, get_linked_id(item), value))
				{
					primary_item = item;
					for_each_ctx.interrupted = true;
				}
			});
			if (primary_item == null)
			{
				var primary_item = options.inline_mvg.add_item(shared.get_caption(ctx, options.sources, null, value));
				primary_item.data = { 
					"with_id": value 
				};
			}
		}
		options.inline_mvg.set_primary(primary_item);
	}
	
	function get_selected()
	{
		var selected = null;
		helpers.for_each(options.inline_mvg.items, function(item, param, for_each_ctx)
		{
			if (item.primary)
			{
				selected = get_linked_id(item);
				for_each_ctx.interrupted = true;
			}
		});
		return selected;
	}
	
	function on_new_item_detected(new_item)
	{
		var primary = false;
		var new_id = get_linked_id(new_item);
		helpers.for_each(options.inline_mvg.items, function(item, param, for_each_ctx)
		{
			if (item.id == null && helpers.ids_equal(ctx.session, get_linked_id(item), new_id))
			{
				primary = item.primary;
				options.inline_mvg.remove_item(item);
				for_each_ctx.interrupted = true;
			}
		});
		if (primary)
			options.inline_mvg.set_primary(new_item);
	}
	
	function on_context_menu()
	{
		if (options.show_primary)
			options.inline_mvg.add_menu_item("set_primary", ctx.session.res_string("inline_mvg_set_primary"), 0);
	}

	function on_context_menu_click(id)
	{
		helpers.for_each(options.inline_mvg.selection, function(item, param, for_each_ctx) {
			switch (id)
			{
				case "set_primary":
					for_each_ctx.interrupted = true;
					set_primary(get_linked_id(item), true);
					break;
			}
		});
	}
}