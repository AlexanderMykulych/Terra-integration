include("helpers.js", "helpers");
include("data_model.js", "data_model");

/**
	@class Class that wraps Outlook View control and implements interface for basic operations
	@constructor
	@param {session} session Session object provided by C++
	@param {ui} ui UI object provided by C++
	@param {security_manager} security_manager Security manager object (can be get from application script)
	@memberOf form_helpers
	@deprecated
*/
function view_controls_handler(session, ui, security_manager)
{
	var events = new helpers.events_connection();
	
	var binder = function(view_ctrl, ext_handler, event_name, pass_single_item)
	{
		var get_first_item = function(selection)
		{
			var enm = new Enumerator(selection);
			return enm.atEnd() ? null : enm.item();
		}

		var handler = function()
		{
			if (pass_single_item)
			{
				var item = get_first_item(view_ctrl.selection);
				if (item != null)
					ext_handler.execute(item);
			}
			else
				ext_handler.execute(view_ctrl.selection);
		}
		events.connect(view_ctrl, event_name, handler);
	}

	var native_opener = function()
	{
		this.execute = function(item)
		{
			if (security_manager.view_access(item))
				session.display_item(item);
			else
				ui.message_box(0, session.res_string("msg_cant_view_item"), session.res_string("msg_cant_delete_item_caption"), 0x30);
		}
	}
	
	var dialog_opener = function(dialog_id)
	{
		var dialog = null;
		
		this.dialog = function(item)
		{
			if (dialog == null)
				dialog = ui.create_dialog(0, dialog_id);
			return dialog;
		}

		this.execute = function(item)
		{
			if (security_manager.view_access(item))
			{
				this.dialog().item = item;
				this.dialog().visible = true;
			}
			else
				ui.message_box(0, session.res_string("msg_cant_view_item"), session.res_string("msg_cant_delete_item_caption"), 0x30);
		}
	}
	
	var physical_item_deleter = function()
	{
		this.execute = function(selection)
		{
			var has_undeleted = false;
			var confirmed = false;
			var items_count = 0;
			for (var enm = new Enumerator(selection); !enm.atEnd(); enm.moveNext())
			{
				items_count++;
				var item = enm.item();
				if (security_manager.delete_access(item))
				{
					if (!confirmed && !helpers.delete_confirmation(ui, session))
						return;
					confirmed = true;
					item.Remove();
				}
				else
					has_undeleted = true;
			}
			if (has_undeleted)
				ui.message_box(0, session.res_string(items_count > 1 ? "msg_can_delete_all_item" : "msg_cant_delete_item"), session.res_string("msg_cant_delete_item_caption"), 0x40);
		}
	}
	
	var by_helper_deleter = function(helper, raise_changed_callback)
	{
		this.execute = function(selection)
		{
			var local_raise_changed = null;
			for (var enm = new Enumerator(selection); !enm.atEnd(); enm.moveNext())
			{
				local_raise_changed = raise_changed_callback;
				helper.mark_for_delete(enm.item());
			}
			if (local_raise_changed)
				local_raise_changed();
		}
	}

	var get_object_from_association_adapter = function(inner, helper)
	{
		this.execute = function(item)
		{
			item = session.open_item(helper.get_assocaited_obj_id(item));
			if (item != null)
				inner.execute(item);
			else
  				ui.message_box(0, session.res_string("msg_no_object_found"), session.res_string("msg_mvg_warning"), 0x30);
			    
		}
	}
	
	/**
		Creates and returns the instance of native_opener
		@returns Instance of native_opener
	*/
	this.native_opener = function()
	{
		return new native_opener();
	}
	
	/**
		Creates and returns the instance of dialog_opener
		@param dialog_id Id of a dialog UI, described in dialogs.xml
		@returns Instance of dialog_opener
	*/
	this.dialog_opener = function(dialog_id)
	{
		return new dialog_opener(dialog_id);
	}
		
	/**
		Creates and returns the instance of physical_item_deleter
		@returns Instance of physical_item_deleter
	*/
	this.physical_item_deleter = function()
	{
		return new physical_item_deleter();
	}
	
	/**
		Creates and returns the instance of by_helper_deleter
		@param helper Helper object that performs deletion
		@param raise_changed_callback Callback function called when item deleted
		@returns Instance of by_helper_deleter
	*/
	this.by_helper_deleter = function(helper, raise_changed_callback)
	{
		return new by_helper_deleter(helper, raise_changed_callback);
	}
	
	/**
		Creates and returns the instance of get_object_from_association_adapter
		@param inner Instance of items opener
		@param helper Instance of helper class
		@returns Instance of get_object_from_association_adapter
	*/
	this.get_object_from_association_adapter = function(inner, helper)
	{
		return new get_object_from_association_adapter(inner, helper);
	}

	/**
		Add support for view control that displays items
		@param ctrl View control
		@param opener Instance of items opener class
		@param deleter Instance of items deleter class
	*/
	this.add_view_ctrl = function(ctrl, opener, deleter)
	{
		if (opener != null)
			new binder(ctrl, opener, "on_dbl_click", true);
		if (deleter != null)
			new binder(ctrl, deleter, "on_delete_clicked");
	}

	/**
		Add support for view control that displays associations
		@param ctrl View control
		@param inner_opener Instance of items opener class
		@param helpers_group Helpers factory
		@param type Items type
		@param raise_changed_callback Callback function called when item changed
		@param {Boolean} supress_delete Deletion prohibited flag
	*/
	this.add_association_view_ctrl = function(ctrl, inner_opener, helpers_group, type, raise_changed_callback, supress_delete)
	{
		var helper = helpers_group.get(type);
		this.add_view_ctrl(ctrl, this.get_object_from_association_adapter(inner_opener, helper), supress_delete ? null : this.by_helper_deleter(helper, raise_changed_callback));
	}
}

/**
	@class Class that implements action calls on button events
	@constructor
	@param action_manager Action manager object
	@param {form} form Outlook form object
	@memberOf form_helpers
	@deprecated
*/
function button_action_caller(action_manager, form)
{
	var events = new helpers.events_connection();

	var binder = function(button, action_name)
	{
		var handler = function()
		{
			action_manager.execute_from_form(action_name, form);
		}
		
		events.connect(button, "on_click", handler);
	}
	
	/**
		Add action for button
		@param button Button control
		@param action_name Name of action
	*/
	this.add = function(button, action_name)
	{
		new binder(button, action_name);
	}
}

/**
	@class Wrapper class for salesbook functionality provided by C++
	@constructor
	@param app Application object provided by C++
	@param view_ids Array if view ids
	@param on_selected Callback function called when item was selected
	@param on_new_item Callback function called when item was created
	@memberOf form_helpers
	@deprecated
*/
function builtin_sales_book(app, view_ids, on_selected, on_new_item)
{	
	var on_new_object = function(type, keywords)
	{
		var item = app.session.create_item(type);
		var display = true;
		if (on_new_item != null)
			display = on_new_item(item, keywords);
		if (display == true)
			app.session.display_item(item);
	}
	
	var on_closed = function(ok, selection)
	{
		if (ok && on_selected != null)
			on_selected(selection)
	}
	
	/**
		Show salesbook
	*/
	this.show = function()
	{
		m_dialog.visible = true;	
	}
	
	/**
		Closes salesbook
	*/
	this.close = function()
	{
		m_dialog.visible = false;
	}

	var m_dialog = app.lookup.create_builtin_dialog(util.jsarray_to_vbarray(view_ids), 0);	
	m_dialog.on_new_object.connect(on_new_object);
	m_dialog.on_closed.connect(on_closed);
}

/**
	@class Class that performs linking between object using autocomplete control
	@constructor
	@param shared_objects Collection of global object (application script)
	@param ac_control Autocomplete control
	@memberOf form_helpers
	@deprecated
*/
function new_item_to_autocomplete(shared_objects, ac_control)
{
	var cfp_manager = shared_objects.cfp_manager;

	function autocomplete_value_setter()
	{
		this.post_save_action_required = true;
		
		this.form_saved = function(form)
		{
			ac_control.selected = form.item.id();
			ac_control.raise_changed();
		}
	}
	
	var on_new_item = function(item, keywords)
	{
		cfp_manager.add_descriptor(item, new autocomplete_value_setter());
		return true;
	}
	
	this.on_new_item_handler = on_new_item;
}

/**
	@class Class that implements opening item selected on autocomplete control
	@constructor
	@param {session} session Session object provided by C++
	@param {ui} ui UI object provided by C++
	@param {meta_scheme} meta_scheme Meta scheme, can be get from application script or created manualy
	@param {security_manager} security_manager Security manager object (can be get from application script)
	@param ctrl Autocomplete control
	@memberOf form_helpers
	@deprecated
*/
function auto_complete_item_opener(session, ui, meta_scheme, security_manager, ctrl)
{
	var events = new helpers.events_connection();

	var handler = function()
	{
		var events_copy = events; // VT: Prevents Garbage collector to remove events object
		var item = session.open_item(ctrl.selected);
		var obj_descr = meta_scheme.get_object_descriptor(item.type_id);
		if (obj_descr != null && obj_descr.view_method == "native")
		{
			if (security_manager.view_access(item))
				session.display_item(item);
			else
				ui.message_box(0, session.res_string("msg_cant_view_item"), session.res_string("msg_attach_note"), 0x30);
		}
	}
		
	events.connect(ctrl, "on_display_selection", handler);
}

/**
	@class Class that implements functionality for autocomplete and salesbook
	@constructor
	@param {application} app Application object provided by C++
	@param {ui} ui UI object provided by C++
	@param {meta_scheme} meta_scheme Meta scheme, can be get from application script or created manualy
	@param {security_manager} security_manager Security manager object (can be get from application script)
	@param obj_type Type of object
	@param field Field name used by autocomplete
	@param ac_control Autocomplete control
	@param open_control Button used to open salesbook
	@param on_selected Callback function called when item was selected
	@param on_new_item Callback function called when item was created
	@memberOf form_helpers
	@deprecated
*/
function auto_complete_with_sales_book(app, ui, meta_scheme, security_manager, obj_type, field, ac_control, open_control, on_selected, on_new_item)
{
	var field_descr = meta_scheme.get_object_descriptor(obj_type).fields[field];
	var events = new helpers.events_connection();

	var std_on_selected = function(selection)
	{
		var events_copy = events; // VT: Prevents Garbage collector to remove events object
		var enm = new Enumerator(selection);
		if (!enm.atEnd())
		{
			ac_control.selected = enm.item().id;
			ac_control.raise_changed();
		}
	}
	if (on_selected == null)
		on_selected = std_on_selected;
	
	var sales_book;
	var open_sales_book = function()
	{
		var events_copy = events; // VT: Prevents Garbage collector to remove events object
		if (sales_book == null)
			sales_book = new builtin_sales_book(app, field_descr.view_ids, on_selected, on_new_item);
		sales_book.show();
	}

	var ac_handler;
	if (ac_control != null)
		ac_handler = new auto_complete_item_opener(app.session, ui, meta_scheme, security_manager, ac_control);
	if (open_control != null)
		events.connect(open_control, "on_click", open_sales_book);
}

/**
	Function that detects is control a combo box
	@param ctrl Combo box control
	@returns {Boolean} Is control a combo box
	@memberOf form_helpers#
	@deprecated
*/
var is_combo_box_selector = function(ctrl)
{
	return ctrl.items != null;
}

/**
	Function applyes filter for combo box control
	@param ctrl Combo box control
	@memberOf form_helpers#
	@deprecated
*/
var set_filter = function(ctrl, filter)
{
	if (is_combo_box_selector(ctrl))
		ctrl = ctrl.items;
	ctrl.filter = filter;
}

/**
	@class Function that will return Dialog object for use in MVG factory
	@constructor
	@param id Id of a dialog UI, described in dialogs.xml
	@memberOf form_helpers
	@deprecated
*/
function mvg_std_dialog(id)
{
	var dialog = null;

	/**
		Creates and initialized MVG dialog
		@param {session} session Session object provided by C++
		@param {ui} ui UI object provided by C++
		@param helper Can be exctacted from mvg_helpers_group by method get
		@param item Parent item
		@param {events} events Signal connection manager
	*/
	this.init = function(session, ui, helper, item, events)
	{
		dialog = ui.create_dialog(0, id);
		dialog.item = item;
		this.form = dialog;
		var new_record_subform = dialog.newRecord_subform;
		if (new_record_subform != null)
		{
			dialog.newRecord_subform.item = session.create_item(helper.type);
			this.right_link_lookup = dialog.newRecord_subform.lp_right_link;
			this.select_btn = dialog.newRecord_subform.btn_lp_right_link;
			this.add_btn = dialog.newRecord_subform.btn_add;
		}
		this.associations_view = dialog.associations_list;
		this.remove_btn = dialog.btn_remove;
		this.primary_selector = dialog.primary_assoc;
		events.connect(dialog.btn_close, "on_click", create_function(dialog, "close"));
	}

	/**
		Shows or hides MVG dialog
		@param {Boolean} visible Visibility flag
	*/
	this.display = function(visible)
	{
		if (dialog != null)
			dialog.visible = visible;
	}

	/**
		Refreshes controls on MVG dialog
	*/
	this.refresh = function()
	{
		if (dialog != null)
			dialog.item = dialog.item;
	}
}

/**
	@deprecated
*/
function mvg_custom_controls(associations_view, lookup_subform, right_link_lookup, add_btn, remove_btn, primary_selector, select_btn)
{
	this.associations_view = associations_view;
	this.right_link_lookup = right_link_lookup;
	this.add_btn = add_btn;
	this.remove_btn = remove_btn;
	this.primary_selector = primary_selector;
	this.select_btn = select_btn;

	var initialized = false;

	this.init = function(session, ui, helper, item, events)
	{
		if (lookup_subform != null)
			lookup_subform.item = session.create_item(helper.type);
		var result = !initialized;
		initialized = true;
		return result;
	}

	this.display = function(visible)
	{}

	this.refresh = function()
	{}
}

/**
	@type Defines access type (full, read only or read only primary)
	@memberOf form_helpers#
	@deprecated
*/
var mvg_access_type =
{
	read_write:0,
	primary_readonly:1,
	readonly:2
}

/**
	@class Class that implements logic for MVG dialog
	@constructor
	@param {application} application Application object provided by C++
	@param {ui} ui UI object provided by C++
	@param {meta_scheme} meta_scheme Meta scheme, can be get from application script or created manualy
	@param {security_manager} security_manager Security manager object (can be get from application script)
	@param dialog Object that describes mvg dialog or set of onform controls
	@param helper Can be exctacted from mvg_helpers_group by method get
	@param {form} form Outlook form object
	@param {events} events Signal connection manager
	@param msg_prefix prefix for resource names that will be used to notify user. Usually three resources are used:
			<br>msg_prefix + "_present"
			<br>msg_prefix + "_is_primary"
			<br>msg_prefix + "_add_caption"
	@param can_delete_primary bool param that allows or denies deletion of assocaition that marked as primary
	@param event_add Call function that is called when association added, assocaited item id will be passed as param (can be null)
	@param event_remove Call function that is called when association removed, assocaited item id will be passed as param (can be null)
	@param primary_control Primary control on parent form. Can be null
	@param special_update_fn If previous param is null and raise_changed cannot be called for primary control on form. If you want form to mark dirty after association add/remove pass callback function by this param which will mark form dirty. You can create callback by helper function raise_changed_from_control
			<br>Example: var raise_changed callback = (new raise_changed_from_control(ctrl)).callback  (syntax high light)
			<br> where ctrl is any custom control on form.
	@param [custom_filter] Filter for autocomplete control
	@memberOf form_helpers
	@deprecated
*/
function mvg_dialog_logic(application, ui, meta_scheme, security_manager, dialog, helper, form, events, msg_prefix, can_delete_primary, event_add, event_remove, primary_control, special_update_fn, custom_filter)
{
	var refresh_combobox = function(ctrl)
	{
		if (ctrl != null && is_combo_box_selector(ctrl))
			ctrl.items.filter = helper.get_actual_state_filter();
	}
	
	var refresh_comboboxes = function()
	{
		refresh_combobox(primary_control);
		refresh_combobox(dialog.primary_selector);
	}

	var activate_dialog = function()
	{
		dialog.form.visible = true;
	}

	var add_assoc = function(right_ids)
	{
		if (!include.helpers.ensure_saved(application.session, ui, item))
			return -1;
		var added_count = 0;
		for (var key in right_ids)
		{
			var right_id = right_ids[key];
			var new_assoc = helper.associate(item, right_id);
			if (new_assoc != null)
			{
				helper.save(new_assoc);
				if (added_count == 0)		
					set_primary(false);
				added_count++;
				if (event_add != undefined)
					event_add(right_id);
			}
		}
		refresh_comboboxes();
		update_delete_button_state();
		activate_dialog();
		return added_count;
	}
	
	var process_selection = function(selected)
	{
		var ids = new Array();
		for (var enm = new Enumerator(selected); !enm.atEnd(); enm.moveNext())
		{	ids.push(enm.item().id());	}
		
		if (ids.length != 0)
		{
			var added_count = add_assoc(ids);
			if (added_count != -1 && added_count != ids.length)
				ui.message_box(0, msg_present, msg_add_caption, 0x30);
		}
	}

	var on_add_clicked = function()
	{
		var right_id = dialog.right_link_lookup.selected;
		if (right_id != null && add_assoc(new Array(right_id)) == 0)
			ui.message_box(0, msg_present, msg_add_caption, 0x30);
		else
			dialog.right_link_lookup.selected = null;
	}
	
	var new_item_created = function()
	{
		set_primary(false);
		refresh_comboboxes();
		activate_dialog();
	}

	var set_primary = function(force_update)
	{
		if (dialog.primary_selector != null)
		{
			if (dialog.primary_selector.value == null || force_update)
			{
				refresh_comboboxes();
				var any_assoc = helper.get_any_associated(item);
				if (any_assoc != null || !is_combo_box_selector(dialog.primary_selector))
					dialog.primary_selector.value = any_assoc;
			}
			dialog.primary_selector.raise_changed();
		}
		else if (special_update_fn != null)
			special_update_fn();
		activate_dialog();
	}

	var on_remove_clicked = function()
	{
		var primary_removed = false;
		var enm = new Enumerator(dialog.associations_view.selection);
		for (; !enm.atEnd(); enm.moveNext())
		{
			var selected_item = enm.item();
			var remove_item_right_id = helper.get_assocaited_obj_id(selected_item);
			var selected_primary = null;
			if (dialog.primary_selector != null)
				selected_primary = dialog.primary_selector.value;
			var current_item_is_primary = selected_primary != null && application.session.equal_ids(selected_primary, remove_item_right_id);
			if (can_delete_primary || !current_item_is_primary)
			{
				helper.mark_for_delete(selected_item);
				if (event_remove != null)
					event_remove(remove_item_right_id);
				primary_removed = primary_removed || current_item_is_primary;
			}
			else
				ui.message_box(0, msg_is_primary, application.session.res_string("msg_mvg_warning"), 0x30);
		}
		set_primary(primary_removed);
		refresh_comboboxes();
		update_delete_button_state();
		activate_dialog();
	}

	var update_delete_button_state = function()
	{
		if (dialog.remove_btn != null)
			dialog.remove_btn.enabled = form_access_type != mvg_access_type.readonly && dialog.associations_view.selection_count != 0;
	}

	var set_enabled = function(ctrl, enabled)
	{
		if (ctrl != null)
			ctrl.enabled = enabled;
	}

	/**
		Displays MVG dialog
		@param {form_helpers.mvg_access_type} access_type Acces type option
	*/
	this.display = function(access_type)
	{
		if (!disabled)
		{
			if (custom_filter != undefined)
				set_filter(dialog.right_link_lookup, custom_filter);

			form_access_type = access_type;
			var read_only = access_type == mvg_access_type.readonly;
			set_enabled(dialog.right_link_lookup, !read_only);
			set_enabled(dialog.add_btn, !read_only);
			set_enabled(dialog.select_btn, !read_only);
			if (dialog.primary_selector != null)//for OpportunityToContact
			{
				if (primary_control != null)
				{
					var value = primary_control.value;
					if (value != null)
						dialog.primary_selector.value = value;
				}
				dialog.primary_selector.enabled = access_type == mvg_access_type.read_write;
			}
			update_delete_button_state();
			if (dialog.primary_selector != null && primary_control != null)
				if (form != null && dialog.form != null)
					application.forms.link_controls(form, primary_control, dialog.form, dialog.primary_selector);
			dialog.display(true);
		}
	}

	/**
		Refreshes dialog
	*/
	this.refresh_controls = function()
	{
		dialog.refresh();
	}
	
	/**
		Disables controls
	*/
	this.disable = function()
	{
		dialog.display(false);
		disabled = true;
	}

	var item = form.item;
	var disabled = false;
	var session = application.session;

	var msg_present = msg_prefix != null ? session.res_string(msg_prefix + "_present") : "";
	var msg_is_primary = msg_prefix != null ? session.res_string(msg_prefix + "_is_primary") : "";
	var msg_add_caption = msg_prefix != null ? session.res_string(msg_prefix + "_add_caption") : "";

	var form_access_type = mvg_access_type.readonly;
	var ac_with_sb;
	if (primary_control != null)
		set_filter(primary_control, helper.get_actual_state_filter());
	
	dialog.init(session, ui, helper, item, events, new_item_created);
	if (dialog.add_btn != null)
		events.connect(dialog.add_btn, "on_click", on_add_clicked);
	if (dialog.right_link_lookup != null && dialog.select_btn != null)
	{
		ac_with_sb = new auto_complete_with_sales_book
			(application, ui, meta_scheme, security_manager, helper.type, helper.right_link, dialog.right_link_lookup, dialog.select_btn, process_selection);
	}
	if (dialog.remove_btn != null)
		events.connect(dialog.remove_btn, "on_click", on_remove_clicked);
	if (dialog.associations_view != null)
		events.connect(dialog.associations_view, "on_selection_changed", update_delete_button_state);
	if (dialog.primary_selector != null)
		set_filter(dialog.primary_selector, helper.get_actual_state_filter());
	events = null;
}

/**
	@class Factory that creates MVG dialog with all the logic.
	@constructor
	@param {application} application Application object provided by C++
	@param {ui} ui UI object provided by C++
	@param {meta_scheme} meta_scheme Meta scheme, can be get from application script or created manualy
	@param {security_manager} security_manager Security manager object (can be get from application script)
	@param dialog Object that describes mvg dialog or set of onform controls
	@param helper Can be exctacted from mvg_helpers_group by method get
	@param msg_prefix prefix for resource names that will be used to notify user. Usually three resources are used:
			<br>msg_prefix + "_present"
			<br>msg_prefix + "_is_primary"
			<br>msg_prefix + "_add_caption"
	@param can_delete_primary bool param that allows or denies deletion of assocaition that marked as primary
	@param event_add Call function that is called when association added, assocaited item id will be passed as param (can be null)
	@param event_remove Call function that is called when association removed, assocaited item id will be passed as param (can be null)
	@param primary_control Primary control on parent form. Can be null
	@param special_update_fn If previous param is null and raise_changed cannot be called for primary control on form. If you want form to mark dirty after association add/remove pass callback function by this param which will mark form dirty. You can create callback by helper function raise_changed_from_control
			<br>Example: var raise_changed callback = (new raise_changed_from_control(ctrl)).callback  (syntax high light)
			<br> where ctrl is any custom control on form.
	@param [custom_filter] Filter for autocomplete control
	@memberOf form_helpers
	@deprecated
*/
function mvg_dialog_factory(application, ui, meta_scheme, security_manager, dialog, helper, msg_prefix, can_delete_primary, event_add, event_remove, primary_control, special_update_fn, custom_filter)
{
	if (primary_control != null)
		set_filter(primary_control, helper.get_actual_state_filter());

	/**
		Creates new MVG dialog with logic
		@param {form} form Outlook form object
		@param {events} events Signal connection manager
		@returns MVG dialog wrapper
	*/
	this.create = function(form, events)
	{
		return new mvg_dialog_logic(application, ui, meta_scheme, security_manager, dialog, helper, form, events, msg_prefix, can_delete_primary, event_add, event_remove, primary_control, special_update_fn, custom_filter);
	}
}

/**
	@class Creates MVG dialog button wrapper class
	@constructor
	@param {ui} ui UI object provided by C++
	@param {session} session Session object provided by C++
	@param {events} events Signal connection manager
	@param factory Dialogs factory
	@param btn Button that opens dialog
	@param {form} form Outlook form object
	@param controlling_item Subform item (if exists)
	@param check_access_type Function that provides acces type option
	@memberOf form_helpers
	@deprecated
*/
function mvg_dialog_button(ui, session, events, factory, btn, form, controlling_item, check_access_type)
{
	var disabled = false;
	var dialog_events = null;
	var dialog = null;

	var display = function()
	{
		if (!disabled && helpers.ensure_saved(session, ui, form.item, controlling_item))
		{
			if (dialog == null)
			{
				dialog_events = new helpers.events_connection();
				dialog = factory.create(form, events);
			}
			dialog.display(check_access_type == null ? mvg_access_type.read_write : check_access_type());
		}
	}

	events.connect(btn, "on_click", display);

	/**
		Refreshes controls
	*/
	this.refresh_controls = function()
	{
		if (dialog != null)
			dialog.refresh_controls();
	}
	
	/**
		Disables dialog
	*/
	this.disable = function()
	{
		disabled = true;
		if (dialog != null)
		{
			dialog.disable();
			dialog = null;
			dialog_events = null;
		}
	}
}

/**
	@class Class that creates raise_changed callback for control
	@constructor
	@param other_control Control
	@memberOf form_helpers
	@deprecated
*/
function raise_changed_from_control(other_control)
{
	var raise = function()
	{
		other_control.raise_changed();
	}

	this.callback = raise;
}

/** 
	@class Class constructor, that will return an object, which will be used to define validation rules on a Form.
	@constructor
	@param {session} session Session object provided by C++
	@param {form} form Outlook form object
	@param state_fn Function that provides current state
	@param {subform} subform Subform object in case of subform validation
	@memberOf form_helpers
*/
function form_validator(session, form, state_fn, subform)
{
	var empty_array = new Array();

	var validators = new Array();
	var enabled = true;

	var add_validator = function(ids, message, handler, group)
	{
		var validator = new Object();
		validator.ids = util.jsarray_to_vbarray(ids != null ? ids : empty_array);
		validator.message = message;
		validator.fn = handler;
		validator.group = group;
		validators.push(validator);
	}

	var validation_ctx = function(session, item)
	{
		this.item = item;

		var snapshot = null;
		this.snapshot = function()
		{
			if (snapshot == null)
				snapshot = item.snapshot;
			return snapshot;
		}

		var id = false;
		this.id = function()
		{
			if (id == false)
				id = helpers.safe_get_id(item);
			return id;
		}

		var message = null;
		var is_res_id = true;

		this.set_message = function(mess, is_res)
		{
			message = mess;
			is_res_id = is_res;
		}

		this.get_message = function()
		{
			return is_res_id && message != "" ? session.res_string(message) : message;
		}

		this.interrupted = false;
		this.interrupt = function()
		{
			this.interrupted = true;
		}
	}

	var validate = function (ctx) {
		if (enabled) {
			var state = state_fn != null ? state_fn() : null;
			var validated_form = subform == null ? form : subform;

			var item = validated_form.item;
			var validator_ctx = new validation_ctx(session, item);
			for (var key in validators) {
				var validator = validators[key];
				var applicable = state == null || validator.group == null || helpers.contains(state, validator.group);
				if (applicable) {
					validator_ctx.set_message(validator.message, true);
					var result = validator.fn(validator_ctx);
					if (result != true)
						(subform == null ? ctx : ctx.subform(subform)).add_invalidated(validator.ids, validator_ctx.get_message());
					if (validator_ctx.interrupted)
						break;
				}
			}
			util.disconnect_object(item);
		}
	}
	form.on_validate.connect(validate);
	if (subform != null)
		form.register_subform(subform);
	
	var is_empty_value = function(value)
	{
		return value ==null || value == "";
	}

	/**
		Function of the validation object, that will return validator to validate uniquity of a field value 
		@param fields Array of fileds names for validation
		@param {Boolean} skip_empty_validation If True, empty fields will not be validated
		@returns Validator function
	*/
	this.unique_validator = function(fields, skip_empty_validation)
	{
		var validator = function(ctx)
		{
			var filter = session.create_criteria("and");
			var empty_fields = new Array();
			for (var enm = new Enumerator(fields); !enm.atEnd(); enm.moveNext())
			{
				var field = enm.item();
				var field_value = ctx.snapshot()[field];
				if (is_empty_value(field_value))
				{
					if (skip_empty_validation)
						return true;
					else
						empty_fields.push(field);
				}
				else
					filter.add(session.create_expression(field, "eq", field_value));
			}
			for (var enm = new Enumerator(session.find_items(ctx.item.type_id, filter)); !enm.atEnd(); enm.moveNext())
			{
				var item = enm.item();
				var empty_fields_is_empty = true;
				for (var empty_enm = new Enumerator(empty_fields); !empty_enm.atEnd(); empty_enm.moveNext())
					if (!is_empty_value(item[empty_enm.item()]))
					{
						empty_fields_is_empty = false;
						break;
					}
				if (empty_fields_is_empty && !helpers.ids_equal(session, item.id, ctx.id()))
					return false;
			}
			return true;
		}
		return validator;
	}

	/**
		Function of the validation object, that will return validator to validate that required field is not empty
		@param field Field name
		@returns Validator function
	*/
	this.empty_field_validator = function(field)
	{
		var validator = function(ctx)
		{
			return !is_empty_value(ctx.snapshot()[field]);
		}
		return validator;
	}
	
	this.field_length_validator = function(field, max_length)
	{
		var validator = function(ctx)
		{
			var fld_value = ctx.snapshot()[field];
			return fld_value == null || fld_value.length <= max_length;
		}
		return validator;
	}

	/**
		Function of the validation object that validates whether the set of specified fields is unique for the whole set of items of this type.
		@param fields Array of field names to be validated as unique. Validation will be passed if there is no such combination of field values on any other object
		@param ids Array of id's of the controls to be highlighted if unique validation fails
		@param message ID of error message text in package.res file. Error message will be shown if field's value length is more than max_length value
		@param skip_empty_validation Set to false if you do not want to ignore empty fields.
		@returns Validator function
	*/
	this.validate_unique_fields = function(fields, ids, message, skip_empty_validation, group)
	{
		add_validator(ids, message, this.unique_validator(fields, skip_empty_validation == true), group);
	}

	/**
		Function of the validation object that validates whether the field's value is empty. Mostly used for required fields.
		@param field Name of a field we are going to validate it's length
		@param id Id of a control, that display this field's value. This control would be highlighted if validation fails.
		@param message ID of error message text in package.res file. Error message will be shown if field's value length is more than max_length value
		@param group
	*/
	this.validate_empty_field = function(field, id, message, highlight_control, group) {
			if (id != null && highlight_control != false)
			(subform != null ? subform : form)[id].required = true;
		add_validator(id != null ? new Array(id) : null, message, this.empty_field_validator(field), group);
	}

	/**
		Function of the validation object that validates the length of the string field's value.
		@param field Name of a field we are going to validate it's length
		@param id Id of a control, that display this field's value. This control would be highlighted if validation fails.
		@param max_length Maximum length of the field's value allowed.
		@param message ID of error message text in package.res file. Error message will be shown if field's value length is more than max_length value
		@param group
	*/
	this.validate_field_length = function(field, id, max_length, message, group)
	{
		add_validator(id != null ? new Array(id) : null, message, this.field_length_validator(field, max_length), group);
	}
	
	/**
		Function of the validation object that alows used to add his own validation function.
		@param fn Name of the user's custom function. This function should return true if validation is passed successfully
		@param ids Array of ids of the controls to be highlighted if custom validation function retun false (means that validation failed)
		@param message ID of error message text in package.res file. Error message will be shown if custom validation function retun false (means that validation failed)
		@param group
	*/
	this.add_custom = function(fn, ids, message, group)
	{
		add_validator(ids, message, fn, group);
	}
	
	/**
		This function enables or disables validation.
		@param enbl Set to false if you want to disable validation
	*/
	this.set_enabled = function(enbl)
	{
		enabled = enbl;
	}
}

/** 
	@class Form links manager that manage most operations on form.
	During construction ctx will be extended with fields "item_ex", "links", "triggers", "security_descriptor", "validator", "events" and "created_from_ctx" if exists.
	@constructor
	@param {form_helpers.ctx} ctx General ctx.
	@memberOf form_helpers
*/
function form_links_manager(ctx)
{
	ctx.controls_initialized = ctx.child_type == "dialog" || ctx.child_type == "subform";
	ctx.form_links_manager = this;

	var application = ctx.application;
	var session = application.session;
	var form = ctx.form;
	var item = form.item;

	var links_obj = function()
	{
		data_model.links_model.call(this);

		this.base_get_link = this.get_link;
		this.get_link = function(criteria)
		{
			var result = this.base_get_link(criteria);
			if (result.reason == "absent")
				result = ctx.data_model.links.get_link(criteria);
			return result;
		}

		this.base_for_each = this.for_each;
		this.for_each = function(criteria, f)
		{
			function proxy4override(link)
			{
				var orig = ctx.data_model.links.get_link(link);
				if (orig.reason == "absent")
					f(link);
			}
			this.base_for_each(criteria, proxy4override)

			var _this = this;
			function proxy(link)
			{
				var override = _this.base_get_link(link);
				f(override.reason == "absent" ? link : override.link);
			}
			ctx.data_model.links.for_each(criteria, proxy);
		}
	}

	var triggers_obj = function()
	{
		data_model.triggers.call(this);

		this.base_call = this.call;
		this.call = function(ctx, action_ctx)
		{
			this.base_call(ctx, action_ctx);
			ctx.data_model.triggers.call(ctx, action_ctx);
		}
	}

	/**
	Indicates if this form_links_manager is disabled.
	@type bool
	*/
	this.disabled = false;

	function events_connection(form_links_manager)
	{
		helpers.events_connection.call(this);
		var connect = this.connect;

		this.connect = function()
		{
			if (arguments[2] != null)
				arguments[2] = disconnectable_handler(arguments[2], form_links_manager);
			connect.apply(this, arguments);
		}
	}
	ctx.events = new events_connection(this);

	helpers.merge_contexts({
		"custom_data": {},

		"validate_access": true,
		"revert_links": true,
		"ensure_saved_confirmation": true
	}, ctx);

	/**
	Local links.
	@type data_model.links_model
	*/
	this.links = ctx.links = new links_obj();

	/**
	Local triggers.
	@type data_model.triggers
	*/
	this.triggers = ctx.triggers = new triggers_obj();

	new data_model.objects_linker2(ctx);
	
	// Item Extension Section
	var custom_controllers = [];

	var item_ex = function()
	{
		this.fcd_item = item;
		this.item_ex_type = "form_links_manager";

		var snapshot = null;
		var id = false;
		var modified_fields = [];

		this.get_snapshot = function()
		{
			if (snapshot == null)
			{
				snapshot = item.type_id == "Mail" ? item : item.snapshot;
			}
			return snapshot;
		}

		this.reset = function()
		{
			snapshot = null;
			id = false;
			modified_fields = [];
		}

		this.get_id = function()
		{
			if (id == false)
				id = helpers.safe_get_id(item);
			return id;
		}

		this.get_type = function()
		{ return item.type_id; }

		this.save = function()
		{
			var result;
			if (ctx.child_type == "subform" && this.get_id() == null)
				result = ctx.parent_ctx.item_ex.save();
			else
				result = helpers.save_item(ctx.form);
			this.reset();
			return result;
		}

		this.get_property = function(name)
		{
			var handler_ctx = { "name": name };
			helpers.for_each(custom_controllers, function(cc) { if (cc.controller.get_value != null) cc.controller.get_value(ctx, handler_ctx); });
			if (handler_ctx.value_set)
				return handler_ctx.value;
			else if (modified_fields[name] != null)
				return modified_fields[name].value;
			else
				return this.get_snapshot()[name];
		}

		this.set_property = function(name, value)
		{
			item[name] = value;
			modified_fields[name] = { "value": value };
			var handler_ctx = { "name": name, "value": value };
			helpers.for_each(custom_controllers, function(cc) { if (cc.controller.set_value != null) cc.controller.set_value(ctx, handler_ctx); });
		}

		this.ensure_saved = function()
		{
			return (this.get_id() != null
				|| ((!ctx.ensure_saved_confirmation || ctx.ui.message_box(0, ctx.session.res_string("msg_item_not_saved"), ctx.session.res_string("msg_item_not_saved_caption"), 0x44) == 6) && this.save()));
		}

		this.set_form_dirty = function()
		{
			var ok = false;
			helpers.for_each(custom_controllers, function(cc, param, for_each_ctx)
			{
				if (cc.controller.set_form_dirty != null)
				{
					cc.controller.set_form_dirty();
					ok = true;
					for_each_ctx.interrupted = true;
				};
			});
			if (!ok)
			{
				var obj_descr = ctx.data_model.objects.get_object(this.get_type());
				if (obj_descr.set_form_dirty != null)
					obj_descr.set_form_dirty(ctx);
			}
			return ok;
		}
	}

	/**
	Represents item displayed on form.
	@type form_helpers.item_ex
	*/
	this.item_ex = new item_ex();
	ctx.item_ex = this.item_ex;

	var default_controller_options =
	{
		"type": ctx.item_ex.get_type()
	}

	/**
	Register and initialize controller.
	@param {form_helpers.controller} controller Controller that should be initialized and registered.
	@param options Options of controller initialization. This options will be extended with "type" options, "link" if possible and default_controller_options if exists.
	*/
	this.add_controller = function(controller, options)
	{
		var cc = {
			"options": options,
			"controller": controller
		}

		options = helpers.merge_contexts(controller.default_options, options);
		options = helpers.merge_contexts(default_controller_options, options);
		options = helpers.merge_contexts({ "link": ctx.links.get_link(options).link }, options);
		controller.init(ctx, options);
		update_access([cc]);
		custom_controllers.push(cc);
		return controller;
	}

	// Notifications section
	var default_notification_ctx_params =
	{
		"type": ctx.item_ex.get_type(),
		"item_ex": ctx.item_ex,
		"submited": false
	}

	/**
	Create function that simplifies sending of notification.
	@param {data_model.trigger_action_ctx} const_params Const params that should be extended with "type", "item_ex" and "submited" options.
	@return Function with signature f(action_ctx) that will extend action_ctx with const params and pass it to {@link data_model.trigger#handler}.
	@type Function
	*/
	this.create_notifier = function(const_params)
	{
		helpers.merge_contexts(default_notification_ctx_params, const_params);

		function f(action_ctx)
		{
			action_ctx = helpers.merge_contexts(const_params, action_ctx);
			ctx.triggers.call(ctx, action_ctx);
		}
		return f;
	}

	// Access section
	if (ctx.security_manager != null)
		ctx.security_descriptor = ctx.security_manager.create(ctx);

	var update_access = function(items)
	{
		if (items == null)
			items = custom_controllers;
		if (ctx.security_descriptor && ctx.security_descriptor.link_access != null)
			helpers.for_each(items, function(cc) { if (cc.controller.update_access != null) cc.controller.update_access(ctx, ctx.security_descriptor); });
	}

	/**
	Updates access for all controllers. This function is called automatically during initialization and after save, usually there is no need to call it manually.
	*/
	this.update_access = function()
	{
		update_access();
	}

	// Validation section
	{
		function validation_state_fn()
		{
			return ctx.validation_state_fn != null ? ctx.validation_state_fn() : null;
		}

		ctx.validator = ctx.child_type == "subform"
			? new form_validator(ctx.session, ctx.parent_ctx.form, validation_state_fn, ctx.form)
			: new form_validator(ctx.session, ctx.form, validation_state_fn);

		if (ctx.validate_access && ctx.security_descriptor != null)
			ctx.validator.add_custom(function() { return ctx.security_descriptor.modify_access(); }, [], "msg_cant_save_item");
	}

	// Initialization
	if (this.item_ex.get_id() == null)
	{ // Item is new
		if (ctx.created_from_ctx == null)
			ctx.created_from_ctx = ctx.cfp_manager.retrieve_item_descriptor(item);
	}
	else
	{
		if (ctx.revert_links)
			ctx.linker.revert({ "item_ex": this.item_ex });
	}

	var on_after_saved = new helpers.signal();

	/**
	Signal that is raised after form saved and all required post-save operations completed.
	@type helpers.signal
	*/
	this.on_after_saved = on_after_saved;

	var on_saved_handler = function()
	{
		ctx.item_ex.reset();
		ctx.linker.submit({ "item_ex": ctx.item_ex });
		on_after_saved.raise(ctx);
		if (ctx.security_descriptor && ctx.security_descriptor.reset != null)
			ctx.security_descriptor.reset();
		update_access();
	}
	ctx.form.on_saved.connect(on_saved_handler);
	
	/**
	Signal that is raised after click cancel close or escape for dialog
	@type helpers.signal
	*/
	if (ctx.child_type == "dialog")
		this.on_save_cancelled = new helpers.signal();

	/**
	Performs initialization of object in case it is new and sets ctx.controls_initialized to true. Call this function at the end of form initialization.
	*/
	this.init_new = function()
	{
		if (ctx.item_ex.get_id() == null)
		{
			var created_from_ctx = ctx.created_from_ctx;
			ctx.created_from_ctx = null;
			var prefill_result = data_model.prefill_item(ctx, { "item_ex": ctx.item_ex, "submited": false, "notification_params": created_from_ctx });
			on_after_saved.connect(helpers.call_once(function()
			{
				data_model.after_save_link(ctx, prefill_result.link_results, { "submited": true })
				if (created_from_ctx != null && created_from_ctx.on_after_saved != null)
					helpers.safe_call(function() { created_from_ctx.on_after_saved.raise(ctx); });
			}));
			if (ctx.child_type == "dialog" || ctx.child_type == "subform")
				ctx.form.item = ctx.item_ex.fcd_item;
		}
		ctx.controls_initialized = true;
	}

	/**
	Disables all controllers and event handlers on form. Required to avoid unexpected processing in objects that are ready for garbage collection but is alive still.
	*/
	this.disable = function()
	{
		this.disabled = true;
		ctx.validator.set_enabled(false);
		helpers.for_each(custom_controllers, function(cc)
		{
			cc.options.disabled = true;
			if (cc.controller.disable != null)
				cc.controller.disable();
		});
		util.disconnect_object(item);
	}

	/**
	Performs all required post-save operations include "on_after_saved" event raising. Required for dialog and subforms where no on_saved event raised.
	*/
	this.on_saved = function()
	{
		on_saved_handler();
	}
}

var shared = new function()
{
	this.apply_template_params = function(tpl, params)
	{
		if (params != null)
		{
			for (var key in params)
				tpl = helpers.replace_all("$" + key, params[key], tpl);
		}
		return tpl;
	}
} ();

/**
Creates functor that call function only if value of "options.disabled" not equal to true. This function is usuallu used to create control event handlers in 
@param {Function} f Internal function that have to called or not depending on value of "options.disabled". 
@param options Options that can contain "disabled" field. 
@return Return function that checks value "options.disabled" before call of internal funtion.
@type Function
*/
function disconnectable_handler(f, options)
{
	function handler()
	{
		if (options.disabled != true)
			f.apply(this, arguments);
	}
	return handler;
}

/**
	@class Controller that used to create new object including all auxiliary notification.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function create_new_controller()
{
	this.default_options =
	{
		"created_from_ctx_type": "std",
		"submited": false,
		"new_notification": false
	};

	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.create_new_controller_options} options
	*/
	this.init = function(c, opt)
	{
		ctx = c;
		options = opt;

		options.create_new_notifier = ctx.form_links_manager.create_notifier({
			"tag": options.link ? options.link.tag : null,
			"submited": options.submited
		});
	}

	/**
		Since create_new_controller doesn't handle any control's or other signal this method is used by other controllers to perform create operation.
		@param {data_model.trigger_action_ctx} action_ctx Partially filled action_ctx. Also it can contain partially filled notification_params. Can be null. All required absent data will be filled during processing of create operation.
		@param {bool} show Indicates if "show" notification required after object is created.
	*/
	this.create_new = function(action_ctx, show)
	{
		action_ctx = helpers.merge_contexts({
			"link_to": options.link_to
		}, action_ctx);

		action_ctx.notification_params = helpers.merge_contexts({
			"is_new": true,
			"created_from_ctx_type": options.created_from_ctx_type,
			"create_native": options.create_native
		}, action_ctx.notification_params);

		function notify(operation) { options.create_new_notifier(helpers.merge_contexts(action_ctx, { "operation": operation })); }

		var created_type = action_ctx.notification_params.create_native != null ? action_ctx.notification_params.create_native : action_ctx.link_to;
		if (options.new_notification)
			notify("new");
		else
			action_ctx.notification_params.item = ctx.session.create_item(created_type);

		function add_link_me_callback()
		{
			action_ctx.notification_params.on_after_saved = new helpers.signal();
			action_ctx.notification_params.on_after_saved.connect(function(foreign_ctx)
			{
				ctx.linker.link({ "item_ex": ctx.item_ex, "with_id": foreign_ctx.item_ex.get_id(), "tag": options.tag, "submited": false });
			});
		}

		switch (options.created_from_ctx_type)
		{
			case "std":
				notify("new_created");
				break;
			case "link_me":
				add_link_me_callback();
				break;
			case "link_me_and_notification":
				add_link_me_callback();
				notify("new_created");
				break;
		}
		if (show)
		{
			action_ctx.link_to = created_type;
			notify("show");
		}
	}
}

/**
	@private
*/
function std_view_ctrl_delete_filter(ctx, delete_descriptor)
{
	if (delete_descriptor.can_unlink_all == false || delete_descriptor.can_delete_all == false)
		ctx.ui.message_box(0, ctx.session.res_string(delete_descriptor.links.length > 1 ? "msg_can_delete_all_item" : "msg_cant_delete_item"), ctx.session.res_string("msg_cant_delete_item_caption"), 0x40);
}

/**
	@class Controller that create new object as reaction on button click.
	This controller uses {@link form_helpers.create_new_controller} to create new objects.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function button_create_new()
{
	var options;
	var ctx;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.button_create_new_options} options
	*/
	this.init = function(c, opt)
	{
		options = opt;
		ctx = c;

		options.create_new_controller = new create_new_controller();
		ctx.form_links_manager.add_controller(options.create_new_controller, options);

		options.btn.on_click.connect(disconnectable_handler(btn_clicked, options));
	}
	
	function btn_clicked()
	{
		if (ctx.item_ex.ensure_saved())
			options.create_new_controller.create_new(helpers.get_restricted_context(options, ["notification_params"]), options.show);
	}
}

/**
	@class View control events manger. Also supports related buttons for show, delete, new etc. operations.
	This controller uses {@link form_helpers.create_new_controller} to create new objects.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function view_ctrl()
{
	this.default_options =
	{
		"tag": "mvg",
		"submited": false,
		"new_notification": false,
		"dbl_click_action": "show",
		"delete_action": "remove",
		"delete_filter_fn": std_view_ctrl_delete_filter
	};

	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.view_ctrl_options} options
	*/
	this.init = function(c, opt)
	{
		ctx = c;
		options = opt;

		options.removed_associated_ids = [];

		options.view_ctrl_notifier = ctx.form_links_manager.create_notifier({
			"link_to": options.link.link_to,
			"tag": options.link.tag
		});

		options.create_new_controller = new create_new_controller();
		ctx.form_links_manager.add_controller(options.create_new_controller, options);

		var on_dbl_click_handler = ({
			"show": show,
			"show_association": show_association
		})[options.dbl_click_action];
		if (on_dbl_click_handler != null)
			options.view_ctrl.on_dbl_click.connect(disabled_check(on_dbl_click_handler));

		var on_delete_clicked_adapter = function(f)
		{
			var vk_delete = 46;
			return function(vk_code)
			{
				if (!options.custom_view_ctrl || vk_code == vk_delete)
					f.apply(undefined, arguments);
			};
		};
		var on_delete_clicked_handler = ({
			"remove": remove,
			"remove_association": remove_associations
		})[options.delete_action];
		if (on_delete_clicked_handler != null)
			options.view_ctrl[options.custom_view_ctrl ? "on_keyboard_action" : "on_delete_clicked"]
				.connect(disabled_check(on_delete_clicked_adapter(on_delete_clicked_handler)));

		if (options.delete_action != "remove_association")
			ctx.form_links_manager.triggers.add_simple_trigger(remove_submited, options.type, options.link_to, options.tag, "submit");

		connect_handler(options.btn_show, show);
		connect_handler(options.btn_show_association, show_association);
		connect_handler(options.btn_remove, remove);
		connect_handler(options.btn_remove_association, remove_associations);
		connect_handler(options.btn_new, create_new);
		connect_handler(options.btn_show_new, show_new);
	}

	this.update_access = function(ctx, security_descriptor)
	{
		function enable_button(button, enabled)
		{
			if (button != null)
				button.enabled = enabled;
		}
		options.access = security_descriptor.link_access(options);

		enable_button(options.btn_remove, options.access.remove);
		enable_button(options.btn_remove_association, options.access.remove);
		enable_button(options.btn_new, options.access.create);
		enable_button(options.btn_show_new, options.access.create);
	}

	var execute_remove = function(remove_associated)
	{
		if ((options.access == null || options.access.remove) && options.view_ctrl.selection_count)
		{
			var delete_descriptor = {
				"can_unlink_all": true,
				"can_unlink_at_least_one": false,
				"interrupted": false,
				"links": []
			};
			if (remove_associated)
			{
				delete_descriptor.can_delete_all = true;
				delete_descriptor.can_delete_at_least_one = false;
			}

			helpers.for_each(options.view_ctrl.selection, function(item)
			{
				var link = {
					"link_to": options.link.link_to,
					"submited": options.submited,
					"with_id": resolve_association(item)
				}
				link.do_unlink = link.can_unlink = ctx.security_descriptor == null || ctx.security_descriptor.link_operation_access({ "operation": "remove", "with_id": link.with_id, "tag": options.link.tag });
				delete_descriptor.can_unlink_all = delete_descriptor.can_unlink_all && link.can_unlink;
				delete_descriptor.can_unlink_at_least_one = delete_descriptor.can_unlink_at_least_one || link.can_unlink;
				if (remove_associated)
				{
					function delete_access()
					{
						if (ctx.security_manager != null)
						{
							var item = ctx.session.open_item(link.with_id);
							if (item != null)
								return ctx.security_manager.create(ctx, new data_model.std_item_ex(item)).delete_access();
						}
						return true;
					}
					link.do_unlink = link.do_delete = link.can_delete = link.can_unlink && delete_access();
					delete_descriptor.can_delete_all = delete_descriptor.can_delete_all && link.can_delete;
					delete_descriptor.can_delete_at_least_one = delete_descriptor.can_delete_at_least_one || link.can_delete;
				}
				delete_descriptor.links.push(link);
			});
			if (options.delete_filter_fn != null)
				options.delete_filter_fn(ctx, delete_descriptor);

			if (!delete_descriptor.interrupted)
			{
				var notification_params = { "links": [] };
				var do_delete_items = [];
				helpers.for_each2(delete_descriptor.links, function(link)
				{
					if (link.do_unlink)
						notification_params.links.push(link);
					if (link.do_delete)
						do_delete_items.push(link.with_id);
				});

				options.view_ctrl_notifier({ "operation": "unlink", "notification_params": notification_params });
				if (remove_associated)
				{
					helpers.for_each(notification_params.link_results, function(link_result)
					{
						if (link_result.result.success && helpers.contains_object_id(ctx.session, do_delete_items, link_result.spec_ctx.with_id))
							options.removed_associated_ids.push(link_result.spec_ctx.with_id);
					});
					if (options.submited)
						remove_submited();
				}
			}
		}
	}

	var remove_submited = function()
	{
		function f(item_id)
		{
			var item = ctx.session.open_item(item_id);
			if (item != null)
				item.remove();
		}
		helpers.for_each(options.removed_associated_ids, f);
		options.removed_associated_ids = [];
	}

	var notify_show = function(operation, item)
	{
		if (item != null)
		{
			var notification_params = { "item": item };
			options.view_ctrl_notifier({ "operation": operation, "notification_params": notification_params });
		}
	}

	var disabled_check = function(f)
	{
		return function() { if (!options.disabled) f.apply(undefined, arguments); };
	}

	var connect_handler = function(button, handler)
	{
		if (button != null)
			button.on_click.connect(disabled_check(handler));
	}
	
	var resolve_association = function(item)
	{ return options.link.resolve_association(ctx, item); }

	var remove_associations = function()
	{ execute_remove(false); }

	var remove = function()
	{ execute_remove(true); }

	var show_association = function()
	{
		notify_show("show_association", options.view_ctrl.selected);
	}

	var show = function()
	{
		var item = options.view_ctrl.selected;
		if (item != null)
		{
			var linked_item = item;
			var linked_id = resolve_association(item);
			if (!helpers.ids_equal(ctx.session, linked_id, linked_item.id))
			{
				linked_item = ctx.session.open_item(linked_id);
				util.disconnect_object(item);
			}
			if (linked_item != null)
				notify_show("show", linked_item);
			else if (options.missing_object_message)
				ctx.ui.message_box(0, ctx.session.res_string("msg_no_object_found"), ctx.session.res_string("msg_mvg_warning"), 0x30);
		}
	}

	var create_new = function()
	{
		if (ctx.item_ex.ensure_saved())
			options.create_new_controller.create_new(null, false);
	}

	var show_new = function()
	{
		if (ctx.item_ex.ensure_saved())
			options.create_new_controller.create_new(null, true);
	}
}

/**
	@class Items selector represented by Sales Book dialog.
	Displaying of SalesBook dialog and sending of notification to link with selected items is the main task of this controller. Creation of new item is an auxiliary task performed by {@link form_helpers.create_new_controller}.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function sales_book_selector()
{
	this.default_options =
	{
		"created_from_ctx_type": "std",
		"new_notification": false,
		"submited": false
	};
	
	var ctx;
	var options;

	var create_new = function(type, keywords)
	{
		options.dialog.visible = false;
		options.create_new_controller.create_new({ "link_to": type }, true);
	}
	
	var on_closed = function(ok, selection)
	{
		if (ok)
			options.link_notifier({ "notification_params": { "with_ids": helpers.find_result2ids_array(selection)} });
	}

	var show = function()
	{
		if (options.disabled != true && (options.link.id_required != true || ctx.item_ex.ensure_saved()))
		{
			if (options.dialog == null)
			{
				options.dialog = ctx.application.lookup.create_builtin_dialog(util.jsarray_to_vbarray(options.link.sales_book_ids), 0);
				options.dialog.on_closed.connect(on_closed);
				options.dialog.on_new_object.connect(create_new);
			}
			options.dialog.visible = true;
		}
	}

	this.show = show;

	this.close = function()
	{
		if (options.dialog != null)
			options.dialog.visible = false;
	}

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.sales_book_selector_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		if (options["btn_show"] != null)
			options["btn_show"].on_click.connect(show);

		options.link_notifier = ctx.form_links_manager.create_notifier({
			"operation": "link",
			"submited": options.submited,
			"tag": options.link.tag
		});

		options.create_new_controller = new create_new_controller();
		ctx.form_links_manager.add_controller(options.create_new_controller, options);
	}

	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options["btn_show"].enabled = access.create;
		if (!access.create && options.dialog != null && options.dialog.visible == true)
			options.dialog.visible = false;
	}

	this.disable = function()
	{
		if (options.dialog != null && options.dialog.visible == true)
			options.dialog.visible = false;
	}
}

/**
	@class Controller that show item selected in autocomplete by sending of "show" notification.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function autocomplete_opener()
{
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.autocomplete_opener_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		options.show_notifier = ctx.form_links_manager.create_notifier({ "operation": "show" });

		options["autocomplete"].on_display_selection.connect(on_display);
	}

	var on_display = function()
	{
		if (!options.disabled)
		{
			var item = ctx.session.open_item(options["autocomplete"].selected);
			if (item != null)
				options.show_notifier({ "link_to": item.type_id, "notification_params": { "item": item } });
		}
	}
}

/**
	@class Controller that sends "link" notification for object selected in autocomplete on button click event.
	Additional tasks:<br>
	- show selected in autocomplete item by using of {@link form_helpers.autocomplete_opener};<br>
	- show other selector if button clicked and autocomplete is empty;
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function autocomplete_selector()
{
	this.default_options = {
		"submited": false
	}

	var ctx;
	var options;

	var on_add = function()
	{
		if (options.disabled != true)
		{
			var selected_id = options["autocomplete"].selected;
			if (selected_id != null)
			{
				if (options.link.id_required != true || ctx.item_ex.ensure_saved())
				{
					var notification_params = { "with_ids": [selected_id] };
					options.link_notifier({ "notification_params": notification_params });
					if (notification_params.link_results != null && notification_params.link_results[0].result.success == true)
						options["autocomplete"].selected = null;
				}
			}
			else if (options.related_selector != null)
				options.related_selector.show();
		}
	}

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.autocomplete_selector_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		options["btn_add"].on_click.connect(on_add);

		options.link_notifier = ctx.form_links_manager.create_notifier({
			"operation": "link",
			"submited": options.submited,
			"tag": options.link.tag
		});

		ctx.form_links_manager.add_controller(new autocomplete_opener(), options);
	}

	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options["autocomplete"].enabled = access.create;
		options["btn_add"].enabled = access.create;
	}
}

/**
	@class Controller that sends "link" notification and uses dropdown control to display and select items.
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function dropdown_selector()
{
	var ctx;
	var options;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.dropdown_selector_options} options
	*/
	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		options.dropdown.on_expand.connect(on_expand);
		options.dropdown.on_item_click.connect(on_item_click);

		var notifier_ctx = helpers.get_restricted_context(options, ["tag", "params"]);
		helpers.merge_contexts({ "operation": "link" }, notifier_ctx);
		options.link_notifier = ctx.form_links_manager.create_notifier(notifier_ctx);
	}

	var items = {
		"add": function(caption, data, image)
		{
			var dropdown_item = options.dropdown.add_item(caption, { "notification_params": data });
			if (image)
				dropdown_item.set_image(image)
		},
		"add_separator": function()
		{
			options.dropdown.add_separator();
		}
	}

	var on_expand = function()
	{
		if (!options.disabled && (!options.ensure_saved_on_expand || ctx.item_ex.ensure_saved()))
		{
			if (options.refresh_on_expand)
				options.dropdown.clear();
			options.fill(ctx, items);
		}
	}

	var on_item_click = function(id, data)
	{
		if (!options.disabled)
		{
			var np_copy = helpers.merge_contexts(data.notification_params);
			if (data.notification_params != null)
			{
				options.link_notifier({ "notification_params": np_copy });
				if (data_model.is_id_expected_error(np_copy.link_results) && ctx.item_ex.ensure_saved())
				{
					var f = function() { data_model.after_save_link(ctx, np_copy.link_results); };
					if (options.use_on_afrer_saved)
						ctx.form_links_manager.on_after_saved.connect(helpers.call_once(f));
					else
						f();
				}
			}
		}
	}
}

/**
@private
*/
function mvg_single_link_controller()
{
	var ctx;
	var options;

	this.init = function(c, o)
	{
		ctx = c;
		options = o;

		var item = ctx.session.create_item(options.link.association_type);
		var linked = options.link.linked(ctx, { "item_ex": ctx.item_ex });
		if (linked.count > 0)
		{
			var existent = ctx.session.open_item(linked.association_id);
			helpers.for_each(options["additional_fields"], function(field) { item[field] = existent[field]; });
		}
		options["subform"].item = item;
		helpers.for_each(options["additional_subforms"], function(subform) { subform.item = item; });
		options["autocomplete"].selected = linked.value;

		options.created_notifier = ctx.form_links_manager.create_notifier({
			"link_to": options.link_to,
			"tag": options.tag,
			"operation": "created",
			"submited": false
		});
		options["autocomplete"].changed.connect(changed);
		
		ctx.form_links_manager.add_controller(new autocomplete_opener(), options);

		helpers.merge_contexts(options.link, this);
		this.id_required = false;

		ctx.links.add_link(this);
	}

	this.create = function(ctx, spec_ctx)
	{
		if (spec_ctx.submited)
			return options.link.create(ctx, spec_ctx);

		var prev_id = options["autocomplete"].selected;
		if (!helpers.ids_equal(ctx.session, prev_id, spec_ctx.with_id))
		{
			options["autocomplete"].selected = spec_ctx.with_id;
			try
			{
				options.skip_notifications = true;
				options["autocomplete"].raise_changed();
			}
			finally
		{ options.skip_notifications = false; }
			return ({
				"success": true,
				"new_value": spec_ctx.with_id,
				"prev_value": prev_id
			});
		}
		else
			return ({ "success": false, "reason": "already exists" });
	}

	this.linked = function(ctx, spec_ctx)
	{
		if (spec_ctx.submited)
			return options.link.linked(ctx, spec_ctx);

		var result =
		{
			"value": null,
			"values": []
		};
		var id = options["autocomplete"].selected;
		if (id != null)
		{
			result.value = id;
			result.values.push(result.value);
		}
		result.count = result.values.length;
		return result;
	}

	this.submit = function(ctx, spec_ctx)
	{
		var link_result = options.link.create(ctx, { "item_ex": ctx.item_ex, "with_id": options["autocomplete"].selected, "submited": true });
		if (link_result.new_value != null)
		{
			var existent = ctx.session.open_item(link_result.association_id);
			var snapshot = options["subform"].item.snapshot;
			helpers.for_each(options["additional_fields"], function(field) { existent[field] = snapshot[field] });
			if (existent != null)
				ctx.save(existent);
		}
	}

	var changed = function()
	{
		if (options.skip_notifications != true && options.disabled != true)
		{
			var with_id = options["autocomplete"].selected;
			if (check_type(with_id))
				options.created_notifier({ "with_id": with_id });
		}
	}

	var check_type = function(with_id)
	{
		return with_id == null || ctx.session.open_item(with_id).type_id == options.link_to;
	}
}

//////////////////////////////////////////////////////////////////////////
// General triggers
/**
@private
*/
function native_show_related_pim(ctx, action_ctx)
{
	var item = action_ctx.notification_params.item;
	action_ctx.notification_params.item = null;
	if (action_ctx.notification_params.is_new)
		ctx.cfp_manager.add_descriptor(item, action_ctx.notification_params);
	
	item.PIMObjectId != null ? ctx.session.display_item(ctx.session.open_item(item.PIMObjectId)) : ctx.session.display_item(item);
}

/**
Trigger function that show item in native outlook form
@param {platform_scripts.ctx} ctx General ctx that can be used for internal purposes.
@param {data_model.trigger_action_ctx} action_ctx Action context with "notification_params" of type {@link data_model.show_notification_params}.
@memberOf form_helpers#
*/
function native_show(ctx, action_ctx)
{
	var item = action_ctx.notification_params.item;
	action_ctx.notification_params.item = null;
	if (action_ctx.notification_params.is_new)
		ctx.cfp_manager.add_descriptor(item, action_ctx.notification_params);
	ctx.session.display_item(item);
}

/**
Creates trigger function that show item in dialog
@param {String} dialog_id Id of dialog in "dialogs.xml" file which should be used to show items.
@param {form_helpers.create_dialog_show_options} options Options.
@memberOf form_helpers#
@return Trigger function with signature f({@link platform_scripts.ctx}, {@link data_model.trigger_action_ctx}) and expects "notification_params" of type {@link data_model.show_notification_params}.
@type
*/
function create_dialog_show(dialog_id, options)
{
	options = helpers.merge_contexts({
		"form_handler": std_form_handler
	}, options);
	
	function std_form_handler(ctx)
	{
		ctx.form_links_manager.init_new();
	}

	function dialog_wrapper(ctx)
	{
		var dialog;
		var events = new helpers.events_connection();
		
		if(options.dialog_template_params != null)
		{
			options.dialog_xml_template = ctx.ui.get_dialog_xml(dialog_id);
			options.dialog_xml = shared.apply_template_params(options.dialog_xml_template, options.dialog_template_params);
			dialog = ctx.ui.create_dialog_from_xml(0, options.dialog_xml);
		}
		else
		{
			dialog = ctx.ui.create_dialog(0, dialog_id);
		}
		
		var dialog_ctx;

		function save_dialog()
		{
			if (helpers.save_item(dialog))
			{
				dialog_ctx.form_links_manager.on_saved();
				return true;
			}
			return false;
		}
		
		function clear_dialog()
		{
			dialog.item = null;
			dialog_ctx.form_links_manager.disable();
			dialog_ctx.form_links_manager = null;
		}

		function raise_save_cancelled()
		{
			dialog_ctx.form_links_manager.on_save_cancelled.raise();
		}
		
		function close_dialog()
		{
			dialog.visible = false;
			clear_dialog();
		}

		function save_and_close_dialog()
		{
			if (save_dialog())
				close_dialog();
		}
		
		function connect(btn, handler)
		{
			if (btn != null)
				events.connect(btn, "on_click", handler);
		}

		connect(dialog.btn_ok, save_and_close_dialog);
		connect(dialog.btn_cancel, function() { raise_save_cancelled(); close_dialog(); });
		dialog.on_closed.connect(function() { raise_save_cancelled(); clear_dialog(); });

		this.show = function(ctx, action_ctx)
		{
			notification_params = action_ctx.notification_params;
			if (!notification_params.dialog_create_only)
			{
				if (dialog_ctx != null && dialog_ctx.form_links_manager != null)
					dialog_ctx.form_links_manager.disable();
				dialog_ctx = {
					"form": dialog,
					"created_from_ctx": notification_params,
					"show_action_ctx": action_ctx,
					"child_type": "dialog",
					"parent_ctx": ctx,
					"save_dialog": save_dialog,
					"close_dialog": close_dialog,
					"save_and_close_dialog": save_and_close_dialog
				}
				dialog.item = notification_params.item;
				util.disconnect_object(notification_params.item);
				helpers.merge_contexts(ctx, dialog_ctx);
				new form_links_manager(dialog_ctx);
				new options.form_handler(dialog_ctx);
				dialog.visible = true;
			}
		}
	}

	function get_dialog(ctx, index)
	{
		if (ctx.custom_data.dialogs == null)
			ctx.custom_data.dialogs = [];
		var dialog = ctx.custom_data.dialogs[index];
		if (dialog == null)
		{
			dialog = new dialog_wrapper(ctx);
			ctx.custom_data.dialogs[index] = dialog;
		}
		return dialog;
	}

	function dialog_show(ctx, action_ctx)
	{
		var index_params = helpers.get_restricted_context(action_ctx, ["type", "link_to", "tag", "operation"]);
		index_params["dialog_id"] = dialog_id;

		get_dialog(ctx, helpers.format("{dialog_id}/{link_to}", index_params)).show(ctx, action_ctx);
	}
	
	return dialog_show;
}

// Std control wrappers
/**
	@class Implementation of {@link form_helpers.control_wrapper} for primary selector control. 
	@constructor
	@memberOf form_helpers
	@extends form_helpers.control_wrapper
*/
function primary_selector_wrapper()
{
	this.default_options =
	{
		"mvg_tag": "mvg"
	};

	var on_changed;
	var options;
	var fake_selected = undefined;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.primary_selector_wrapper_options} options
	*/
	this.init = function(ctx, opt)
	{
		options = opt;

		var mvg_options = helpers.merge_contexts(options, { "tag": options.mvg_tag });
		var mvg_link = ctx.data_model.links.get_link(mvg_options).link;
		var filter = mvg_link.filtering_support.get_filter(ctx, null, null,
			mvg_link.filtering_support.deleted_status, true,
			mvg_link.filtering_support.unsaved_status, true);
		if (options.ps_filter_fn != null)
			filter = options.ps_filter_fn(ctx, filter);
		options.ctrl.filter = filter;

		on_changed = new helpers.signal();
		this.on_changed = on_changed;
		options.ctrl.changed.connect(raise_changed);
	}

	this.select = function(value)
	{
		helpers.safe_call(function()
		{
			fake_selected = value;
			options.ctrl.value = value;
			options.ctrl.raise_changed();
		});
	}

	this.get_selected = function()
	{
		return fake_selected !== undefined ? fake_selected : options.ctrl.value;
	}

	this.set_control_enabled = function(value)
	{
		options.ctrl.enabled = value;
	}

	var raise_changed = function()
	{
		fake_selected = undefined;
		if (options.disabled != true)
			on_changed.raise();
	}
}

/**
	@class Implementation of {@link form_helpers.control_wrapper} for primary link represented by combobox. 
	@constructor
	@memberOf form_helpers
	@extends form_helpers.control_wrapper
*/
function primary_combobox_wrapper()
{
	this.default_options =
	{
		"mvg_tag": "mvg"
	};

	var on_changed;
	var ctx;
	var options;
	var mvg_link;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.primary_combobox_wrapper_options} options
	*/
	this.init = function(c, opt)
	{
		ctx = c;
		options = opt;

		var mvg_options = helpers.merge_contexts(options, { "tag": options.mvg_tag });
		mvg_link = ctx.data_model.links.get_link(mvg_options).link;

		refresh_filter();

		on_changed = new helpers.signal();
		this.on_changed = on_changed;
		options.ctrl.changed.connect(raise_changed);

		ctx.triggers.add_simple_trigger(refresh_filter, mvg_link.type, mvg_link.link_to, mvg_link.tag, "created");
		ctx.triggers.add_simple_trigger(refresh_filter, mvg_link.type, mvg_link.link_to, mvg_link.tag, "removed");
		ctx.triggers.add_simple_trigger(refresh_filter, mvg_link.type, mvg_link.link_to, mvg_link.tag, "refresh_cb_filter");
	}

	this.select = function(value)
	{
		refresh_filter();
		if (value != null)
			options.ctrl.value = value;
		options.ctrl.raise_changed();
	}

	this.get_selected = function()
	{
		return options.ctrl.value;
	}

	this.set_control_enabled = function(value)
	{
		options.ctrl.enabled = value;
	}

	var raise_changed = function()
	{
		if (options.disabled != true)
			on_changed.raise();
	}

	var refresh_filter = function()
	{
		var filter = mvg_link.filtering_support.get_filter(ctx, null, null,
			mvg_link.filtering_support.deleted_status, true,
			mvg_link.filtering_support.unsaved_status, true);
		if (options.cb_filter_fn != null)
			filter = options.cb_filter_fn(ctx, filter);
		options.ctrl.items.filter = filter;
	}
}

/**
	@class Implementation of {@link form_helpers.control_wrapper} for direct link represented by autocomplete. 
	@constructor
	@memberOf form_helpers
	@extends form_helpers.control_wrapper
*/
function autocomplete_wrapper()
{
	var options;
	var on_changed;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.autocomplete_wrapper_options} options
	*/
	this.init = function(ctx, opt)
	{
		options = opt;

		helpers.merge_contexts({ "autocomplete": options.ctrl }, options);

		on_changed = new helpers.signal();
		this.on_changed = on_changed;
		options.ctrl.changed.connect(raise_changed);

		ctx.form_links_manager.add_controller(new autocomplete_opener(), options);
	}

	this.select = function(value)
	{
		options.ctrl.selected = value;
		options.ctrl.raise_changed();
	}

	this.get_selected = function()
	{
		return options.ctrl.selected;
	}

	this.set_control_enabled = function(value)
	{
		options.ctrl.enabled = value;
	}

	var raise_changed = function()
	{
		if (options.disabled != true)
			on_changed.raise();
	}
}

/**
	@class The controller manages the behavior of direct link on form.
	If item displayed on form it is required to update control as well as field of object. 
	@constructor
	@memberOf form_helpers
	@extends form_helpers.controller
*/
function direct_link_controller()
{
	var options;
	var ctx;

	/**
		@param {form_helpers.ctx} ctx General ctx.
		@param {form_helpers.direct_link_controller_options} options
	*/
	this.init = function(c, opt)
	{
		ctx = c;
		options = opt;

		helpers.merge_contexts({ "tag": "direct" }, options);
		options.created_notifier = ctx.form_links_manager.create_notifier({
			"link_to": options.link_to,
			"tag": options.tag,
			"operation": "created"
		});
		options.ctrl_ex.on_changed.connect(changed);

		if (options.prev_value_in_notification)
		{
			options.prev_value = translate_value(ctx.linker.linked({
				"item_ex": ctx.item_ex,
				"link_to": options.link_to,
				"tag": options.tag,
				"operation": "created"
			}).value);
		}
		else
			options.prev_value = null;
	}

	this.set_value = function(ctx, set_ctx)
	{
		if ((ctx.controls_initialized || options.ctrl_ex.scriptable) && set_ctx.name == options.link.field && supported_value(set_ctx.value))
			set_value(set_ctx.value);
	}

	this.get_value = function(ctx, get_ctx)
	{
		if ((ctx.controls_initialized || options.ctrl_ex.scriptable) && get_ctx.name == options.link.field)
		{
			get_ctx.value = get_value();
			get_ctx.value_set = true;
		}
	}

	this.update_access = function(ctx, security_descriptor)
	{
		var access = security_descriptor.link_access(options);
		options.ctrl_ex.set_control_enabled(access.create && access.remove);
	}

	this.set_form_dirty = function()
	{
		set_value(get_value());
	}

	var changed = function()
	{
		if (options.skip_notifications != true)
		{
			var value = translate_value(options.ctrl_ex.get_selected());
			var action_ctx =
			{
				"with_id": value,
				"result": {
					"success": true,
					"prev_value": options.prev_value_in_notification ? options.prev_value : null,
					"new_value": value
				}
			}
			options.prev_value = value;
			options.created_notifier(action_ctx);
		}
	}

	var set_value = function(value)
	{
		try
		{
			options.skip_notifications = true;
			options.ctrl_ex.select(value);
			options.prev_value = value;
		}
		finally
			{ options.skip_notifications = false; }
	}

	var get_value = function()
	{
		return options.ctrl_ex.get_selected();
	}

	var supported_value = function(value)
	{
		if (value != null && options.polymorph)
		{
			var obj = ctx.session.open_item(value);
			if (obj != null && obj.type_id != options.link_to)
				return false;
		}
		return true;
	}

	var translate_value = function(value)
	{
		return supported_value(value) ? value : null;
	}
}

function create_attachment_trigger(options)
{
	var first_run = true;
	options = helpers.merge_contexts({}, options);
	
	function create_new(ctx, action_ctx)
	{
		if (first_run)
		{
			var object_descriptor = ctx.data_model.objects.get_object(action_ctx.link_to);
			if (object_descriptor != null)
				helpers.merge_contexts(object_descriptor.attachment_options, options);
			first_run = false;
		}

		var path = ctx.ui.pickup_file();
		if (!path)
			return;

		// Check for size limit
		if (options.max_size != null)
		{
			var fs_object = new ActiveXObject("Scripting.FileSystemObject");
			if (fs_object.GetFile(path).size > options.max_size * 1024 * 1024)
			{
				var str = ctx.session.res_string("msg_file_is_large");
				str = str.replace("{size-in-mb}", options.max_size);
				ctx.ui.message_box(0, str, ctx.session.res_string("msg_attach_file"), 0x30);
				return;
			}
		}

		// Check for duplicates
		var find = function(fname)
		{
			var linked_options = helpers.get_restricted_context(action_ctx, ["item_ex", "link_to", "submited"]);
			linked_options.params = { "additional_filter": ctx.session.create_expression(options.filename, "eq", fname) };
			return ctx.linker.linked(linked_options);
		};

		var exists = function(fname)
		{
			return find(fname).count > 0;
		};

		var reg_name = /^(?:.*[\\\/])?(.+)$/;
		var reg_simple_name = /^(.+)(\.[^\.]+?)$/;

		var name = path.replace(reg_name, '$1');
		var do_attach = !exists(name);
		if (!do_attach)
		{
			switch (options.duplicate)
			{
				case "deny":
					ctx.ui.message_box(0, ctx.session.res_string("msg_cant_attach_file"), ctx.session.res_string("msg_cant_attach_file_caption"), 0x30);
					break;

				case "numerate":
					var matches = name.match(reg_simple_name);
					var simple_name = matches ? matches[1] : name;
					var ext = matches ? matches[2] : '';
					var _name = simple_name + ext;
					for (var i = 2; exists(_name); ++i)
					{
						_name = simple_name + ' (' + i + ')' + ext;
					}
					name = _name;
					do_attach = true;
					break;

				case "replace":
					var replace_items = find(name);
					if (6 == ctx.ui.message_box(0, ctx.session.res_string("msg_attach_same_file"), ctx.session.res_string("msg_attach_same_file_caption"), 0x24))
					{
						var unlink_options = helpers.get_restricted_context(action_ctx, ["item_ex", "link_to", "submited"]);
						helpers.for_each(replace_items.values, function(with_id) { ctx.linker.unlink(helpers.merge_contexts(unlink_options, { "with_id": with_id })); });
						do_attach = true;
					}
					break;

				case "allow":
				default:
					do_attach = true;
					break;
			}
		}
		// Create attachment
		if (do_attach)
		{
			try
			{
				var doc = ctx.session.create_document(path, action_ctx.link_to, options.filename, options.body);
				doc[options.filename] = name;
				doc.save();
				ctx.linker.link(helpers.merge_contexts(action_ctx, { "with_id": doc.id }));
			}
			catch (e)
			{
				find_error_template(ctx);
				ctx.ui.message_box(0, helpers.format(options.error_message_template, { "message": e.message }), ctx.session.res_string("msg_error"), 0x30);
			}
		}
	}
	
	function find_error_template(ctx)
	{
		if (options.error_message_template == null)
		{
			try
			{
				options.error_message_template = ctx.session.res_string("msg_attach_file_error");
			}
			catch (e)
			{
				options.error_message_template = "{message}";
			}
		}
	}

	return create_new;
}

function set_form_dirty_trigger(ctx, action_ctx)
{
	if (!action_ctx.submited && action_ctx.result.success && action_ctx.item_ex.set_form_dirty != null)
		action_ctx.item_ex.set_form_dirty();
}

function create_mvg_link_result_analizer(options)
{
	function trigger(ctx, action_ctx)
	{
		var descr = {
			"link_to": null,
			"already_exists": 0,
			"primary_delete_denied": false
		}

		function get_resource(res_index)
		{
			var res_name = options.resources_map[descr.link_to][res_index];
			return ctx.session.res_string(res_name);
		}

		function analize_result(link_result)
		{
			
			switch (link_result.result.reason)
			{
				case "primary_delete_denied":
					descr.link_to = link_result.spec_ctx.link_to;
					descr.primary_delete_denied = true;
					break;
				case "already_exists":
					descr.link_to = link_result.spec_ctx.link_to;
					descr.already_exists++;
					break;
			}
		}
	
		helpers.for_each(action_ctx.notification_params.link_results, analize_result);
		if (descr.already_exists > 0)
			ctx.ui.message_box(0, get_resource("already_exists"), get_resource("already_exists_caption"), 0x30);
		if (descr.primary_delete_denied > 0)
			ctx.ui.message_box(0, get_resource("primary_delete_denied"), ctx.session.res_string("msg_mvg_warning"), 0x30);
	}
	return trigger;
}


function open_remote_item_from_form_control(remote_control, field_control, field) {
	var events = new helpers.events_connection();
	events.connect(remote_control, "on_click", on_btn_control_remote_click);
	events.connect(field_control, "changed", on_field_control_changed);
	remote_control.enabled = (field != null) || (field_control.selected != null);
	
	function on_btn_control_remote_click() {
		var shell = new ActiveXObject("WScript.Shell");
		var id = ctx.application.synchronizer.id_to_remote(field_control.selected);
		shell.Run(ctx.application.connector.get_object_page(id));
	}

	function on_field_control_changed() {
		remote_control.enabled = field_control.selected != null;
	}
}