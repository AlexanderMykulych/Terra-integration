include("form_helpers.js", "form_helpers");
include("raw_item_functions.js", "raw");
include("data_model.js", "data_model");
include("idle.js", "idle");
include("helpers.js", "helpers");

function create_meta_scheme() {
	var scheme = new data_model.data_model();
	scheme.dasl_field_product_prefix = "wb%20";

	function add_mvg_link(left_type, right_type, left_obj_primary, right_obj_primary,
	                      assoc_type, left_link, right_link,
	                      left_assoc_status, right_assoc_status,
	                      left_objs_view_ids, right_objs_view_ids,
	                      left_primary_refresh_required, right_primary_refresh_required,
	                      assoc_left_link_refresh_required, assoc_right_link_refresh_required) {
		var result = {};
		result.mvg1 = new data_model.mvg_link(left_type, right_type, assoc_type, left_link, right_link, right_assoc_status, left_assoc_status);
		result.mvg2 = new data_model.mvg_link(right_type, left_type, assoc_type, right_link, left_link, left_assoc_status, right_assoc_status);
		scheme.links.add_link(result.mvg1);
		scheme.links.add_link(result.mvg2);

		scheme.objects.get_object(assoc_type).get_field(left_link).set_link(left_type, assoc_left_link_refresh_required);
		scheme.objects.get_object(assoc_type).get_field(right_link).set_link(right_type, assoc_right_link_refresh_required);

		result.mvg1.sales_book_ids = right_objs_view_ids;
		result.mvg2.sales_book_ids = left_objs_view_ids;

		if (left_obj_primary != null) {
			result.primary1 = new data_model.direct_link(left_type, right_type, left_obj_primary);
			scheme.links.add_link(result.primary1);
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, left_type, right_type, result.mvg1.tag, "created");
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, left_type, right_type, result.mvg1.tag, "removed");

			scheme.objects.get_object(left_type).get_field(left_obj_primary).set_link(right_type, left_primary_refresh_required);

			scheme.triggers.add_simple_trigger(idle.update_primary_on_submit_trigger, right_type, left_type, result.mvg2.tag, "submit");
			scheme.triggers.add_simple_trigger(idle.update_primary_on_created_removed_trigger, right_type, left_type, result.mvg2.tag, "created");
			scheme.triggers.add_simple_trigger(idle.update_primary_on_created_removed_trigger, right_type, left_type, result.mvg2.tag, "removed");
		}

		if (right_obj_primary != null) {
			result.primary2 = new data_model.direct_link(right_type, left_type, right_obj_primary);
			scheme.links.add_link(result.primary2);
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, right_type, left_type, result.mvg2.tag, "created");
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, right_type, left_type, result.mvg2.tag, "removed");

			scheme.objects.get_object(right_type).get_field(right_obj_primary).set_link(left_type, right_primary_refresh_required);

			scheme.triggers.add_simple_trigger(idle.update_primary_on_submit_trigger, left_type, right_type, result.mvg1.tag, "submit");
			scheme.triggers.add_simple_trigger(idle.update_primary_on_created_removed_trigger, left_type, right_type, result.mvg1.tag, "created");
			scheme.triggers.add_simple_trigger(idle.update_primary_on_created_removed_trigger, left_type, right_type, result.mvg1.tag, "removed");
		}
		return result;
	}

	function add_direct_link(from_type, to_type, link_field, required_link, view_ids, refresh_required, status, primary_on_parent) {
		var result = {};
		result.direct = new data_model.direct_link(from_type, to_type, link_field);
		result.direct.sales_book_ids = view_ids;
		scheme.links.add_link(result.direct);
		scheme.objects.get_object(from_type).get_field(link_field).set_link(to_type, refresh_required);

		if (status != null) {
			result.mvg = new data_model.mirrored_direct_link(to_type, from_type, link_field, status, required_link);
			scheme.links.add_link(result.mvg);
		}
		if (primary_on_parent != null) {
			result.primary1 = new data_model.direct_link(to_type, from_type, primary_on_parent);
			scheme.links.add_link(result.primary1);
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, to_type, from_type, "mvg", "created");
			scheme.triggers.add_simple_trigger(data_model.update_primary_trigger, to_type, from_type, "mvg", "removed");
		}
		return result;
	}

	scheme.triggers.add_simple_trigger(data_model.perform_operation_from_notification_trigger, null, null, null, "link");
	scheme.triggers.add_simple_trigger(data_model.perform_operation_from_notification_trigger, null, null, null, "unlink");

	function on_new_created(ctx, action_ctx) {
		var np = action_ctx.notification_params;
		np["initial_links"] = helpers.push_ex(np["initial_links"], { "with_id": action_ctx.item_ex.get_id(), "tag": "mvg" });
		np["initial_links"] = helpers.push_ex(np["initial_links"], { "with_id": action_ctx.item_ex.get_id(), "tag": "direct" });
	}

	function prefill_current_user(ctx) {
		return helpers.get_current_user_id(ctx.session);
	}

	add_direct_link("Contact", "Contact", "Owner", false, ["lookup:contacts"], true);
	add_direct_link("Contact", "Account", "Account", false, ["lookup:all_accounts"], true);
	add_direct_link("Contact", "Country", "Country", false, ["lookup:all_countries"], true);
	add_direct_link("Contact", "Region", "Region", false, ["lookup:all_regions"], true);
	add_direct_link("Contact", "City", "City", false, ["lookup:all_cities"], true);

	add_direct_link("Activity", "Opportunity", "Opportunity", false, ["lookup:all_opportunities"], true, "Status");
	add_direct_link("Activity", "Document", "Document", false, ["lookup:all_documents"], true, "Status");
	add_direct_link("Activity", "Invoice", "Invoice", false, ["lookup:all_invoices"], false, "InvoiceStatus");
	add_direct_link("Activity", "Contact", "Owner", false, ["lookup:contacts"], true, "Status");
	add_direct_link("Activity", "Account", "Account", false, ["lookup:all_accounts"], true, "Status");
	add_direct_link("Activity", "Contact", "Contact", false, ["lookup:all_contacts"], true, "Status");

	add_direct_link("Task", "Account", "Account", false, ["lookup:all_accounts"], true, "TaskStatus");
	add_direct_link("Task", "Opportunity", "Opportunity", false, ["lookup:all_opportunities"], true, "TaskStatus");

	add_direct_link("Appointment", "Account", "Account", false, ["lookup:all_accounts"], true, "AppointmentStatus");
	add_direct_link("Appointment", "Opportunity", "Opportunity", false, ["lookup:all_opportunities"], true, "AppointmentStatus");

	add_direct_link("City", "Country", "Country", false, ["lookup:all_countries"], true);
	add_direct_link("City", "Region", "Region", false, ["lookup:all_regions"], true);
	add_direct_link("Region", "Country", "Country", false, ["lookup:all_countries"], true);

	with (scheme.triggers) {
		include("forms.js", "forms");
		add_simple_trigger(on_new_created, null, null, null, "new_created");
		add_simple_trigger(form_helpers.native_show, null, "City", null, "show");
		add_simple_trigger(form_helpers.native_show, null, "Region", null, "show");
		add_simple_trigger(form_helpers.native_show, null, "Country", null, "show");
	}

	with (scheme.objects) {
		get_object("Activity").get_field("Owner")["initial_value_fn"] = prefill_current_user;
		get_object("Contact").get_field("Owner")["initial_value_fn"] = prefill_current_user;
		get_object("Appointment").get_field("Owner")["initial_value_fn"] = prefill_current_user;
		get_object("Appointment").get_field("Shared")["initial_value"] = true;
		get_object("Task").get_field("Owner")["initial_value_fn"] = prefill_current_user;
		get_object("Task").get_field("Shared")["initial_value"] = true;
		get_object("Contact").get_field("Shared")["initial_value"] = true;
		get_object("Appointment").get_field("ShowInScheduler")["initial_value"] = true;
	}

	scheme.objects.get_object("Job").get_field("SuppressFileAs")["initial_value"] = "-";

	return scheme;
}

function mail_processor(ctx) {
	function current_user_id() {
		return helpers.get_current_user_id(ctx.session);
	}

	function item_wrapper(item, item_ex) {
		if (item != null || item_ex != null) {
			return ({
				"item": function () {
					if (item == null)
						item = item_ex.fcd_item;
					return item;
				},
				"item_ex": function () {
					if (item_ex == null)
						item_ex = new data_model.std_item_ex(item, { "set_property_only_if_different": true, "lazy_save": false });
					return item_ex;
				}
			});
		}
		else
			return null;
	}

	function add_association_description(id, proxy, for_each_ctx, tag, unlink) {
		proxy.associations = helpers.merge_contexts({ "link": [], "unlink": [] }, proxy.associations);
		proxy.associations[unlink ? "unlink" : "link"].push({ "with_id": id, "tag": (tag == null ? "mvg" : tag) });
	}

	var get_owner_for_ol_item = function (ol) {
		var result = {
			"owner": current_user_id()
		};
		return result;
	};
	var create_proxy_item = function (ol, notification_params) {
		var create_ctx = { "type": "Activity" };
		var create_result = data_model.prefill_item(ctx, create_ctx);
		var proxy = item_wrapper(create_ctx.item, create_ctx.item_ex);
		link_proxy_item(proxy, ol);
		return proxy;
	};
	var get_proxy_item = function (ol, ol_id) {
		if (ol_id == null) {
			if (ol.item_ex().get_type() == "Mail")
				ol_id = ol.item_ex().get_property("SearchKey");
			else
				ol_id = ol.item_ex().get_id();
		}
		var item = null;
		if (ol_id != null) {
			var filter = ctx.session.create_expression("PIMObjectId", "eq", ol_id);
			item = ctx.session.find_item("Activity", filter);
		}
		return item_wrapper(item);
	};
	var link_proxy_item = function (proxy, ol) {
		var new_pim_id = null;
		if (ol != null && ol.item_ex().get_type() == "Mail") {
			new_pim_id = ol.item_ex().get_property("SearchKey");
		}
		proxy.item_ex().set_property("PIMObjectId", new_pim_id);
	};
	var process_mail_fields = function (proxy, ol) {
		if (ol != null && proxy != null) {
			if (ol.item_ex().get_type() == "Mail") {
				var item = ol.item_ex().fcd_item;
				var completedActivityStatus = '4bdbb88f-58e6-df11-971b-001d60e938c6';
				proxy.item_ex().set_property("Title", ol.item_ex().get_property("Subject"));
				proxy.item_ex().set_property("Body", ol.item_ex().fcd_item.raw_item.HTMLBody);
				proxy.item_ex().set_property("IsHtmlBody", true);
				proxy.item_ex().set_property("StartDate", ol.item_ex().get_property("CreationTime"));
				proxy.item_ex().set_property("DueDate", ol.item_ex().get_property("CreationTime"));
				proxy.item_ex().set_property("Recepient", raw.get_recipints_of_type(ctx.application, item, raw.olTo).toString());
				proxy.item_ex().set_property("Sent", true);
				proxy.item_ex().set_property("Sender", item.SenderAddress);
				proxy.item_ex().set_property("Status", completedActivityStatus);
				proxy.item_ex().set_property("CopyRecepient", raw.get_recipints_of_type(ctx.application, item, raw.olCC).toString());
				proxy.item_ex().set_property("BlindCopyRecepient", raw.get_recipints_of_type(ctx.application, item, raw.olBCC).toString());
			}
		}
	};
	var process_mail_attachments = function (proxy, ol) {
		if (proxy.fcd_item == null && proxy.fcd_item.id == null) {
			return;
		}
		var max_name_length = 80;
		var attachments = ol.fcd_item.Attachments;
		if (attachments != null) {
			attachments = attachments.toArray();
			for (var key in attachments) {
				var attachment = attachments[key];
				var document = ctx.session.create_item("ActivityFile");
				document.assign_property("Data", attachment, "Body");
				document.Activity = proxy.fcd_item.id;
				document.Name = attachment.name.substr(0, max_name_length);
				document.save();
			}
		}
	};
	var process_mail_changes = function (proxy, ol, contacts) {
		link_proxy_item(proxy, ol);
		process_mail_fields(proxy, ol);
		ctx.save(proxy.item());
		process_mail_attachments(proxy.item_ex(), ol.item_ex());
		proxy.item_ex().reset();
		add_association_description(current_user_id(), proxy);
	};
	this.get_proxy = function (ol_item_ex, find_and_create, notification_params) {
		var ol = item_wrapper(null, ol_item_ex);
		var proxy = get_proxy_item(ol);
		if (find_and_create && proxy == null) {
			proxy = create_proxy_item(ol, notification_params);
		}
		return proxy != null ? proxy.item_ex() : null;
	};
	this.process_ol_item_changes = function (proxy_item_ex, ol_item_ex, is_new_proxy) {
		var ol = item_wrapper(null, ol_item_ex);
		ol.created = is_new_proxy;
		var proxy = item_wrapper(null, proxy_item_ex);
		var ol_type = ol.item_ex().get_type();
		if (ol_type == "Mail")
			process_mail_changes(proxy, ol);
	};
}

function mail_owner_validator(context, form) {
	return function (ctx) {
		return true;
	};
}

function contact_conversion_helper() {
	this.converted_to_platform = function (ctx, options, item_ex) {
	};
	this.converting_to_native = function (ctx, options, item_ex) {
	};
	this.set_visible = function (ctx, options, item_ex, visible) {
	};
}