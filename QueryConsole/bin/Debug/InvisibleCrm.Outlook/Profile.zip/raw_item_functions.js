include("helpers.js", "helpers");

/**
	Assignes task
	@param task Task item
	@memberOf raw
*/
function assign_task(task)
{
	task.raw_item.Assign();
}

var olOriginator = 0;
var olTo = 1;
var olCC = 2;
var olBCC = 3;

/**
	Returns email address of specified recipient
	@param {application} application Application object provided by C++
	@param recipient Recipient object
	@memberOf raw
*/
function get_recipient_address(application, recipient)
{
	var result = null;
	try
	{
		var type = recipient.AddressEntry.Type;
		if (type == "SMTP")
			result = recipient.Address;
		else
		{
			var addresses = application.accounts.open_entry(application.session.hexstring_to_id(recipient.EntryID)).toArray();
			if (addresses.length > 0)
				result = addresses[0];
		}
	}
	catch (e)
	{}
	return result;
}

/**
	Returns array of PIM item's recipients of specified type
	@param {application} application Application object provided by C++
	@param item PIM item
	@param type Type name. Can be one of:
		<br>raw_item_functions.olOriginator - Sender
		<br>raw_item_functions.olTo - Recipient
		<br>raw_item_functions.olCC - CC
		<br>raw_item_functions.olBCC - BCC
	@memberOf raw
*/
function get_recipints_of_type(application, item, type)
{
	var result = new Array();
	var recipients = item.raw_item.Recipients;
	for (var i = 1; i <= recipients.Count; i++)
	{
		var recipient = recipients.item(i);
		if (recipient.Type == type)
			result.push(get_recipient_address(application, recipient));
	}
	return result;
}

/**
	Returns list of non-declined attendees
	@param {application} application Application object provided by C++
	@param item PIM item
	@returns Array email addresses
	@memberOf raw
*/
function get_not_declined_attendies(application, item)
{
	var result = new Array();
	try
	{
		var recipients = item.raw_item.Recipients;
		for (var i = 1; i <= recipients.Count; i++)
		{
			var recipient = recipients.item(i);
			if (recipient.MeetingResponseStatus != 4)
				result.push(get_recipient_address(application, recipient));
		}
	}
	catch (e)
	{
		// It is possible to process item changed event for deleted item.
		// Therefore this catch required
	}
	return result;
}

/**
	Updates PIM item recipient address
	@param {application} application Application object provided by C++
	@param item PIM item
	@param {String} address Recipient address
	@memberOf raw
*/
function update_recipient(application, item, address)
{
	var recipients = item.raw_item.Recipients;
	for (var i = 1; i <= recipients.Count; i++)
	{
		var recipient = recipients.item(i);
		if (get_recipient_address(application, recipient) == address || address == recipient.Address)
		{
			if (recipient.MeetingResponseStatus != 4)
				return;
			else
			{
				recipient.Delete();
				break;
			}
		}
	}
	recipients.Add(address).Resolve();
}

/**
	Replaces PIM item recipients list with new valies
	@param {application} application Application object provided by C++
	@param item PIM item
	@param {Array[String]} recipients Array of email addresses
	@memberOf raw
*/
function set_item_attendees(application, item, recipients)
{
	recipients = recipients.toArray();
	// Removing excess
	var something_done = true;
	while (something_done)
	{
		something_done = false;
		var rawRecipients = item.raw_item.Recipients;
		for (var i = 1; i <= rawRecipients.Count; i++)
		{
			var recipient = rawRecipients.item(i);
			if (recipient.MeetingResponseStatus != 4 && !include.helpers.contains(recipients, get_recipient_address(application, recipient)))
			{
				recipient.Delete();
				something_done = true;
				break;
			}
		}
	}
	// Adding new
	for (var enm = new Enumerator(recipients); !enm.atEnd(); enm.moveNext())
	{
		var address = enm.item();
		if (item.SenderAddress != address)
			update_recipient(application, item, address);
	}
}

/**
	Adds recipient address to PIM item
	@param {application} application Application object provided by C++
	@param item PIM item
	@param {String} address Address to add
	@memberOf raw
*/
function add_recipient_to_item(application, item, address)
{
	if (item.type_id == "Task")
		assign_task(item);
	else if (item.type_id == "Event")
	{
		if (item.MeetingStatus == 0)
			item.MeetingStatus = 1;
	} else if (item.type_id == "Appointment") {
		if (item.raw_item.MeetingStatus == 0)
			item.raw_item.MeetingStatus = 1;
	}
	update_recipient(application, item, address);
}

/**
	Deletes recipient address from PIM item
	@param {application} application Application object provided by C++
	@param item PIM item
	@param {string} address Address to delete
	@memberOf raw
*/
function delete_recipient(application, item, address)
{
	var rawRecipients = item.raw_item.Recipients;
	for (var i = 1; i <= rawRecipients.Count; i++)
	{
		var recipient = rawRecipients.item(i);
		if (address == get_recipient_address(application, recipient) || address == recipient.Address)
		{
			recipient.Delete();
			break;
		}
	}
}

/**
	Mark <b>Email<b> item as dirty
	@param mail Email item
	@memberOf raw
*/
function mark_mail_dirty(mail)
{
	mail.raw_item.AutoForwarded = mail.raw_item.AutoForwarded;
}

/**
	Return name of Meeting Organizer
	@param meeting Event item
	@memberOf raw
*/
function get_meeting_organizer_name(meeting)
{
	return meeting.raw_item.Organizer;
}

/**
	Return name of Task Owner
	@param task Task item
	@memberOf raw
*/
function get_task_owner_name(task)
{
	return task.raw_item.Owner;
}

/**
	Return list of non-declined attendees in format: <First Name> <Last Name>(<email>)
	@param {application} application Application object provided by C++
	@param meeting Event item
	@param int type. Can be on of:
			1 - required attendees
			2 - optional attendees
	@memberOf raw
*/
function get_not_declined_attendees_of_type(application, item, type)
{
	var result = new Array();
	try
	{
		var recipients = item.raw_item.Recipients;
		for (var i = 1; i <= recipients.Count; i++)
		{
			var recipient = recipients.item(i);
			if (recipient.MeetingResponseStatus != 4 && recipient.Type == type)
				result.push(recipient.name);
		}
	}
	catch (e)
	{
		// It is possible to process item changed event for deleted item.
		// Therefore this catch required
	}
	return result;
}

function set_item_dirty(item) {
	var fields = {
		"Mail": "AutoForwarded",
		"Event": "NoAging",
		"Task": "NoAging"
	};
	var field = fields[item.type_id];
	var raw_item = item.raw_item;
	var value = raw_item[field];
	raw_item[field] = !value;
	raw_item[field] = value;
}