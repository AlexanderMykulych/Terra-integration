include("data_model.js", "data_model");

/**
@class Idle processing manager. Main class of Idle processing that implements subscription
to application-generated events and performs defined handlers
@constructor
@param {platform_scripts.ctx} ctx General ctx with global objects.
@memberOf idle
*/
function idle_manager2(ctx) {
	var job_handlers = [];

	var idle_engine = ctx.application.idle_engine;
	var forms = ctx.application.forms;

	idle_engine.on_idle_job.connect(on_idle_job);

	function get_job_string(job) {
		var str = null;
		for (var key in job)
			if (key != "id" && key != "name" && key != "immediately" && key != "item") {
				str != null ? str += "," : str = "";
				str += key + "=" + job[key];
			}
		return job.name + (str != null ? ":" + str : "");
	}

	function parse_job_string(job_string) {
		var job = { "name": job_string };
		var pos = job_string.indexOf(":");
		if (pos != -1) {
			job["name"] = job["name"].substring(0, pos);
			job_string = job_string.substring(pos + 1);
			if (job_string.length) {
				helpers.for_each(job_string.split(","), function (option) {
					var splited = option.split("=");
					job[splited[0]] = splited[1];
				});
			}
		}
		return job;
	}

	function enque_job(job) {
		idle_engine.enqueue_idle_job(job.id, get_job_string(job));
	}

	function execute_job(job) {
		var job_handler = job_handlers[job.name];
		if (job_handler != null) {
			var result = null;
			if (job_handler.requires_closed_form && forms.find_by_object(job.id) != null)
				result = false;
			if (job_handler.requires_item) {
				job.item = ctx.session.open_item(job.id);
				if (job.item == null)
					result = true; // No handling and no re-enqueuing required
			}
			if (result == null) {
				job.retry_counter = parseInt(job.retry_counter == null ? "0" : job.retry_counter);
				try
				{ result = job_handler.execute(job); }
				catch (e) {
					result = job_handler.reenqueue_on_exception != true;
				} // "result" set to false if re-enqueue required 
			}
			if (result == false) {
				job.retry_counter++;
				enque_job(job);
			}
		}
	}

	function on_idle_job(id, job_string) {
		var job = parse_job_string(job_string);
		job["id"] = id;
		execute_job(job);
	}

	/**
	Add job handler.
	@param {idle.job_handler} job_handler Job handler to be added
	*/
	this.add_handler = function (job_handler) {
		job_handlers[job_handler.name] = job_handler;
	}

	/**
	Add job to enqueue or execute immediately.
	@param {idle.job} job Job to be executed
	*/
	this.execute_job = function (job) {
		(job["immediately"] ? execute_job : enque_job)(job);
	}
}

/**
@class Class that implements job handler for Idle manager to perform joined fields synchronization in linked items
for example - <b>Client</b> item has linked <b>Address</b> item. Changes in <b>Address Phone</b> field must be applied to <b>Business Phone</b> field of <b>Client</b>
@constructor
@param {platform_scripts.ctx} ctx General ctx with global objects.
@memberOf idle
*/
function joined_fields_updater2(ctx) {
	var descriptions = [];

	function link_description(type, field, cascade) {
		this.type = type;
		this.field = field;
		this.cascade = (cascade == true);
	}

	var get_obj_descriptor = function (type) {
		if (descriptions[type] == null)
			descriptions[type] = new Array();
		return descriptions[type];
	}

	// Description build version 1
	var analize_link = function (link) {
		if (link != null) {
			if (link.link_type == "mvg")
				analize_link(link.left_obj_primary_link);
			else {
				var field_descr = link.get_field_descriptor();
				if (field_descr.require_refresh)
					for (var enm = new Enumerator(field_descr.link_to_types); !enm.atEnd(); enm.moveNext())
						get_obj_descriptor(enm.item()).push(new link_description(field_descr.obj_type, field_descr.name, field_descr.cascade_refresh));
			}
		}
	}

	// Description build version 2
	var analize_field_dscr = function (fld) {
		if (fld.link_refresh_required) {
			function f(to_type) {
				get_obj_descriptor(to_type).push(new link_description(fld.parent.type, fld.name, fld.link_refresh_cascade));
			}
			helpers.for_each(fld.link_to, f);
		}
	}

	var analize_object_dscr = function (obj) {
		obj.for_each_field(analize_field_dscr);
	}

	if (ctx.data_model != null) {
		// Version 2 descriptor
		ctx.data_model.objects.for_each_object(analize_object_dscr);
	}
	else {
		// Version 1 descriptor
		for (; !ctx.links_enumerator.atEnd(); ctx.links_enumerator.moveNext())
			analize_link(ctx.links_enumerator.item());
	}

	// Jobs
	var process_object_update = {
		"name": "ObjectUpdated",
		"execute": function (job) {
			helpers.for_each(descriptions[job["Type"]], function (link_descr) {
				var filter = ctx.session.create_expression(link_descr.field, "eq", job.id);
				helpers.for_each(ctx.session.find_items(link_descr.type, filter), function (child) {
					var new_job = {
						"id": child.id,
						"name": "RefreshField",
						"immediately": job.immediately,
						"Field": link_descr.field
					};
					if (link_descr.cascade)
						new_job["Cascade"] = "";
					ctx.idle_manager.execute_job(new_job);
				});
			});
		}
	}

	var refresh_field =
	{
		"name": "RefreshField",
		"requires_closed_form": true,
		"requires_item": true,
		"execute": function (job) {
			var field = job["Field"];
			var value = job.item[field];
			if (value != null) {
				var related_obj = ctx.session.open_item(value);
				if (related_obj != null) {
					job.item[field] = value;
					ctx.save_helper.save_and_disable_events(job.item, true);
					if (job["Cascade"] != null)
						add_object_update_job(job.item, job.immediately);
				}
			}
		}
	}
	ctx.idle_manager.add_handler(process_object_update);
	ctx.idle_manager.add_handler(refresh_field);

	var add_object_update_job = function (obj, immediately) {
		var type = obj.type_id;
		if (descriptions[type] != null)
			ctx.idle_manager.execute_job({
				"id": obj.id,
				"name": process_object_update.name,
				"immediately": immediately,
				"Type": type
			});
	}

	var object_update_handler = function (obj) {
		add_object_update_job(obj, false);
	}
	ctx.application.on_item_changed.connect(object_update_handler);

	/**
	Manually initiate fields update
	@param obj Item that was updated
	@param immediately Perform job immediatly, do not wait for idle
	*/
	this.register_update = function (obj, immediately) {
		add_object_update_job(obj, immediately);
	}
}

/**
@class Class that implements job handler for Idle manager to perform update of primary field
of parent item when association item was created or removed.
<p>For example, Contact is associated with Account by M:M relationship and has primary account.
Assume that Contact with no Accounts is associated to some Account. This account must become primary on those contact.
Assume that Contact primary association with Account is deleted from those Account. Other associated Account must become primary or primary must be cleared if no other associations exists.</p>
@constructor
@param {platform_scripts.ctx} ctx General ctx with global objects.
@memberOf idle
*/
function primary_updater2(ctx) {
	var task_name = "ValidatePrimary2";

	var default_params =
	{
		"primary_tag": "direct",
		"mvg_tag": "mvg"
	}

	var validate_primary = {
		"name": "ValidatePrimary2",
		"requires_closed_form": true,
		"reenqueue_on_exception": true,
		"requires_item": true,
		"execute": function (job) {
			helpers.merge_contexts(default_params, job);

			var spec_ctx = {
				"item_ex": new data_model.std_item_ex(job.item),
				"link_to": job.link_to,
				"submited": true
			};

			var new_id = false;
			var primary = ctx.linker.linked(helpers.merge_contexts(spec_ctx, { "tag": job.primary_tag }));
			var get_mvg = function () { return ctx.linker.linked(helpers.merge_contexts(spec_ctx, { "tag": job.mvg_tag })); };
			if (job.operation == "created" && primary.count == 0) {
				var mvg = get_mvg();
				if (mvg.count > 0)
					new_id = mvg.values[0];
			}
			else if (job.operation == "removed" && primary.count != 0) {
				var mvg = get_mvg();
				if (!helpers.contains_object_id(ctx.session, mvg.values, primary.values[0]))
					new_id = mvg.count > 0 ? mvg.values[0] : null;
			}
			if (new_id != false) {
				ctx.linker.link(helpers.merge_contexts(spec_ctx, { "with_id": new_id, "tag": job.primary_tag }));
				if (spec_ctx.item_ex.save_called)
					ctx.save(job.item);
			}
		}
	}
	ctx.idle_manager.add_handler(validate_primary);

	var add = function (id, link_to, operation, params) {
		ctx.idle_manager.execute_job(helpers.merge_contexts({
			"id": id,
			"name": "ValidatePrimary2",
			"immediately": true,
			"link_to": link_to,
			"operation": operation
		}, params));
	}

	var submit_trigger = function (ctx, action_ctx) {
		var link_to = action_ctx.item_ex.get_type();

		function f(id, operation) { add(id, link_to, operation); }

		helpers.for_each(action_ctx.notification_params.created, f, "created");
		helpers.for_each(action_ctx.notification_params.removed, f, "removed");
	}

	var created_removed_trigger = function (ctx, action_ctx) {
		if (action_ctx.submited)
			add(action_ctx.with_id, action_ctx.item_ex.get_type(), action_ctx.operation);
	}

	this.submit_trigger = submit_trigger;
	this.created_removed_trigger = created_removed_trigger;

	this.add = function (ids, params) {
		helpers.for_each2(ids, function (id) { add(id, null, null, params); });
	}
}

function update_primary_on_submit_trigger(ctx, action_ctx) {
	ctx.primary_updater.submit_trigger(ctx, action_ctx);
}
function update_primary_on_created_removed_trigger(ctx, action_ctx) {
	ctx.primary_updater.created_removed_trigger(ctx, action_ctx);
}

/**
@class Class that helps to handle item conversion.
<p>This class is required to handle late custom fields adding to converted item that may cause exceptions.</p>
@constructor
@param {platform_scripts.ctx} ctx General ctx with global objects.
@param {idle.item_convert_helper_options} options Options that configures conversion.
@memberOf idle
*/
function item_convert_helper(ctx, options) {
	var task_name = "ConvertedToPlatform";

	function save(item_ctx) {
		if (item_ctx.item_ex.dirty)
			;
	}

	var converted_to_platform = {
		"name": task_name,
		"requires_closed_form": true,
		"reenqueue_on_exception": true,
		"requires_item": true,
		"execute": function (job) {
			var item_ctx = create_item_ctx(job.item);
			try {
				item_ctx.converted_to_platform();
				if (job.retry_counter)
					item_ctx.set_visible(true);
				item_ctx.save();
			}
			catch (e) {
				item_ctx.set_visible(false);
				item_ctx.save();
				throw e;
			}
		}
	}
	ctx.idle_manager.add_handler(converted_to_platform);

	function create_item_ctx(item) {
		return ({
			"item_ex": new data_model.std_item_ex(item),
			"type_descr": options.types[item.type_id],
			"converting_to_native": function ()
			{ this.type_descr.converting_to_native(ctx, options, this.item_ex); },
			"converted_to_platform": function ()
			{ this.type_descr.converted_to_platform(ctx, options, this.item_ex); },
			"set_visible": function (visible)
			{ if (this.type_descr.set_visible != null) this.type_descr.set_visible(ctx, options, this.item_ex, visible); },
			"save": function ()
			{ if (this.item_ex.dirty) ctx.save_helper.save_and_disable_events(this.item_ex.fcd_item); }
		});
	}

	function convert_to_siebel(item) {
		ctx.idle_manager.execute_job({
			"id": item.id,
			"name": task_name,
			"immediately": true
		});
	}

	function converting_to_native(item) {
		var item_ctx = create_item_ctx(item);
		item_ctx.converting_to_native(ctx, options, item_ctx.item_ex);
		item_ctx.save();
	}

	this.item_convertor = ctx.application.item_convertor;
	this.item_convertor.on_converted_to_platform.connect(convert_to_siebel);
	this.item_convertor.on_converted_to_native.connect(converting_to_native);
}
//////////////////////////////////////////////////////////////////////////
// Deprecated functions leaved for backward compatibility only
//////////////////////////////////////////////////////////////////////////

/**
@class Idle processing manager. Main class of Idle processing that implements subscription
to application-generated events and performs defined handlers
@constructor
@param {application} application Application object provided by C++
@extends idle.idle_manager2
@memberOf idle
@deprecated Use {@link idle.idle_manager2}
*/
function idle_manager(application) {
	idle_manager2.call(this, { "application": application, "session": application.session });

	/**
	Adds job to queue
	@param id Item ID
	@param {String} prefix Job handler preffix
	@param params Parametrers array
	@param immediately Perform job immediatly, do not wait for idle
	*/
	this.add_job = function (id, prefix, params, immediately) {
		this.execute_job(helpers.merge_contexts(params, {
			"id": id,
			"name": prefix,
			"immediately": immediately
		}));
	}

	/**
	Adds job handler
	@param {String} prefix Job handler preffix
	@param {Function} handler Job handler callback function
	@param {Boolean} requires_closed_form Job cannot be performed if item is currently opened on form
	*/
	this.add_job_handler = function (prefix, handler, requires_closed_form) {
		this.add_handler({
			"name": prefix,
			"execute": function (job) { return handler(job.id, job, job.immediately); },
			"requires_closed_form": requires_closed_form
		});
	}
}

/**
@class Class that implements job handler for Idle manager to perform joined fields synchronization in linked items
for example - <b>Client</b> item has linked <b>Address</b> item. Changes in <b>Address Phone</b> field must be applied to <b>Business Phone</b> field of <b>Client</b>
@constructor
@param {application} application Application object provided by C++
@param {idle.idle_manager} idle_manager Instance of idle_manager class
@param {data_model.data_model} data_model Data Model or links enumerator (can be retrieved by meta_scheme.get_links_enumerator(), supported for backward compatibility).
@param {helpers.save_helper} item_saver Items saving helper
@extends idle.joined_fields_updater2
@memberOf idle
@deprecated Use {@link idle.joined_fields_updater2}.
*/
function joined_fields_updater(application, idle_manager, data_model, item_saver) {
	joined_fields_updater2.call(this, {
		"application": application,
		"session": application.session,
		"idle_manager": idle_manager,
		"data_model": data_model.objects != null ? data_model : null,
		"links_enumerator": data_model.objects == null ? data_model : null,
		"save_helper": item_saver
	});
}

/**
@class Class that implements job handler for Idle manager to perform update of primary field
of parent item when association item was created or removed
@constructor
@param {application} application Application object provided by C++
@param {idle.idle_manager} idle_manager Instance of idle_manager class
@param {meta_scheme} meta_scheme Meta scheme, can be get from application script or created manualy
@memberOf idle
@deprecated Use {@link idle.primary_value_updater2}.
*/
function primary_value_updater(application, idle_manager, meta_scheme) {
	var session = application.session;

	var link_to_type_param = "LinkToType";
	var type_param = "Type";
	var type_added_value = "added";
	var type_removed_value = "removed";
	var validate_primary_task = "ValidatePrimary";

	var objects_linker_facrory = new data_model.objects_linker_facrory(session, null, null, meta_scheme);

	var get_mvg_helper = function (from_type, to_type) {
		return objects_linker_facrory.create(from_type, to_type);
	}

	var get_primary_field = function (from_type, to_type) {
		return meta_scheme.get_mvg_link_primary_field_name(from_type, to_type);
	}

	var need_prefill_primary = function (from_type, to_type) {
		var descr = meta_scheme.get_mvg_link_primary_description(from_type, to_type);
		return descr != null ? descr.prefill_for_first_association : false;
	}

	var validate_primary = function (id, params, immediately) {
		var obj = session.open_item(id);
		if (obj != null) {
			try {
				var from_type = obj.type_id;
				var to_type = params[link_to_type_param];
				var change_type = params[type_param];
				var helper = get_mvg_helper(from_type, to_type);
				var field = get_primary_field(from_type, to_type);
				var prefill_primary = need_prefill_primary(from_type, to_type);
				var field_value = obj[field];
				if (prefill_primary && change_type == type_added_value && field_value == null) {
					var new_value = helper.get_any_saved_associated_id(obj);
					if (new_value != null) {
						obj[field] = new_value;
						obj.save();
					}
				}
				if (change_type == type_removed_value && field_value != null && helper.get_saved_associated_ids(obj, field_value).length == 0) {
					obj[field] = prefill_primary ? helper.get_any_saved_associated_id(obj) : null;
					obj.save();
				}
			}
			catch (e) {
				return false;
			}
		}
	}
	idle_manager.add_job_handler(validate_primary_task, validate_primary, true);

	var add_job = function (id, association_with_type, type) {
		var params = new Array();
		params[link_to_type_param] = association_with_type;
		params[type_param] = type;
		idle_manager.add_job(id, validate_primary_task, params, true);
	}

	/**
	Performs checking of primary field when association item was created
	@param id Parent item ID
	@param {String} link_to_type Type of linked item
	*/
	this.track_association_add = function (id, link_to_type) {
		add_job(id, link_to_type, type_added_value);
	}

	/**
	Performs checking of primary field when association item was removed
	@param id Parent item ID
	@param {String} link_to_type Type of linked item
	*/
	this.track_association_remove = function (id, link_to_type) {
		add_job(id, link_to_type, type_removed_value);
	}
}
