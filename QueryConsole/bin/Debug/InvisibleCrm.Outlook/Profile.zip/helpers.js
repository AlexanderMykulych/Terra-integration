var TrackStatus = {
	 "SharedFlagStatus" : 2,
	"UnSharedFlagStatus" : 0
};

var ask_delete_confirmation = true;

/**
	@class Helper class that implements items saving
	@constructor
	@param {application} application Application object provided by C++
	@memberOf helpers
*/
function save_helper(application)
{
	var session = application.session;
	var recursion_guard_array = new Array();
	
	var get_key = function(item)
	{
		var sk = item.SearchKey;
		return sk != null ? session.id_to_hexstring(sk) : null;
	}
	
	var register_saving = function(key)
	{
		if (key != null)
		{
			if (recursion_guard_array[key] == null)
				recursion_guard_array[key] = 1;
			else
				recursion_guard_array[key] = recursion_guard_array[key] + 1;
		}
	}

	var unregister_saving = function(key)
	{
		if (key != null)
		{
			if (recursion_guard_array[key] == 1)
				recursion_guard_array[key] = null;
			else
				recursion_guard_array[key] = recursion_guard_array[key] - 1;
		}
	}

	/**
		Disables saving events for item
		@param item Item to disable events for it
		@param {Integer} [disable_count=1] Count of events to disable
	*/
	this.disable_events = function(item, disable_count)
	{
		if (disable_count == null)
			disable_count = 1;
		application.skip_events(item, 1);
		for (var i = 0; i < disable_count; i++)
			application.skip_events(item, 2);
	}

	/**
		Saves item and disables saing events while save in progress
		@param item Item to save
		@param {Boolean} silent If True do not update item's timestamp
		@param [object_to_save=item] Subform item
		@param {Integer} [disable_count=1] Count of events to disable
	*/
	this.save_and_disable_events = function(item, silent, object_to_save, disable_count)
	{
		var key = get_key(item);
		if (object_to_save == null)
			object_to_save = item;
		try
		{
			register_saving(key);
			if (silent == true)
				object_to_save.silent_save();
			else
				object_to_save.save();
			this.disable_events(item, disable_count);
		}
		finally
		{
			unregister_saving(key);
		}
	}
	
	/**
		Check if item save is in progress
		@param item Item to check
		@returns True if saving in progress
	*/
	this.is_saving_now = function(item)
	{
		var key = get_key(item);
		return key != null && recursion_guard_array[key] != null;
	}
}

/**
	Perform function call for every element in Enumeration.
	@param enm Enumeration
	@param f Function with signature "f(item, params, {@link helpers.for_each_ctx})".
	@param [params] Additional parameter
	@memberOf helpers
*/
function for_each(enm, f, params)
{
	if (enm != null)
	{
		var for_each_ctx = {"interrupted": false };
		for (var e = new Enumerator(enm); !e.atEnd() && !for_each_ctx.interrupted; e.moveNext())
			f(e.item(), params, for_each_ctx);
	}
}

/**
	Perform function call for every element in Enumeration.
	This function is almost the same as {@link helpers#for_each} except that it use "for (var key in enm)" instead of "Enumerator" object.
	@param enm Enumeration
	@param f Function with signature "f(item, params, {@link helpers.for_each_ctx})".
	@param [params] Additional parameter
	@memberOf helpers
*/
function for_each2(enm, f, params)
{
	if (enm != null)
	{
		var for_each_ctx = { "interrupted": false };
		for (var key in enm)
		{
			f(enm[key], params, for_each_ctx);
			if (for_each_ctx.interrupted)
				break;
		}
	}
}

/**
	Enumerates search result and returns found items IDs
	@param fr Search result
	@returns Array of items IDs
	@memberOf helpers
*/
function find_result2ids_array(fr)
{
	var result = new Array();
	function f(item)
	{
		result.push(item.id);
	}
	for_each(fr, f);
	return result;
}

/**
    Case insensetive comparation for strings
    @param base string
    @param string we want to comapre
    @returns true or false depends on result
    @memberOf helpers
**/
function ci_eqaul(s1, s2)
{
	var to_lower = function(s) { return s == null ? null : s.toLowerCase(); };
	return to_lower(s1) == to_lower(s2);
}

/**
    Case sensetive comparation for strings
    @param base string
    @param string we want to comapre
    @returns true or false depends on result
    @memberOf helpers
**/
function cs_eqaul(s1, s2) 
{
    return s1 == s2;
}

/**
    Checks if array contains object (via predicate)
    @param array Array of items to check for object
    @param object Object to check
    @param predicate
    @returns True if array contains object
    @memberOf helpers
*/
function contains_ex(array, object, predicate) {
    for (var key in array)
        if (predicate(array[key], object))
            return true;
    return false;
}

/**
    Checks if array contains object (sensetive)
    @param array Array of items to check for object
    @param object Object to check
    @returns True if array contains object
    @memberOf helpers
*/
function contains(array, object) 
{
    return contains_ex(array, object, cs_eqaul);
}

/**
    Checks if array contains object (insensetive)
    @param array Array of items to check for object
    @param object Object to check
    @returns True if array contains object
    @memberOf helpers
*/
function ci_contains(array, object) 
{
    return contains_ex(array, object, ci_eqaul);
}

/**
	Copyes all fields that are not exists in destination from source to destination
	@param source Source object
	@param [dest] Destination object
	@returns Updated dest object or copy of source if dest=null
	@memberOf helpers
*/
function merge_contexts(source, dest)
{
	if (dest == null)
		dest = {};
	if (source != null)
		for (var key in source)
			if (dest[key] == null)
				dest[key] = source[key];
	return dest;
}

/**
	Returns object containting only fields from defined list
	@param source Source object
	@param fields Fields array
	@returns Generated object
	@memberOf helpers
*/
function get_restricted_context(source, fields)
{
	var result = {};
	for_each(fields, function(field) { result[field] = source[field]; });
	return result;
}

function push_ex(array, value)
{
	if (array == null)
		array = [];
	array.push(value);
	return array;
}

function push_array_ex(array, insert_array)
{
	if (array == null)
		array = [];
	return array.concat(insert_array);
}

/**
Checks if array contains binary object
@param array Array of items to check for object
@param object Binary object to check
@returns True if array contains object
@memberOf helpers
*/
function contains_binary(array, object)
{
	var first = 0;
	var last = array.length - 1;
	while (last - first > 1)
	{
		var middle = Math.round((first + last) / 2);
		var el = array[middle];
		if (el > object)
			last = middle;
		else
			first = middle;
	}
	return (array[first] == object || array[last] == object);
}

/**
	Safely compares two object IDs
	@param {session} session Session object provided by C++
	@param id1 First ID to compare
	@param id2 Second ID to compare
	@returns True if IDs are equal (also if both are null)
	@memberOf helpers
*/
function ids_equal(session, id1, id2)
{
	return (id1 == null && id2 == null) || (id1 != null && id2 != null && session.equal_ids(id1, id2))
}

/**
	Checks if array of IDs contains specified ID
	@param {session} session Session object provided by C++
	@param array Array of items IDs
	@param id Object ID to check
	@returns True if array contains specified ID
	@memberOf helpers
*/
function contains_object_id(session, array, id)
{
	for (var key in array)
		if (ids_equal(session, array[key], id))
			return true;
	return false;
}

/**
	Checks if array of items contains specified item
	@param {session} session Session object provided by C++
	@param array Array of items
	@param object Item to check
	@returns True if array contains specified item
	@memberOf helpers
*/
function contains_object(session, array, object)
{
	var object_id = object.id;
	for (var key in array)
		if (session.equal_ids(array[key].id, object_id))
			return true;
	return false;
}

/**
	Creates copy of array excluding duplicates
	@param source_array Source array
	@returns Copy of source array without duplicates
	@memberOf helpers
*/
function stable_unique_array(source_array)
{
	var result_array = new Array();
	for (var key in source_array)
		if (!contains(result_array, source_array[key]))
			result_array.push(source_array[key]);
	return result_array;
}

/**
	Creates copy of array of IDs excluding duplicates
	@param {session} session Session object provided by C++
	@param source_array Source array
	@returns Copy of source array without duplicates
	@memberOf helpers
*/
function stable_unique_id_array(session, source_array)
{
	var result_array = new Array();
	for (var key in source_array)
		if (!contains_object_id(session, result_array, source_array[key]))
			result_array.push(source_array[key]);
	return result_array;
}

/**
	Creates copy of array of items excluding duplicates
	@param {session} session Session object provided by C++
	@param source_array Source array
	@returns Copy of source array without duplicates
	@memberOf helpers
*/
function stable_unique_objects_array(session, source_array)
{
	var result_array = new Array();
	for (var key in source_array)
		if (!contains_object(session, result_array, source_array[key]))
			result_array.push(source_array[key]);
	return result_array;
}

/**
	Append all elements of one array to another
	@param dest Destination array
	@param additional Array to append
	@memberOf helpers
*/
function push_array(dest, additional)
{
	for (var enm = new Enumerator(additional); !enm.atEnd(); enm.moveNext())
		dest.push(enm.item());
}

/**
	Converts integer value to string
	@param number Value to convert
	@param digits_count Minimul numbetr length (in digits)
	@example
	int_to_string(-123, 0);  // result: 123
	int_to_string(-123, 10); // result: -0000000123
	@memberOf helpers
*/
function int_to_string(number, digits_count)
{
	var negative = (number < 0);
	if (negative)
		number = -number;
	var str = "" + number;
	while (str.length < digits_count)
		str = "0" + str;
	if (negative)
		str = "-" + str;
	return str;
}

/**
	Returns copy of specified date without time values
	@param {Date} datetime Date
	@return Copy of specified date without time values
	@memberOf helpers
*/
function get_date_without_time(datetime)
{
	var date = new Date(datetime);
	date.setMilliseconds(0);
	date.setSeconds(0);
	date.setMinutes(0);
	date.setHours(0);
	return date.getVarDate();
}

/**
	Formates date
	@param {Date} date Date
	@param {String} format Date format:
		<br>ss - Seconds. Number of digits - 2
		<br>s - Seconds. Number of digits - 1
		<br>mm - Minutes. Number of digits - 2
		<br>m - Minuter. Number of digits - 1
		<br>HH - Hours in 24h format. Number of digits - 2
		<br>H - Hours in 24h format. Number of digits - 1
		<br>hh - Hours in 12h format. Number of digits - 2
		<br>h - Hours in 12h format. Number of digits - 1
		<br>dd - Day of month. Number of digits - 2
		<br>d - Day of month. Number of digits - 1
		<br>MM - Month. Number of digits - 2
		<br>M - Month. Number of digits - 1
		<br>yyyy - Year
		<br>a - AM/PM suffix
	@example
		format_date(new Date(2010, 30, 06, 15, 11, 01, 0), "dd-MM-yyyy HH:mm:ss"); // result: 30-06-2010 15:11:01
		format_date(new Date(2010, 30, 06, 15, 11, 01, 0), "d-MM-yyyy h:m:s a"); // result: 30-6-2010 3:11:1 PM
	@returns String containing formatted date
	@memberOf helpers
*/
function format_date(date, format)
{
	var seconds = date.getSeconds();
	var minutes = date.getMinutes();
	var hours = date.getHours();
	var day_of_month = date.getDate();
	var month = date.getMonth() + 1;

	var am_mp = hours < 12 ? "AM" : "PM";
	var am_pm_hours = hours % 12;
	if (am_pm_hours == 0)
		am_pm_hours = 12;
	
	format = format.replace("ss", int_to_string(seconds, 2));
	format = format.replace("s", int_to_string(seconds));
	format = format.replace("mm", int_to_string(minutes, 2));
	format = format.replace("m", int_to_string(minutes));
	format = format.replace("HH", int_to_string(hours, 2));
	format = format.replace("H", int_to_string(hours));
	format = format.replace("hh", int_to_string(am_pm_hours, 2));
	format = format.replace("h", int_to_string(am_pm_hours));

	format = format.replace("dd", int_to_string(day_of_month, 2));
	format = format.replace("d", int_to_string(day_of_month));
	format = format.replace("MM", int_to_string(month, 2));
	format = format.replace("M", int_to_string(month));
	format = format.replace("yyyy", int_to_string(date.getFullYear()));

	format = format.replace("a", am_mp);
	return format;
}

function format(templ, values)
{
	for (var key in values)
		templ = helpers.replace_all("{" + key + "}", values[key], templ);
	return templ;
}

/**
	Replaces all occurances of substring from string
	@param {String} repl_what String to replace
	@param {String} repl_with String to replace with
	@param {String} str Source string
	@returns Result string
	@memberOf helpers
*/
function replace_all(repl_what, repl_with, str)
{
	var result = str;
	while (true)
	{
		var old_r = result;
		result = result.replace(repl_what, repl_with);
		if (result == old_r)
			break;
	}
	return result;
}

/**
	@class Class that manages events connections
	@constructor
	@memberOf helpers
*/
function events_connection()
{
	this.notifications = new Array();

	/**
		Connect event
		@param ctrl Event provider (such as UI control, C++ object or script class)
		@param {String} event Event name
		@param {Function} handler Event handler callback
		@example
			function ob_btn_click_callback()
			{
				// do something...
			}
			events.connect(button, "on_click", ob_btn_click_callback);
	*/
	this.connect = function(ctrl, event, handler)
	{
		this.notifications.push(ctrl);
		ctrl[event].connect(handler);
	}
}

function recursion_guard(limit)
{
	if (limit == null)
		limit = 1;
	var current = 0;

	this.limit_reached = function()
	{
		return current >= limit;
	}

	this.wrap_function = function(f)
	{
		function guarded()
		{
			if (current < limit)
			{
				try
				{
					current++;
					f.apply(this, arguments);
					current--;
				}
				catch (e)
				{
					current--;
					throw e;
				}
			}
		}
		return guarded;
	}
}

function guard_reccursion(f, limit)
{
	return new recursion_guard(limit).wrap_function(f);
}

function call_once(f)
{
	return (function()
	{
		if (f != null)
		{
			var fc = f;
			f = null;
			fc.apply(this, arguments);
		}
	});
}

/**
@class Signal implementation for using in scripting classes
@constructor
@memberOf helpers
*/
function signal(options)
{
	var callbacks = [];

	/**
	Adds handler callback to signal
	@param {Function} callback  Event handler callback
	*/
	this.connect = function(callback)
	{
		callbacks.push(callback);
	}

	/**
	Raises signal
	Can take any number and type of parameters (max. 5 in current implementation)
	*/
	this.raise = function()
	{
		for_each(callbacks, function(cb, args) { cb.apply(undefined, args) }, arguments);
	}

	if (options != null && options.rc_guard != null)
		this.raise = new recursion_guard(options.rc_guard).wrap_function(this.raise);
}

/**
	Safely gets item ID
	@param item Item to get ID from
	@returns Item's ID. null if it can't be taken (item is new or broken)
	@memberOf helpers
*/
function safe_get_id(item)
{
	try
	{
		return item.id();
	}
	catch(e)
	{
		return null;
	}
}

/**
	Checks if item is not new (created but not saved)
	@param item Item to check
	@returns True if item is new
	@memberOf helpers
*/
function is_new_item(item)
{
	try
	{
		item.id();
	}
	catch(e)
	{
		return true;
	}
	return false;
}

/**
	Safely saves item
	@param item Item to save
	@returns True if successfully saved
	@memberOf helpers
*/
function save_item(item)
{
	try
	{
		item.save();
		return true;
	}
	catch(e)
	{
		return false;
	}
	return true;
}

/**
	Saves item and shows error message if failed
	@param {session} session Session object provided by C++
	@param {ui} ui UI object provided by C++
	@param item Item to save
	@param [item_to_save=item] Subform item
	returns True if successfully saved
	@memberOf helpers
*/
function ensure_saved(session, ui, item, item_to_save)
{
	if (item_to_save == null)
		item_to_save = item;
	if (helpers.safe_get_id(item) == null)
		return ui.message_box(0, session.res_string("msg_item_not_saved"), session.res_string("msg_item_not_saved_caption"), 0x44) == 6 && helpers.save_item(item_to_save);
	return true;
}

/**
	Asks user to confirm deletion.
	If ask_delete_confirmation is False, simply returns True
	@param {ui} ui UI object provided by C++
	@param {session} session Session object provided by C++
	@returns True if user confirmed deletion
	@memberOf helpers
*/
function delete_confirmation(ui, session)
{
	if (!ask_delete_confirmation)
		return true;
	return ui.message_box(0, session.res_string("msg_delete_confirmation_message"), session.res_string("msg_delete_confirmation_caption"), 0x24) == 6;
}

/**
	Safely gets acdcount addresses
	@param {application} application Application object provided by C++
	@returns Array of addresses strings
	@memberOf helpers
*/
function safe_get_account_addresses(application)
{
	if (application)
	{
		try
		{
			return application.accounts.addresses.toArray();
		}
		catch(e)
		{
		}
	}
	return new Array();
}

/**
	Checks if character is whitespace or tabulation
	@param ch Character to check
	@returns True if character is whitespace or tabulation
	@memberOf helpers
*/
function is_white_space(ch)
{
	return ch == " " || ch == "\t";
}

/**
	Removes whitespaces and tabulations from start and end of string
	@param {String} str Input string
	@returns Result string
	@memberOf helpers
*/
function trim(str)
{
	var first = 0;
	while (str.length > first && is_white_space(str.charAt(first)))
		first++;
	var last = str.length - 1;
	while (last > first && is_white_space(str.charAt(last)))
		last--;
	return str.slice(first, last + 1);
}

/**
	Returns copy of specified date without seconds value
	@param {Date} datetime Date
	@return Copy of specified date without seconds values
	@memberOf helpers
*/
function clear_seconds(datetime)
{
	var dt = new Date(datetime);
	dt.setSeconds(0);
	return dt.getVarDate();
}

/**
	Removes '\', '/', ';', ':' '*', '?', '"', '<', '>' and '|' from string
	@param {String} file_name Input string
	@returns Result string
	@memberOf helpers
*/
function crear_filename(file_name)
{
	var regexp = /[\\\/\:\*\?\"\<\>\|]/g;
	return trim(file_name.replace(regexp, ""));
}

/**
	Return '::Defaults' item
	@param {session} session Session object provided by C++
	@returns ::Defaults item, null if not exists
	@memberOf helpers
*/
function get_defaults(session)
{
	return session.find_item("::Defaults", session.create_criteria("or"));
}

/**
	Returns ID of current user's item
	@param {session} session Session object provided by C++
	@returns ID of item of current user, null if not exists
	@memberOf helpers
*/
function get_current_user_id(session) 
{
	var defaults = get_defaults(session);
	return defaults != null ? defaults.CurrentUser : null;
}

function get_current_user_string_id(session)
{
	var defaults = get_defaults(session);
	return defaults != null ? session.open_item(defaults.CurrentUser)["String Id"] : "";
}

/**
	Returns current user's item
	@param {session} session Session object provided by C++
	@returns Item of current user, null if not exists
	@memberOf helpers
*/
function get_current_user(session)
{
	var current_user_id = get_current_user_id(session);
	return current_user_id != null ? session.open_item(current_user_id) : null;
}

function safe_call(f)
{
	try
	{
		return ({ "success": true, "result": f() });
	}
	catch (e)
	{
		return ({ "success": false });
	}
}

/**
Returns formatted string.
@param {bayan_string} string in bayan_string format like ":[:(First Name) :]:[:(Last Name):]".
@source {source} item to apply bayan_string.
@returns formatted string with values from source.
@memberOf helpers
*/
function parse_string(bayan_string, source)
{
	if (!bayan_string) return bayan_string;

	function remove_symblols(str, symbols)
	{
		var regexp = symbols.join("|");
		return str.replace(new RegExp(regexp, "g"), "");
	}
	function get_all_substr_between(str, start, end)
	{
		var regexp = new RegExp(start + "[\\s\\S]*?" + end, "g");
		var matched = str.match(regexp);
		var result = new Array();
		if (matched)
		{
			for (var matchIndex = 0; matchIndex < matched.length; matchIndex++)
				result.push(remove_symblols(matched[matchIndex], [start, end]));
		}
		return result;
	}
	function field_value_inserter(instance)
	{
		return instance.replace(/:\(([\S\s]*?)\)/g,
			function(replace_value, fieldName)
			{
				return (source[fieldName]) ? source[fieldName] : "";
			});
	}
	function get_character_between_instances(instances, index)
	{
		var cur_substr_index = (index == instances.length) ? bayan_string.length : bayan_string.indexOf(":[" + instances[index] + ":]");
		var perv_subst = ":[" + instances[index - 1] + ":]"
		var perv_substr_index = (index == 0) ? 0 : bayan_string.indexOf(perv_subst) + perv_subst.length;
		return (perv_substr_index != -1 && cur_substr_index != -1) ? bayan_string.substring(perv_substr_index, cur_substr_index) : "";
	}
	var result = "";
	var instances = get_all_substr_between(bayan_string, ":\\[", ":\\]");

	for (var instIndex in instances)
	{
		result += get_character_between_instances(instances, instIndex);
		
		var instance = instances[instIndex];
		var fields = get_all_substr_between(instance, ":\\(", "\\)");
		var is_not_empty_field = false;
		for (var fieldIndex in fields)
			is_not_empty_field = (!!source[fields[fieldIndex]]) || is_not_empty_field;

		if (is_not_empty_field)
		{
			result += field_value_inserter(instance);
		}
	}
	result += get_character_between_instances(instances, instances.length);
	return result;
}

function retrieve_single_item(ctx) {
	var enm = new Enumerator(ctx);
	if (!enm.atEnd() && enm.item() != null)
		return enm.item();
	return null;
}


function get_recipient_address(application, recipient) {
	var result = null;
	try {
		var type = recipient.AddressEntry.Type;
		if (type == "SMTP" && recipient.Address != "")
			result = recipient.Address;
		else {
			var addresses = application.accounts.open_entry(application.session.hexstring_to_id(recipient.EntryID)).toArray();
			if (addresses.length > 0)
				result = addresses[0];
		}
	}
	catch (e) { }
	return result;
}