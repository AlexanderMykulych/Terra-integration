include("helpers.js", "helpers");
include("data_model.js", "data_model");
include("business_logic.js", "business_logic");
include("actions.js", "actions");
include("security_utils.js", "security_utils");
include("idle.js", "idle");
include("mail_processing.js", "mail_processing");
include("actions_support.js", "actions_support");
include("raw_item_functions.js", "raw_item_functions");

var item_saver = new helpers.save_helper(application);
var idle_manager = new idle.idle_manager(application);
var action_manager = actions_support.create_action_manager(application, util);

var g_ctx =
{
	"application": application,
	"session": session,
	"ui": ui,
	"synchronizer": application.synchronizer,
	"save_helper": item_saver,
	"data_model": business_logic.create_meta_scheme(),
	"cfp_manager": new actions_support.created_from_parent_manager(session),
	"save": function (item) {
		item_saver.save_and_disable_events(item, true, null, 2);
	},
	"idle_manager": idle_manager
};

var track_item = {
	"name": "TrackItem",
	"requires_closed_form": true,
	"reenqueue_on_exception": true,
	"requires_item": true,
	"execute": function (job) {
		var item = session.open_item(job.id);
		try {
			item.Shared = job.track === "true";
			item.save();
		} catch (e) {
			throw e;
		}
		return true;
	}
};

var update_activity_handler = {
	"name": "update_activity_handler",
	"requires_closed_form": true,
	"reenqueue_on_exception": true,
	"requires_item": true,
	"execute": function (job) {
		var item = session.open_item(job.id);
		update_activity(item);
		return true;
	}
};

idle_manager.add_handler(track_item);
idle_manager.add_handler(update_activity_handler);

function delete_participants(ctx, type, item) {
	var activityFilter = ctx.session.create_criteria("and");
	activityFilter.add(ctx.session.create_expression("Activity", "eq", item.id));
	var participants = new Enumerator(ctx.session.find_items(type, activityFilter));
	for (var enm = participants; !enm.atEnd() ; enm.moveNext()) {
		var participant = enm.item();
		var exist = false;
		for (var i = 1; i < item.raw_item.Recipients.Count + 1; i++) {
			var recipient = item.raw_item.Recipients.Item(i);
			var filter = ctx.session.create_criteria("or");
			filter.add(ctx.session.create_expression("Email", "eq", recipient.Address));
			var contacts = new Enumerator(ctx.session.find_items("Contact", filter));
			for (var enm = contacts; !enm.atEnd() ; enm.moveNext()) {
				if (enm.item() != null && participant != null && ctx.session.equal_ids(participant.id, enm.item().id)) {
					exist = true;
					break;
				}
			}
		}
		if (!exist) {
			ctx.session.open_item(participant.id).remove();
		}
	}
}

function add_participants(ctx, type, item) {
	var activityFilter = ctx.session.create_criteria("and");
	activityFilter.add(ctx.session.create_expression("Activity", "eq", item.id));
	for (var i = 1; i < item.raw_item.Recipients.Count + 1; i++) {
		var exist = false;
		participants = new Enumerator(ctx.session.find_items(type, activityFilter));
		var recipient = item.raw_item.Recipients.Item(i);
		var filter = ctx.session.create_criteria("and");
		filter.add(ctx.session.create_expression("Email", "eq", recipient.Address));
		for (participants; !participants.atEnd() ; participants.moveNext()) {
			if (participants.item().Participant == null) {
				continue;
			}
			var participant = ctx.session.open_item(participants.item().Participant);
			var contacts = new Enumerator(ctx.session.find_items("Contact", filter));
			for (contacts; !contacts.atEnd() ; contacts.moveNext()) {
				var contact = contacts.item();
				if (contact != null && participant != null && ctx.session.equal_ids(participant.id, contact.id)) {
					exist = true;
					break;
				}
			}
		}
		if (!exist) {
			if (contact == null) {
				contact = ctx.session.find_item("Contact", filter);
				if (contact == null) {
					return;
				}
			}
			var taskParticipant = ctx.session.create_item(type);
			taskParticipant.Activity = item.id;
			taskParticipant.Participant = contact.id;
			taskParticipant.silent_save();
		}
	}
}

function update_activity(item) {
	if (item.type_id == "Appointment") {
		item.ShowInScheduler = true;
		item.GlobalActivityID = item.raw_item.GlobalAppointmentID;
		delete_participants(g_ctx, item.type_id + "Participant", item);
		add_participants(g_ctx, item.type_id + "Participant", item);
	}
	g_ctx.save(item);
}

function on_item_created(item) {
	if (item.type_id == "Appointment" || item.type_id == "Task") {
		g_ctx.idle_manager.add_job(item.id, "update_activity_handler", {}, false);
	}
	process_activity_participant(item, add_participant);
}

function on_item_before_delete(item) {
	process_activity_participant(item, delete_participant);
}

function on_item_changed(item) {
	if (item.type_id == "Appointment" || item.type_id == "Task") {
		g_ctx.idle_manager.add_job(item.id, "update_activity_handler", {}, false);
	}
}

function on_item_deleted(item_id) {
}

function delete_participant(activity, contact) {
	raw_item_functions.delete_recipient(application, activity, contact.Email);
	g_ctx.save(activity);
}

function add_participant(activity, contact) {
	raw_item_functions.add_recipient_to_item(application, activity, contact.Email);
	g_ctx.save(activity);
}

function process_activity_participant(item, handler) {
	if (item.type_id == "TaskParticipant" || item.type_id == "AppointmentParticipant") {
		var activity = null;
		if (item.Activity != null) {
			activity = session.open_item(item.Activity);
		}
		if (item.Participant != null && activity != null && activity.raw_item.Ownership != 1) {
			var contact = session.open_item(item.Participant);
			if (contact != null && contact.Email != null) {
				handler(activity, contact);
			}
		}
	}
}

function on_fra_step(step_id, callback_wrapper) {
	if (step_id == "sa-convert_items") {
		application.item_convertor.convert_type_to_platform("Contact");
		callback_wrapper.done(false);
	}
}

function get_proxy_by_PIMId(id) {
	var session = g_ctx.session, filter = session.create_criteria("and");
	filter.add(session.create_expression("PIMObjectId", "eq", id));
	return session.find_item("Activity", filter);;
}

function process_ol_item_changes(item) {
	var mail_processor = new business_logic.mail_processor(g_ctx), session = g_ctx.session;
	var id = item.SearchKey;
	var helper = get_proxy_by_PIMId(id);
	if (typeof (helper) != "undefined" && helper != null) {
		mail_processor.process_ol_item_changes(new data_model.std_item_ex(helper, null),
								new data_model.std_item_ex(item, null), true);
	}
}

application.on_item_created.connect(on_item_created);
application.on_item_changed.connect(on_item_changed);
application.on_item_deleted.connect(on_item_deleted);
application.on_mail_sent.connect(process_ol_item_changes);
application.on_fra_step.connect(on_fra_step);
g_ctx.synchronizer.on_before_item_delete.connect(on_item_before_delete);

var action_manager = actions_support.create_action_manager(application, util);
action_manager.add_action("contact_convert_bpmonline", new actions.convert_items(application.item_convertor, g_ctx, true, "Contact"));
action_manager.add_action("contact_convert_outlook", new actions.convert_items(application.item_convertor, g_ctx, false, "Contact"));
action_manager.add_action("appointment_convert_bpmonline", new actions.convert_items(application.item_convertor, g_ctx, true, "Appointment"));
action_manager.add_action("appointment_convert_outlook", new actions.convert_items(application.item_convertor, g_ctx, false, "Appointment"));
action_manager.add_action("calendar_convert_bpmonline", new actions.convert_items(application.item_convertor, g_ctx, true, "Appointment"));
action_manager.add_action("calendar_convert_outlook", new actions.convert_items(application.item_convertor, g_ctx, false, "Appointment"));
action_manager.add_action("task_convert_bpmonline", new actions.convert_items(application.item_convertor, g_ctx, true, "Task"));
action_manager.add_action("task_convert_outlook", new actions.convert_items(application.item_convertor, g_ctx, false, "Task"));
action_manager.add_actions(["show_help_contact", "show_help_calendar", "show_help_mail", "show_help", "show_help_task",
	"show_help_appointment", "show_help_calendar"], new actions.show_help(g_ctx));
action_manager.add_actions(["new_contact"], new actions.new_item(g_ctx, "Contact"));
action_manager.add_actions(["new_appointment", "new_appointment"], new actions.new_item(g_ctx, "Appointment"));
action_manager.add_actions(["new_task"], new actions.new_item(g_ctx, "Task"));
action_manager.add_actions(["new_calendar_appointment"], new actions.new_item(g_ctx, "Appointment"));
action_manager.add_actions(["track_mail"], new actions.track_mail(g_ctx, true));
action_manager.add_actions(["un_track_mail"], new actions.track_mail(g_ctx, false));
action_manager.add_actions(["track_contact"], new actions.track_item(g_ctx, true, "Contact"));
action_manager.add_actions(["untrack_contact"], new actions.track_item(g_ctx, false, "Contact"));;
action_manager.add_actions(["track_task"], new actions.track_item(g_ctx, true, "Task"));
action_manager.add_actions(["untrack_task"], new actions.track_item(g_ctx, false, "Task"));
action_manager.add_actions(["track_appointment", "track_calendar"], new actions.track_item(g_ctx, true, "Appointment"));
action_manager.add_actions(["untrack_appointment", "untrack_calendar"], new actions.track_item(g_ctx, false, "Appointment"));
action_manager.add_actions(["open_remote", "calendar_open_remote", "c_open_remote", "m_open_remote", "mi_open_remote",
		"t_open_remote", "a_open_remote", "event_open_remote", "task_open_remote"], new actions.open_remote(g_ctx));

var convertor_helper = new idle.item_convert_helper(g_ctx, {
	"types": {
		"Contact": new business_logic.contact_conversion_helper(),
		"Appointment": new business_logic.contact_conversion_helper(),
		"Task": new business_logic.contact_conversion_helper()
	}
});

//clear_mail_box();

function clear_mail_box() {
	/*var types = ['::Defaults', 'Activity', 'ActivityFile', 'ActivityStatus',
	'Account', 'AddressType', 'Campaign', 'City', 'Contact', 'ContactDecisionRole',
	'ContactSalutationType', 'ContactType', 'Country', 'Department', 'Document', 'EmailSendStatus',
	'Employee', 'Gender', 'Invoice', 'Job', 'Opportunity', 'Region',
	'SysAdminUnit', 'SysContactRight', 'SysEntitySchemaRecRightSource'];*/
	var types = ['ActivityFile'];
	var filter = g_ctx.session.create_criteria("and");
	helpers.for_each(types, function (type) {
		var count, total_count = 0;
		do {
			count = 0;
			var items = session.find_items(type, filter);
			helpers.for_each(items, function (item) {
				item.remove();
				count++;
			});
			total_count += count;
		} while (count != 0);
		g_ctx.application.logger.info(type + " removed " + total_count);
	});
}
