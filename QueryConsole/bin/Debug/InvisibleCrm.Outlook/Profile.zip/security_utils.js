include("security_manager.js", "security_manager");
include("helpers.js", "helpers");

function workbooks_security_manager(session)
{
	return new security_manager.security_manager(session, [], workbooks_security_factory());
}

function workbooks_security_factory()
{		
	function workbooks_security(session, item, form)
	{
		var DENY_VIEW = 0x00000001;
		var DENY_MODIFY = 0x00000002;
		var DENY_DELETE = 0x00000004;
		var SYNCHRONIZED = 0x20000000;
		var INDIRECTLY_VISIBLE = 0x40000000;
		
		function get_hex_object_state()
		{
			if (item["object_state"] != undefined)
				return "0x" + item["object_state"].toString(16);	
			else
				return "0x00000000";
		}
		
		/*return true if can access*/		
		this.view_access = function()
		{
			return !(get_hex_object_state() & DENY_VIEW);
		}
		
		/*return true if can modify*/
		this.modify_access = function()
		{
			return (!(get_hex_object_state() & DENY_MODIFY) && (!(get_hex_object_state() & INDIRECTLY_VISIBLE)));
		}
		
		/*return true if can delete*/
		this.delete_access = function()
		{
			return (!(get_hex_object_state() & DENY_DELETE) && (!(get_hex_object_state() & INDIRECTLY_VISIBLE)));
		}
	}
	
	var create_fn = function (session, item, form)
	{
		return new workbooks_security(session, item, form);
	}
	
	return create_fn;
}
