include("helpers.js", "helpers");
include("security_utils.js", "security_utils");
include("data_model.js", "data_model");
include("form_helpers.js", "form_helpers");
include("md5.js", "md5");

function string_helper()
{
	var allSpacesRe = /\s+/g;
	var leadingSpacesRe = /^\s+/;
	var trailingSpacesRe = /\s+$/;
	
	this.remove_spaces = function(s) 
	{ return s.replace(allSpacesRe, ""); }
	
	this.trim_leading = function(s) 
	{ return s.replace(leadingSpacesRe, ""); }
	
	this.trim_trailing = function(s) 
	{ return s.replace(trailingSpacesRe, ""); }

	this.trim = function(s) 
	{ return this.trim_leading(this.trim_trailing(s)); }
}

function create_security_manager(session)
{
	return security_utils.workbooks_security_manager(session);
}

function string_to_hex(str) {
	var hex = '';
	for (var i = 0; i < str.length; i++) {
		hex += '' + str.charCodeAt(i).toString(16);
	}
	return hex;
}

function view_controls_handler(session, ui, meta_scheme)
{
	return new form_helpers.view_controls_handler(session, ui, create_security_manager(session, meta_scheme));
}

function try_to_save(session, ui, item, controlling_item)
{
	if (controlling_item == undefined)
		controlling_item = item;
	if (helpers.safe_get_id(item) == null)
	{
		if (ui.message_box(0, session.res_string("msg_item_not_saved"), session.res_string("msg_item_not_saved_caption"), 0x44) != 6)
			return false;
		try
		{
			controlling_item.save();
		}
		catch(e)
		{
			return false;
		}
	}
	return true;
}

function hash(source)
{
	return md5.hex_md5(source);
}
